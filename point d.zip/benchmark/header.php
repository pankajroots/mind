<?php
/**
 * The template for displaying the header
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <?php if ( $bmrk_opts[ 'resp-mode' ] ) : ?>
    <meta name="viewport" content="initial-scale=1, width=device-width"/>
    <?php endif; ?>
    <!-- Add js-enabled class to html -->
    <script>(function(){document.documentElement.className='js-enabled'})();</script>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

    <!-- Mobile Menu -->
    <div id="resp-menu">

        <div class="resp-menu-logo">
			<?php benchmark_logo( 'mobile' ); ?>
        </div><!-- /.resp-menu-logo -->

		<?php
		$menu_args = array( 'theme_location' => 'primary', 'menu_class' => 'resp-menu', 'container' => false, 'fallback_cb' => 'benchmark_resp_menu_fallback' );
		$hide_top_nav = '';

		if ( is_page() ) {
			global $post;

			// Fetch page options for per page header area settings
			$page_opts 		= get_post_meta( $post->ID, 'bmrk_page_opts', true );
			$custom_menu 	= isset( $page_opts[ 'custom_menu' ] ) ? $page_opts[ 'custom_menu' ] : false;
			$one_page_menu 	= isset( $page_opts[ 'one_page_menu' ] ) ? $page_opts[ 'one_page_menu' ] : false;
			$hide_top_nav 	= isset( $page_opts[ 'hide_top_nav' ] ) ? $page_opts[ 'hide_top_nav' ] : false;

			if ( $custom_menu && $custom_menu !== 'none' ) {
				$menu_args['menu'] = $custom_menu;
				$menu_args['theme_location'] = '';
			}

			if ( $one_page_menu && has_nav_menu( 'primary' ) || ( $one_page_menu && $custom_menu && $custom_menu !== 'none' ) ) {
				$menu_args['menu_class'] = 'one-page-menu resp-menu';
			}

        	wp_nav_menu( $menu_args );
		}

		else {

			if ( isset( $bmrk_opts[ 'responsive-menu' ] ) && ! empty( $bmrk_opts[ 'responsive-menu' ] ) ) {
				$menu_args['menu'] = $bmrk_opts[ 'responsive-menu' ];
				$menu_args['theme_location'] = '';
			}

			wp_nav_menu( $menu_args );
		}
		?>

    </div><!--/ #resp-menu -->

    <div id="page" class="hfeed site clearfix">

        <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'benchmark' ); ?></a>

        <header id="header" class="site-header clearfix normal">

            <?php
			// Top links bar
            if ( $bmrk_opts[ 'top-bar-check' ] ) :
				if ( is_page() ) {
					if ( ! $hide_top_nav ) {
						get_template_part( 'includes/utility-bar' );
					}
				}
				else {
					get_template_part( 'includes/utility-bar' );
				}
            endif;

			// Header area - logo, header icons, etc.
            get_template_part( 'includes/header-area' );
		?>

        </header><!-- /#header -->

        <?php // Hero area - page titles, custom banner, etc.
        get_template_part( 'includes/hero-area' );  ?>

        <div id="primary">
            <div id="content" class="site-content container clearfix">
                <div class="row content-row">
					<?php if ( $bmrk_opts[ 'pwa-check' ]  ) :
						if ( is_active_sidebar( 'primary-widget-area' ) ) : ?>

                            <!-- Primary widget area -->
                            <div class="widget-area primary-widget-area clearfix">
								<?php dynamic_sidebar( 'primary-widget-area' ); ?>
                            </div><!-- /.primary-widget-area -->

						<?php endif;
                    endif; ?>