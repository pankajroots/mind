<?php
/**
 * The template for displaying all pages.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

get_header();

	// Page options variables
	$page_opts 		= get_post_meta( $posts[0]->ID, 'bmrk_page_opts', true );
	$sb_placement 	= isset( $page_opts[ 'sb_placement' ] ) ? $page_opts[ 'sb_placement' ] : 'global';

	$content_class 	= 'col-xs-12 col-md-9';

	switch( $sb_placement ) {

		case 'none' :
			$content_class = 'col-md-12';
		break;

		case 'left' :
			$content_class = 'col-xs-12 col-md-9 content-right';
		break;

		case 'right' :
			$content_class = 'col-xs-12 col-md-9 content-left';
		break;

	}
?>

<main id="main" class="<?php echo esc_attr( $content_class ); ?>">
	<?php
    do_action( 'benchmark_main_content_start' );

    while ( have_posts() ) :
		the_post(); ?>

        <div id="post-<?php the_ID(); ?>" <?php post_class( 'page-content' ); ?>>

            <div class="entry-content">

				<?php the_content();

                wp_link_pages( array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'benchmark' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'benchmark' ) . ' </span>%',
					'separator'   => '<span class="screen-reader-text">, </span>',
                ) );
                ?>
            </div><!-- /.entry-content -->
        </div><!-- /.page-content -->

        <?php

		// If comments are open or we have at least one comment, load up the comment template.
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}

    endwhile;
    ?>

    </main><!-- /#main -->

    <?php
    if ( 'none' != $sb_placement ) {
		get_sidebar();
	}

    get_footer(); ?>