/**
 * custom.js
 * custom JavaScript functions and plugin initialization
 */
jQuery(function ($) {

    'use strict';

    // Loading spinner
    var bmrk_spinner = '<div class="md-loader"><svg class="spinner" x="0px" y="0px" width="40px" height="40px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><g transform="translate(33, 33)"><circle class="myObject" stroke="#000" fill="none" stroke-linecap="round" stroke-width="5" x="-10" y="-10" r="20"></circle></g></svg></div>',
        update_wishlist_count;

    // Material design loader
    function materialLoader() {
        $.blockUI.defaults.onBlock = function () {
            $(bmrk_spinner).hide().appendTo($(this)).fadeIn(1000);
        };
        $.blockUI.defaults.onUnBlock = function () {
            $(this).find('.md-loader').fadeOut(1000);
        };
    }

    // Show loading spinner on various events
    $(document).on('init_checkout update_checkout updated_shipping_method', 'body', materialLoader)
        .on('change', 'select.shipping_method, input[name^=shipping_method]', materialLoader)
        .on('click', 'a.remove_from_wishlist', materialLoader);

    // Show loading spinner on add to cart and wishlist event
    $(document).on('click', 'a.add_to_cart_button:not(.product_type_variable), a.add_to_wishlist', function () {
        $('div.product-actions-overlay').removeClass('pao-active');
        $(bmrk_spinner).hide().appendTo($(this).closest('div.product-wrap')).fadeIn(1000);
        $(this).closest('div.product-wrap').addClass('product-adding');
    });

    // Remove spinner when products loaded
    $(document).on('added_to_cart added_to_wishlist', 'body', function () {
        $('div.md-loader').addClass('md-success').find('svg.spinner').fadeOut(1000, function () {
                $(this).remove();
            })
            .closest('div.product-wrap').addClass('product-added').removeClass('product-adding');
        $('div.md-success').addClass('show-in').delay(1000).fadeOut(400, function () {
            $(this).remove();
        });
    });


    // yith wishlist count update
    update_wishlist_count = function () {
        $.ajax({
            beforeSend: function () {},
            complete: function () {},
            data: {
                action: 'update_wishlist_count'
            },
            success: function (data) {
                $('.header-wishlist-count .wishlist-count').html(data);
            },

            url: yith_wcwl_l10n.ajax_url
        });
    };

    $('body').on('added_to_wishlist removed_from_wishlist added_to_cart', update_wishlist_count);


    // Add loading spinner to yith ajax navigation results
    $(document).on('click', '.yith-wcan a', function () {
        var container = $('div.products');
        if (container.is('.yith-wcan-loading')) {
            container.append(bmrk_spinner);
        }
    });

    $('.yith-wcwl-add-button').find('img.ajax-loading').remove();

    $(window).on('load', function () {

        // Owl carousel init
        if ($.fn.owlCarousel) {
            var target = $(".gallery-slider");
            $('#owl-testimonials').owlCarousel({
                margin: 24,
                items: 1,
                smartSpeed: 1000
            });
            target.each(function () {
                var slider = $(this).find(".owl-carousel"),
                    parent = $(this);

                slider.owlCarousel({
                    items: parent.data('items'),
                    loop: false,
                    margin: parent.data('margin'),
                    autoplay: true,
                    autoplayTimeout: 5000,
                    autoHeight: false,
                    nav: parent.data('nav'),
                    dots: parent.data('dots'),
                    smartSpeed: 500,
                    navText: false,
                    rtl: ($("body").is(".rtl")),
                    autoplayHoverPause: true,

                    responsive: {
                        0: {
                            items: 1,
                            dots: true
                        },
                        480: {
                            items: (parent.data('items') > 2 ? 2 : parent.data('items')),
                            dots: true
                        },
                        600: {
                            items: (parent.data('items') > 3 ? 3 : parent.data('items')),
                            dots: true
                        },
                        960: {
                            items: parent.data('items')
                        }
                    }
                });
            });
        }

        // Enable masonry for post grids and products
        if ($.isFunction($.fn.masonry)) {
            $('#main .masonry-enabled, .masonry-enabled').masonry({
                itemSelector: '.entry-grid, .product',
                isOriginLeft: !($('body').is('.rtl'))
            });
        }

    });
});

jQuery(document).ready(function ($) {

    'use strict';

    // Add accordion like submenu items to responsive menu
    function responsive_menu_items() {
        var sub_menus = $('.resp-menu').find('.menu-item-has-children'),
            expand_menus,
            expand_text = bmrk_custom !== 'undefined' ? bmrk_custom.expand_menu_text : 'Expand or collapse menu items';

        if (sub_menus.length) {
            $(sub_menus).each(function () {
                $(this).append('<a class="expand-menu" href="#" title="' + expand_text + '"><i class="mdi mdi-keyboard_arrow_down"></i></a>').find('.sub-menu').hide();
            });
        }

        expand_menus = $('.resp-menu').find('.expand-menu');

        if (expand_menus.length) {
            $(expand_menus).on('click', function (e) {
                var icon = $(this).find('.mdi');
                icon.toggleClass('rotate-180');
                $(this).prev().slideToggle(300);
                e.preventDefault();
            });
        }

    }

    responsive_menu_items();

    // Toggle body classes for responsive menu
    $('.menu-trigger, .resp-menu-mask').click(function (e) {
        $('body').toggleClass('show-nav');
        e.preventDefault();
    });

    $('.filter-button, .shop-sb-mask').click(function (e) {
        e.preventDefault();
        $('body').toggleClass('show-shop-sb');

    });

    // Search form
    $('.search-trigger').click(function (e) {
        e.preventDefault();
        $(this).toggleClass('search-btn-active');
        $('.search-panel').toggleClass('search-active');
        setTimeout(function () {
            $('.search-panel').find('input.search-field').focus();
        }, 500);
    });

    $('.search-close').click(function (e) {
        e.preventDefault();
        $('.search-panel').removeClass('search-active');
        $('.search-trigger').removeClass('search-btn-active');
    });

    // WooCommerce cart submenu
    $(document).on('click', 'a.cart-contents-2', function (e) {
        $(this).parent().find('div.cart-submenu').toggleClass('cart-active');
        $(this).toggleClass('cart-btn-active');
        e.preventDefault();
    });


    // Product and post grid actions
    $(document).on("click", 'a.product-actions-trigger, a.post-actions-trigger', function (e) {
        e.preventDefault();
        var t = $(this).parent().find('div.product-actions-overlay, div.post-actions-overlay'),
            panels = $('div.product-actions-overlay,div.post-actions-overlay');
        $(t).toggleClass('pao-active');
        $(panels).not(t).removeClass('pao-active');
    });

    // Close search bar and cart submenu when clicking on document body
    $(document).on("click", function () {
        $('.search-overlay').removeClass('search-active');
        $('.cart-submenu').removeClass('cart-active');
        $('.product-actions-overlay, .post-actions-overlay').removeClass('pao-active');
        $('a.cart-contents-2').removeClass('cart-btn-active');
    });

    // Stop propagation for various selectors
    $(document).on('click', '.search-trigger, .search-overlay, .cart-widget, a.product-actions-trigger, a.post-actions-trigger, .yith-wcqv-button', function (e) {
        e.stopPropagation();
    });


    // Sticky Nav
    function benchmark_sticky_nav() {
        if (bmrk_custom !== 'undefined' && 'fixed' === bmrk_custom.navbar_type) {
            var lastScroll = 0,
                nav_offset = $('#header').outerHeight(),
                top_bar = $('#utility-top').outerHeight() + $('.top-widget-area').outerHeight(),
                successor = $('#hero-area').length ? $('#hero-area') : $('#primary');

            if (!$('body').hasClass('transparent-nav')) {
                successor.css({
                    "padding-top": nav_offset
                });
            }

            $(window).on('load scroll', function () {
                var st = $(this).scrollTop();
                if (st > top_bar) {
                    $('#header').addClass('nav-enabled');
                } else {
                    $('#header').removeClass('nav-enabled');
                }
                lastScroll = st;
            });
        }

    }

    benchmark_sticky_nav();

    /**
     * Nav menu hover effect
     */
    $('.nav-menu li').hover(function () {
        $(this).find('ul:first').css({
            visibility: "visible",
            display: "none"
        }).fadeIn(200);
    }, function () {
        $(this).find('ul:first').css({
            visibility: "visible",
            display: "none"
        });
    });

    /**
     * Smooth scrolling
     * http://css-tricks.com/snippets/jquery/smooth-scrolling/
     */

    function smoothLinkScroll() {
        var scroll_links = $('a[href*="#"]:not([href="#"], [role="tab"], .panel-title a)'),
            flag = $('body').hasClass('one-page-enabled');
        if (flag) {
            scroll_links.each(function () {
                var $this = $(this);
                $this.click(function () {
                    if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
                        var target = $(this.hash),
                            offset = $('.header-main').outerHeight();
                        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                        if (target.length) {
                            $('html,body').animate({
                                scrollTop: target.offset().top - 64 // or use offset
                            }, 1000);
                            return false;
                        }
                    }
                });
            });
        }
    }

    smoothLinkScroll();

    // https://jsfiddle.net/mekwall/up4nu/
    function linkScrollSpy() {

        // Bind to scroll
        $(window).on('scroll', function () {
            // Get container scroll position
            var menuItems = $('.one-page-menu').find('a[href*="#"]:not([href="#"])'),
                scrollItems,
                topMenuHeight = $('.header-main').outerHeight(),
                fromTop = $(this).scrollTop() + topMenuHeight,
                cur,
                lastId;

            if (menuItems !== 'undefined' && menuItems.length) {
                scrollItems = menuItems.map(function () {
                    var item = $($(this).attr("href"));
                    if (item.length) {
                        return item;
                    }
                });

                // Get id of current scroll item
                cur = scrollItems.map(function () {
                    if ($(this).offset().top < fromTop + topMenuHeight)
                        return this;
                });
                // Get the id of the current element
                cur = cur[cur.length - 1];
                var id = cur && cur.length ? cur[0].id : "";

                if (lastId !== id) {
                    lastId = id;
                    // Set/remove active class
                    menuItems
                        .parent().removeClass("active")
                        .end().filter('[href="#' + id + '"]').parent().addClass("active");
                }
            }
        });
    }

    linkScrollSpy();


    // Scroll to top button
    $('#scroll-to-top').hide();
    $(window).on('load scroll', function () {
        if ($(this).scrollTop() > 100) {
            $('#scroll-to-top').fadeIn(300);
        } else {
            $('#scroll-to-top').fadeOut(300);
        }
    });

    $('#scroll-to-top a').click(function () {
        $('html, body').animate({
            scrollTop: 0
        }, 800);
        return false;
    });

    // Print button on single post and single product
    $('.ss-print a').click(function (e) {
        e.preventDefault();
        window.print();
    });

    // Add brackets to category widget counts
    function addBrackets() {
        var count_items = $('small.count');
        count_items.each(function () {
            $(this).text('(' + $(this).text() + ')');
        });
    }

    addBrackets();

    // Restart yith quickview plugin when products filtered via yith ajax navigation
    $(document).on('yith-wcan-ajax-filtered', function () {
        if ($.fn.yith_quick_view) {
            $.fn.yith_quick_view();
        }
        addBrackets();
    });

    $('#option-button').on('click', function (e) {
        e.preventDefault();
        $('.option-panel').toggleClass('panel-active');
    });
});