Dear user,

Kindly refer to the documentation/index.html file inside your main download archive for theme installation and setup instructions.