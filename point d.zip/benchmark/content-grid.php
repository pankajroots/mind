<?php
/**
 * Content Loop for archives - Grid Style.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

?>


	<?php
	// Class variables
	$count = 1;
	$clear_class = '';
	$grid_class = 'entry-grid col-xs-6';

	switch( $bmrk_opts[ 'grid-columns' ] ) {
		case '2' :
			$grid_class .= ' ss-col-2';
		break;
		
		case '3' :
			$grid_class .= ' col-sm-4 col-md-4 ss-col-3';
		break;

		case '4' :
			$grid_class .= ' col-sm-3 col-md-3 ss-col-4';
		break;
	}

?>

        <article id="post-<?php the_ID();?>" <?php post_class( $grid_class ); ?>>
            <div class="entry-inner">
				<?php if ( 'video' == get_post_format() && $bmrk_opts[ 'archive-video-check' ] ) {
                    get_template_part( 'formats/format-video' );
                }
                else {
				if ( has_post_thumbnail() ) { ?>
                    <div class="post-thumb">
						<?php if ( 'gallery' == get_post_format() ) { ?>
                            <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                        <?php }

                        elseif ( 'video' == get_post_format() ) { ?>
                            <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                        <?php }

						if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
                            echo benchmark_post_thumbnail( $bmrk_opts[ 'grid-images' ][ 'width' ], $bmrk_opts[ 'grid-images' ][ 'height' ], (bool)$bmrk_opts[ 'grid-misc' ][ '1' ], (bool)$bmrk_opts[ 'grid-misc' ][ '2' ] );
						}

						else { ?>

                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php
                            echo benchmark_post_thumbnail( $bmrk_opts[ 'grid-images' ][ 'width' ], $bmrk_opts[ 'grid-images' ][ 'height' ], (bool)$bmrk_opts[ 'grid-misc' ][ '1' ], (bool)$bmrk_opts[ 'grid-misc' ][ '2' ] );
                            ?>
                        </a>

						<?php } ?>

                    </div><!-- /.post-thumb -->
                <?php } // has_post_thumbnail
				} ?>

                <div class="entry-content">
					<?php

					// Action hook before grid post title
					do_action( 'benchmark_before_grid_title' );

					the_title( '<h2><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

					// Action hook after grid post title
					do_action( 'benchmark_after_grid_title' );
					?>

                    <p class="post-excerpt">
						<?php echo benchmark_short( get_the_excerpt(), $bmrk_opts[ 'excerpt-length-grid' ] ); ?>
                    </p>
                </div><!-- /.entry-content -->

				<?php
                if ( $bmrk_opts[ 'archive-meta-check' ] ) : ?>
                    <footer class="entry-actions">
                        <aside id="meta-<?php the_ID();?>" class="entry-meta"><?php echo benchmark_footer_actions(); ?></aside>
                    </footer><!-- ./entry-actions -->
                <?php endif; ?>

            </div><!-- /.entry-inner -->

		</article><!-- /#post-<?php the_ID();?> -->