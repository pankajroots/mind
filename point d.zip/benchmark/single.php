<?php
/**
 * The Template for displaying all single posts.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

get_header();

	// Post option panel variables
	$post_opts 			= get_post_meta( $posts[0]->ID, 'bmrk_post_options', true );
	$hide_meta 			= ( isset( $post_opts['hide_meta'] ) ) ? $post_opts['hide_meta'] : '';
	$hide_image 		= ( isset( $post_opts['hide_image'] ) ) ? $post_opts['hide_image'] : '';
	$hide_related 		= ( isset( $post_opts['hide_related'] ) ) ? $post_opts['hide_related'] : '';
	$show_image 		= ( isset( $post_opts['show_image'] ) ) ? $post_opts['show_image'] : '';
	$sb_placement 		= isset( $post_opts[ 'sb_placement' ] ) ? $post_opts[ 'sb_placement' ] : 'global';

	// Set basic content class
	$content_class = 'col-xs-12 col-md-9';

	// Change content class according to sidebar placement
	switch( $sb_placement ) {

		case 'none' :
			$content_class = 'col-md-12';
		break;

		case 'left' :
			$content_class = 'col-xs-12 col-md-9 content-right';
		break;

		case 'right' :
			$content_class = 'col-xs-12 col-md-9 content-left';
		break;

	}

	// Start main content
	?>
	<main id="main" class="<?php echo esc_attr( $content_class ); ?>">

		<?php
        // Inline widget area before content
        if ( $bmrk_opts[ 'cwa-a-check' ]  ) :
			if ( is_active_sidebar( 'content-widget-area-a' ) ) : ?>

                <div class="widget-area content-widget-area clearfix">
					<?php dynamic_sidebar( 'content-widget-area-a' ); ?>
                </div><!-- /.content-widget-area -->

			<?php endif;
        endif;

        // Load breadcrumb
        do_action( 'benchmark_main_content_start' );

        // Start the loop
        while ( have_posts() ) : the_post(); ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                <header class="entry-header">
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                </header><!-- .entry-header -->

                <div class="entry-content">

					<?php
                    if( 'video' == get_post_format() ) {
						get_template_part( 'formats/format', 'video' );
					}

                    else {
						if ( $bmrk_opts[ 'feat-image-check' ] && ! is_attachment() ) :
							if ( ! $hide_image ) : ?>
                                <p class="single-post-image"><?php echo benchmark_post_thumbnail( $bmrk_opts[ 'single-images' ][ 'width' ], $bmrk_opts[ 'single-images' ][ 'height' ], (bool)$bmrk_opts[ 'single-misc' ][ '1' ], (bool)$bmrk_opts[ 'single-misc' ][ '2' ] ); ?></p>
                                <?php echo benchmark_post_thumbnail_caption();
							endif;
						else :
							if ( 'true' == $show_image ) : ?>
                                <p class="single-post-image"><?php echo benchmark_post_thumbnail( $bmrk_opts[ 'single-images' ][ 'width' ], $bmrk_opts[ 'single-images' ][ 'height' ], (bool)$bmrk_opts[ 'single-misc' ][ '1' ], (bool)$bmrk_opts[ 'single-misc' ][ '2' ] ); ?></p>
                                <?php echo benchmark_post_thumbnail_caption();
							endif;
						endif;
                    }

                    /* translators: %s: Name of current post */
                    the_content( sprintf(
						esc_html__( 'Continue reading %s', 'benchmark' ),
						the_title( '<span class="screen-reader-text">', '</span>', false )
                    ) );

                    wp_link_pages( array(
						'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'benchmark' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
						'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'benchmark' ) . ' </span>%',
						'separator'   => '<span class="screen-reader-text">, </span>',
                    ) );
                    ?>
                </div><!-- .entry-content -->

                <?php
                // Single post meta
                if ( $bmrk_opts[ 'single-meta-check' ] ) :
					if ( ! $hide_meta ) : ?>
                        <footer id="meta-<?php the_ID();?>" class="entry-footer entry-meta single-entry-meta">
							<?php echo apply_filters( 'benchmark_post_meta_single', benchmark_post_meta( 'meta-links' ) ); ?>
                        </footer><!-- /.entry-footer -->
					<?php endif;
                endif;
                ?>

            </article><!-- #post-## -->

            <?php
            // Post navigation links
            if ( $bmrk_opts[ 'single-nav-check' ] ) :
				the_post_navigation( array(
					'next_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Next', 'benchmark' ) . '</span> ' .
					'<span class="screen-reader-text">' . esc_html__( 'Next post:', 'benchmark' ) . '</span> ' .
					'<span class="post-title">%title</span>',
					'prev_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Previous', 'benchmark' ) . '</span> ' .
					'<span class="screen-reader-text">' . esc_html__( 'Previous post:', 'benchmark' ) . '</span> ' .
					'<span class="post-title">%title</span>',
				) );
            endif;

			// Social sharing links
            if ( $bmrk_opts[ 'sharing-check' ] ) :
				echo bmrk_social_sharing( apply_filters( 'benchmark_social_sharing_heading', esc_html__( 'Share this', 'benchmark' ) ), $bmrk_opts[ 'sharing-buttons' ] );
            endif;

			// Author bio
            if ( $bmrk_opts[ 'author-check' ] ) :
				if ( get_the_author_meta( 'description' ) ) : ?>
                    <div class="author-info clearfix">
                        <h3 class="author-heading"><?php esc_html_e( 'Published by', 'benchmark' ); ?></h3>

                        <div class="author-avatar">
							<?php echo get_avatar( get_the_author_meta( 'user_email' ), 80 ); ?>
                        </div><!-- /.author-avatar -->

                        <div class="author-description">
                            <h4 class="author-title"><?php echo get_the_author(); ?></h4>

                            <p class="author-bio">
                            <?php the_author_meta( 'description' ); ?>
                            </p><!-- /.author-bio -->

                            <p><a class="author-link" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author">
                            <?php printf( esc_html__( 'More posts by %s', 'benchmark' ), get_the_author() ); ?>
                            </a></p>
                        </div><!-- /.author-description -->
                    </div><!-- /.author-info -->
				<?php endif;
            endif;

            // Related Posts
            if ( $bmrk_opts[ 'rp-check' ] && ! is_attachment() ) {
				if ( ! $hide_related ) {
					benchmark_related_posts();
				}
            }

            // Inline widget area after content
            if ( $bmrk_opts[ 'cwa-b-check' ] ) :
				if ( is_active_sidebar( 'content-widget-area-b' ) ) : ?>

                    <div class="widget-area content-widget-area clearfix">
                    <?php dynamic_sidebar( 'content-widget-area-b' ); ?>
                    </div><!-- /.content-widget-area -->

				<?php endif;
            endif;

            // Comments template
            if ( comments_open() || get_comments_number() ) {
				comments_template();
            }

        endwhile; ?>

	</main><!-- /#main -->

	<?php
    if ( $bmrk_opts[ 'single-sb-check' ] ) {
		if ( 'none' != $sb_placement ) {
			get_sidebar();
		}
	}
	get_footer(); ?>