<?php
/**
 * The sidebar containing the main widget area.
 */

global $post;
?>

<div id="sidebar" class="widget-area col-xs-12 col-md-3" role="complementary">
	<?php
	if ( is_active_sidebar( 'sidebar-widget-area' ) ) : ?>
		<div class="main-sidebar">
			<?php dynamic_sidebar( 'sidebar-widget-area' ); ?>
		</div><!-- /.main-sidebar -->
	<?php
	endif;
	?>
</div><!-- #sidebar -->