<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "bmrk_opts";


    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Theme Options', 'benchmark' ),
        'page_title'           => esc_html__( 'Theme Options', 'benchmark' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
		'forced_dev_mode_off'  => true,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'system_info'          => false,
        // REMOVE

        //'compiler'             => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */



    /*
     *
     * ---> START SECTIONS
     *
     */

    /* As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for */

    // -> START Basic Fields

                Redux::setSection( $opt_name, array(
                    'title'  => esc_html__( 'General', 'benchmark' ),
                    'desc'   => esc_html__( 'This section contains general settings for the theme.', 'benchmark' ),
                    'icon'   => 'el el-home',
                    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
                    'fields' => array(

                        array(
                            'id'       => 'layout-style',
                            'type'     => 'image_select',
                            'title'    => esc_html__( 'Layout Style', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose a layout style', 'benchmark' ),
                            //Must provide key => value(array:title|img) pairs for radio options
                            'options'  => array(
                                'boxed' => array( 'title' => 'Boxed', 'img' => get_template_directory_uri() . '/images/boxed.png' ),
                                'stretched' => array( 'title' => 'Stretched', 'img' => get_template_directory_uri() . '/images/stretched.png' ),
                             ),
                            'default'  => 'stretched'
                        ),

						array(
							'id' => 'layout-width',
							'type' => 'slider',
							'title' => esc_html__('Layout Width', 'benchmark'),
							'subtitle' => esc_html__('Set or change the site layout width', 'benchmark'),
							'desc' => esc_html__('Value is in px. Min: 800, Max: 2000, default value: 940', 'benchmark'),
							"default" => 940,
							"min" => 800,
							"step" => 1,
							"max" => 2000,
							'display_value' => 'text'
						),

                        array(
                            'id'       => 'color-scheme',
                            'type'     => 'select',
                            'title'    => esc_html__( 'Color Scheme', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select a color scheme for the theme.', 'benchmark' ),
							'desc' => esc_html__( 'These CSS files are located inside css/schemes/ folder.', 'benchmark' ),
                            'options'  => array(
								'default'	=> 'Default',
								'blue' => 'Blue',
								'brown' => 'Brown',
								'coffee' => 'Coffee',
								'forest' => 'Forest Green',
								'green' => 'Green',
								'indigo' => 'Indigo',
								'pink' => 'Pink',
								'purple-green' => 'Purple Green',
								'purple-tan' => 'Purple Tan',
								'purple' => 'Purple',
								'slate' => 'Slate',
								'teal' => 'Teal',
								'white'  => 'White'
							),
                            'default'  => 'default',
                        ),

                        array(
                            'id'       => 'sb-pos',
                            'type'     => 'image_select',
                            'title'    => esc_html__( 'Sidebar Placement', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select a sidebar placement.', 'benchmark' ),
                            'options'  => array(
                                'left' => array(
									'title' => 'Left',
                                    'alt' => '2 Column Left',
                                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                                ),
                                'right' => array(
									'title' => 'Right',
                                    'alt' => '2 Column Right',
                                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                                )
                            ),
                            'default'  => 'right'
                        ),

                        array(
                            'id'       => 'custom-head-code',
                            'type'     => 'textarea',
                            'title'    => esc_html__( 'Custom Head Markup', 'benchmark' ),
                            'subtitle' => esc_html__( 'Place any custom code you want to show in head node of site.', 'benchmark' ),
                            'desc'     => esc_html__( 'This field can be used for placing Google Analytics code or any custom JS code.', 'benchmark' ),
                            'validate' => '',
                            'default'  => ''
                        ),

                        array(
                            'id'       => 'crumbs-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Breadcrumbs', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide breadcrumbs', 'benchmark' ),
                            'default'  => true,
							'on'       => 'Show',
							'off'      => 'Hide',
                        ),

                        array(
                            'id'       => 'resp-mode',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Responsive Mode', 'benchmark' ),
                            'subtitle' => esc_html__( 'Enable or disable responsiveness', 'benchmark' ),
                            'default'  => true,
							'on'       => 'Enable',
							'off'      => 'Disable',
                        ),

						array(
							'id'       => 'social-meta-check',
							'type'     => 'checkbox',
							'title'    => esc_html__('Social Sharing Meta tags', 'benchmark'),
							'subtitle' => esc_html__('Enable social sharing meta tags for the following:', 'benchmark'),
							'desc'     => esc_html__('Social meta tags are added in head node of site for proper content sharing. This includes Open Graph tags for Facebook.', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'posts' => 'Posts',
								'pages' => 'Pages'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'posts' => '1',
								'pages' => '0'
							)
						)

                        /*array(
                            'id'       => 'rtl-css',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'rtl.css', 'benchmark' ),
                            'subtitle' => esc_html__( 'Force load rtl.css file', 'benchmark' ),
							'desc'		=> esc_html__( 'Enable this setting if you wish to use rtl.css on non RTL installation of WordPress', 'benchmark' ),
                            'default'  => false,
							'on'       => 'Enable',
							'off'      => 'Disable',
                        )*/
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'  	 => 'el el-credit-card',
                    'title'  	=> esc_html__( 'Top Bar', 'benchmark' ),
					'desc'   => esc_html__( 'Settings for the top utility bar.', 'benchmark' ),
                    'fields' => array(

                        array(
                            'id'       => 'top-bar-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Top Utility Bar', 'benchmark' ),
                            'subtitle' => esc_html__( 'Enable or disable top utility bar', 'benchmark' ),
                            'default'  => true,
                            'on'       => 'Enabled',
                            'off'      => 'Disabled',
                        ),

                        array(
                            'id'       => 'cb-text-left',
                            'type'     => 'textarea',
							'required' => array( 'top-bar-check', '=', '1' ),
                            'title'    => esc_html__( 'Left section text', 'benchmark' ),
                            'subtitle' => esc_html__( 'Place your custom HTML text for left callout section. HTML Allowed (wp_kses)', 'benchmark' ),
                            'validate' => 'html', //see http://codex.wordpress.org/Function_Reference/wp_kses_post
                            'default'  => '<ul class="icon-list-horz">
<li><i class="mdi mdi-mail"></i>contact@yoursite.com</li>
<li><i class="mdi mdi-call"></i>1800 180 29890</li>
</ul>'
                        ),

                        array(
                            'id'       => 'callout-right',
                            'type'     => 'select',
							'required' => array( 'top-bar-check', '=', '1' ),
                            'title'    => esc_html__( 'Show in right section', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose what to show in right section', 'benchmark' ),
                            'options'  => array(
                                'links' => 'Custom Navbar',
                                'text' => 'Custom Text'
                            ),
                            'default'  => 'links'
                        ),

                        array(
                            'id'       => 'cb-text-right',
                            'type'     => 'textarea',
							'required' => array( 'callout-right', '=', 'text' ),
                            'title'    => esc_html__( 'Right section text', 'benchmark' ),
                            'subtitle' => esc_html__( 'Place your custom HTML text for right callout section. HTML Allowed (wp_kses)', 'benchmark' ),
                            'validate' => 'html',
                            'default'  => 'Optional callout text.'
                        ),

                        array(
                            'id'       => 'cb-right-links',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array( 'callout-right', '=', 'links' ),
                            'title'    => esc_html__( 'Custom Navbar', 'benchmark' ),
                            'subtitle' => esc_html__( 'Build custom nav by enabling these options', 'benchmark' ),
                            'options'  => array(
                                '1' => 'Welcome Text',
                                '2' => 'Login / Register link',
                                '3' => 'Cart items - Totals',
								'4' => 'Language Switcher (requires WPML Plugin)',
								//'5' => 'Currency Switcher (BETA, requires WooCommerce and WC Multilinugal Plugin)',
                            ),
                            'default'  => array(
                                '1' => '1',
                                '2' => '1',
                                '3' => '0',
								'4' => '0',
								//'5' => '0'
                            )
                        )
                    )
                ) );

				Redux::setSection( $opt_name, array(
					'icon'  	 => 'el el-flag',
					'title'  	=> esc_html__( 'Header', 'benchmark' ),
					'desc'   => esc_html__( 'This section contains settings for header area.', 'benchmark' ),
					'fields' => array(

                        array(
                            'id'       => 'logo-check',
                            'type'     => 'select',
                            'title'    => esc_html__( 'Show site logo as', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose whether to show site logo as text or image', 'benchmark' ),
                            'options'  => array(
                                'image' => 'Image',
								'text' => 'Text'
							),
                            'default'  => 'image'
                        ),

                        array(
                            'id'       => 'logo-url',
                            'type'     => 'media',
							'required' => array( 'logo-check', "=", 'image' ),
                            'url'      => true,
                            'title'    => esc_html__( 'Logo URL', 'benchmark' ),
                            'compiler' => 'true',
                            'subtitle' => esc_html__( 'Upload your logo or choose an image from the media library. Recommended size: 96px x 56px', 'benchmark' ),
                            'default'  => array( 'url' => get_template_directory_uri() . '/images/logo.png' )
                        ),

                        array(
                            'id'       => 'logo-2x-url',
                            'type'     => 'media',
							'required' => array( 'logo-check', "=", 'image' ),
                            'url'      => true,
                            'title'    => esc_html__( 'Logo @2x URL', 'benchmark' ),
                            'compiler' => 'true',
                            'subtitle' => esc_html__( 'Upload high resolution logo or choose an image from the media library.  Recommended size: 192px x 112px', 'benchmark' ),
                            'default'  => array( 'url' => get_template_directory_uri() . '/images/logo@2x.png' ),
							'desc'   => esc_html__( 'If provided, this logo will be used in place of normal one.', 'benchmark' ),
                            'hint'      => array(
                                'title'     => 'Retina resolution logo',
                                'content'   => 'Provide a logo of 2x resolution. Ex. A 96 x 56 logo will become 192 x 112',
                            )
                        ),

                        array(
                            'id'       => 'logo-dark-url',
                            'type'     => 'media',
							'required' => array( 'logo-check', "=", 'image' ),
                            'url'      => true,
                            'title'    => esc_html__( 'Dark logo URL', 'benchmark' ),
                            'compiler' => 'true',
                            'subtitle' => esc_html__( 'Upload alternate logo for white color scheme. This logo will be shown on white background, so use a dark logo image.  Recommended size: 192px x 112px', 'benchmark' ),
                            'default'  => array( 'url' => get_template_directory_uri() . '/images/logo_dark@2x.png' ),
							'desc'   => esc_html__( 'If provided, this logo will be used for white color scheme.', 'benchmark' )
                        ),

						array(
							'id'       => 'logo-custom-url',
							'type'     => 'text',
							'required' => array( 'logo-check', "=", 'image' ),
							'title'    => esc_html__( 'Custom Logo URL', 'benchmark' ),
							'subtitle' => esc_html__( 'Use this field for providing custom logo URL outside of media library.', 'benchmark' ),
							'desc'     => esc_html__( 'You can provide custom URL or third party image link here.', 'benchmark' ),
							'validate' => 'url',
							'msg'      => esc_html__( 'URL is invalid.', 'benchmark' ),
							'default'  => ''
						),

						array(
							'id'       => 'logo-custom-url-dark',
							'type'     => 'text',
							'required' => array( 'logo-check', "=", 'image' ),
							'title'    => esc_html__( 'Custom Logo URL (Dark)', 'benchmark' ),
							'subtitle' => esc_html__( 'Use this field for providing custom logo URL for white color scheme.', 'benchmark' ),
							'desc'     => esc_html__( 'You can provide custom URL or third party image link here.', 'benchmark' ),
							'validate' => 'url',
							'msg'      => esc_html__( 'URL is invalid.', 'benchmark' ),
							'default'  => ''
						),

                        array(
                            'id'       => 'site-title',
                            'type'     => 'text',
							'required' => array( 'logo-check', "=", 'text' ),
                            'title'    => esc_html__( 'Site Title', 'benchmark' ),
                            'subtitle' => esc_html__( 'Provide a site name', 'benchmark' ),
                            'default'  => '<span>BENCH</span>MARK'
                        ),

                       array(
                            'id'       => 'navbar-type',
                            'type'     => 'select',
                            'title'    => esc_html__( 'Navbar type', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose a navbar type', 'benchmark' ),
                            'options'  => array(
                                'fixed' => 'Fixed',
                                'static' => 'Static'
                            ),
                            'default'  => 'fixed'
                        ),

                        array(
                            'id'       => 'woo-cart-widget',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Header cart widget', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide cart widget in header area', 'benchmark' ),
							'desc'		=> esc_html__( 'This feature requires WooCommerce Plugin.', 'benchmark' ),
                            'default'  => 0,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

						array(
                            'id'       => 'wishlist-count',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Wishlist counter', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide wishlist counter in header area', 'benchmark' ),
							'desc'		=> esc_html__( 'This feature requires WooCommerce and YITH Wishlist plugins.', 'benchmark' ),
                            'default'  => 0,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

						array(
                            'id'       => 'search-form',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Search Form', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide search form in header area', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

						array(
                            'id'       => 'search-form-type',
                            'type'     => 'select',
                            'title'    => esc_html__( 'Search form type', 'benchmark' ),
							'required' => array( 'search-form', "=", 1 ),
                            'subtitle' => esc_html__( 'Choose type of search form', 'benchmark' ),
                            'options'  => array(
                                'normal' => 'Normal Search',
                                'product' => 'Products Search'
                            ),
                            'default'  => 'normal'
                        ),

                        array(
                            'id'       => 'hero-check-pages',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Hero Section', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide hero area in all pages globally.', 'benchmark' ),
							'desc'     => esc_html__( 'Use this option for hiding hero section on all pages. This is the section after menu which shows page titles.', 'benchmark' ),
                            'default'  => true,
                            'on'       => 'Show',
                            'off'      => 'Hide',
                        ),

                        array(
                            'id'       => 'responsive-menu',
                            'type'     => 'select',
                            'title'    => esc_html__( 'Responsive Menu', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose a menu to be shown in responsive mobile version', 'benchmark' ),
                            'data'     => 'menu'
                        )
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-folder-open',
                    'title'  => esc_html__( 'Archives', 'benchmark' ),
					'desc'   => esc_html__( 'This section contains settings for archive, blog and portfolio templates.', 'benchmark' ),
                    'fields' => array(
                       array(
                            'id'       => 'archive-style',
                            'type'     => 'select',
                            'title'    => esc_html__( 'Global archive &amp; blog style', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose a template style for archives', 'benchmark' ),
                            'options'  => array(
								'grid' => 'Grid',
								'list'	=> 'List',
								'classic' => 'Classic'
                            ),
                            'default'  => 'grid'
                        ),

                        array(
                            'id'            => 'grid-columns',
                            'type'          => 'select',
							'required' => array( 'archive-style', "=", 'grid' ),
                            'title'         => esc_html__( 'Grid columns', 'benchmark' ),
                            'subtitle'      => esc_html__( 'Choose number of columns for grid template', 'benchmark' ),
                            'options'  => array(
                                '2' => '2',
                                '3' => '3',
								'4' => '4'
                            ),
                            'default'  => '2',
                            'hint'     => array(
                                //'title'     => '',
                                'content' => esc_html__( 'Grid style archives will show number of columns as specified in this setting.', 'benchmark' )
                            )
                        ),

                       array(
                            'id'       => 'classic-content-check',
                            'type'     => 'select',
							'required' => array( 'archive-style', "=", 'classic' ),
                            'title'    => esc_html__( 'Classic blog content style', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose what to show in classic style templates', 'benchmark' ),
                            'options'  => array(
                                'content' => 'Full content',
                                'excerpt' => 'Short excerpt'
                            ),
                            'default'  => 'excerpt'
                        ),

                        array(
                            'id'       => 'excerpt-length-grid',
                            'type'     => 'text',
							'required' => array( 'archive-style', "=", 'grid' ),
                            'title'    => esc_html__( 'Grid style excerpt length', 'benchmark' ),
                            'subtitle' => esc_html__( 'The numeric word length for excerpt', 'benchmark' ),
                            'validate' => 'numeric',
                            'default'  => '15',
                            'hint'      => array(
                                'content'   => esc_html__( 'This excerpt length will apply to all grid style templates. Max allowed limit is 55 words.', 'benchmark' ),
                            )
                        ),

                        array(
                            'id'       => 'excerpt-length-list',
                            'type'     => 'text',
							'required' => array( 'archive-style', "=", 'list' ),
                            'title'    => esc_html__( 'List style excerpt length', 'benchmark' ),
                            'subtitle' => esc_html__( 'The numeric word length for excerpt', 'benchmark' ),
                            'validate' => 'numeric',
                            'default'  => '55',
                            'hint'      => array(
                                'content'   => esc_html__( 'This excerpt length will apply to all list style templates. Max allowed limit is 55 words.', 'benchmark' ),
                            )
                        ),

                        array(
                            'id'       => 'excerpt-length-classic',
                            'type'     => 'text',
                            'required' => array(
                                array( 'archive-style', "=", 'classic' ),
                                array( 'classic-content-check', '=', 'excerpt' ),
                            ),
                            'title'    => esc_html__( 'List style excerpt length', 'benchmark' ),
                            'subtitle' => esc_html__( 'The numeric word length for excerpt', 'benchmark' ),
                            'validate' => 'numeric',
                            'default'  => '55',
                            'hint'      => array(
                                'content'   => esc_html__( 'This excerpt length will apply to classic style templates when chosen to show excerpt. Max allowed limit is 55 words.', 'benchmark' ),
                            )
                        ),

                        array(
                            'id'       => 'masonry-check',
                            'type'     => 'switch',
							'required' => array( 'archive-style', "=", 'grid' ),
                            'title'    => esc_html__( 'Masonry', 'benchmark' ),
                            'subtitle' => esc_html__( 'Enable or disable masonry', 'benchmark' ),
							'desc'	   => esc_html__( 'This setting will apply to grid style archives.', 'benchmark' ),
                            'default'  => 1,
                            'hint'      => array(
                                'title'     => 'What is it?',
                                'content'   => 'Masonry is a brick style layout in which all grids float to fill available space. It is used in grid style templates in this theme.',
                            )
                        ),

                        array(
                            'id'       => 'meta-links',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array( 'single-meta-check', "=", '1' ),
                            'title'    => esc_html__( 'Single post meta items', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select and reorder post meta items. These will be shown on single posts.', 'benchmark' ),
                            'desc'     => esc_html__( 'Drag the buttons up or down to reorder them.', 'benchmark' ),
                            'options'  => array(
                                'date' => 'Post date',
                                'author' => 'Author',
                                'cats' => 'Categories',
								'tags' => 'Tags',
								'comments' => 'Comment count',
								'edit' => 'Edit Link'
                            ),
							'default'  => array(
                                'date' => '1',
                                'author' => '1',
                                'cats' => '1',
								'tags' => '1',
								'comments' => '1',
								'edit'  => '1'
                            )
                        ),

                        array(
                            'id'       => 'archive-meta-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Archive Post Meta', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide post meta on archives', 'benchmark' ),
							'desc'	   => esc_html__( 'This setting will apply to archives. (Not to widgets and shortcodes).', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                       array(
                            'id'       => 'meta-links-grid',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array(
								array( 'archive-style', "=", 'grid' ),
								array( 'archive-meta-check', "=", '1')
							 ),
                            'title'    => esc_html__( 'Grid archive meta items', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select and re order grid post meta items. These will be shown in grid style archives.', 'benchmark' ),
                            'desc'     => esc_html__( 'Drag the buttons up or down to re order them.', 'benchmark' ),
                            'options'  => array(
                                'date' => 'Post date',
								'cats' => 'Categories',
                                'author' => 'Author'

                            ),
							'default'  => array(
                                'date' => '1',
								'cats' => '1',
                                'author' => '0'
                            )
                        ),

                        array(
                            'id'       => 'meta-links-list',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array(
								array('archive-style', "!=", 'grid'),
								array('archive-meta-check', "=", '1')
							 ),
                            'title'    => esc_html__( 'List/Classic archive meta items', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select and re order list post meta items. These will be shown in list and classic style archives.', 'benchmark' ),
                            'desc'     => esc_html__( 'Drag the buttons up or down to re order them.', 'benchmark' ),
                            'options'  => array(
                                'date' => 'Post date',
                                'author' => 'Author',
                                'cats' => 'Categories',
								'comments' => 'Comment count',
								'morelink' => 'Read more'
                            ),
							'default'  => array(
                                'date' => '1',
                                'author' => '0',
                                'cats' => '1',
								'comments' => '1',
								'morelink' => '1'
                            )
                        ),

                        array(
                            'id'       => 'meta-links-port',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array( 'archive-meta-check', "=", '1' ),
                            'title'    => esc_html__( 'Portfolio meta items', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select and reorder portfolio meta items', 'benchmark' ),
                            'desc'     => esc_html__( 'These meta items will appear on portfolio grid items.', 'benchmark' ),
                            'options'  => array(
                                'date' => 'Post date',
                                'author' => 'Author',
                                'cats' => 'Categories',
								'comments' => 'Comment count',
								'morelink' => 'Read more'
                            ),
							'default'  => array(
                                'date' => '1',
                                'author' => '0',
                                'cats' => '0',
								'comments' => '0',
								'morelink' => '1'
                            )
                        ),

                        array(
                            'id'       => 'hero-check-archives',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Hero area in archives', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide hero section in archives.', 'benchmark' ),
							'desc'     => esc_html__( 'Use this option for globally hiding hero section on archives. This section shows archive title after menu area.', 'benchmark' ),
                            'default'  => true,
                            'on'       => 'Show',
                            'off'      => 'Hide',
                        ),

                        array(
                            'id'       => 'archive-sb-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Sidebar on archives', 'benchmark' ),
                            'subtitle' => esc_html__( 'Enable or disable sidebar on archives', 'benchmark' ),
                            'default'  => true,
                            'on'       => 'Show',
                            'off'      => 'Hide',
                        ),

                        array(
                            'id'       => 'archive-video-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Video embed in archives', 'benchmark' ),
                            'subtitle' => esc_html__( 'Enable or disable video embed in archive', 'benchmark' ),
							'desc'     => esc_html__( 'If enabled, an inline video embed will be shown in place of thumbnail in archives.', 'benchmark' ),
                            'default'  => false,
                            'on'       => 'Show',
                            'off'      => 'Hide',
                        ),
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-file',
                    'title'  => esc_html__( 'Single Post', 'benchmark' ),
					'heading' => esc_html__( 'Single Post Settings', 'benchmark' ),
					'desc'   => esc_html__( 'This section contains settings for single posts', 'benchmark' ),
                    'fields' => array(

						array(
                            'id'       => 'single-sb-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Sidebar on single post', 'benchmark' ),
                            'subtitle' => esc_html__( 'Enable or disable sidebar on single post', 'benchmark' ),
                            'default'  => true,
                            'on'       => 'Show',
                            'off'      => 'Hide',
                        ),

                        array(
                            'id'       => 'author-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Author Bio', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide author bio', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                        array(
                            'id'       => 'feat-image-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Featured image', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide featured image', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                            'hint'      => array(
                                'content'   => esc_html__( 'Enable or disable automatic insertion of featured images on single posts.', 'benchmark' ),
                            )
                        ),

                        array(
                            'id'       => 'rp-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Related Posts', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide related posts', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                       array(
                            'id'       => 'rp-taxonomy',
                            'type'     => 'select',
							'required' => array( 'rp-check', "=", '1' ),
                            'title'    => esc_html__( 'Related posts taxonomy', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose a taxonomy criteria for showing related posts', 'benchmark' ),
                            'options'  => array(
                                '0' => 'Category',
                                '1' => 'Tags'
                            ),
                            'default'  => '0'
                        ),

                       array(
                            'id'       => 'rp-style',
                            'type'     => 'select',
							'required' => array( 'rp-check', "=", '1' ),
                            'title'    => esc_html__( 'Related posts display style', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose a display style for related posts', 'benchmark' ),
                            'options'  => array(
                                'thumbnail' => 'Thumbnail Grid',
                                'plain' => 'Plain List'
                            ),
                            'default'  => 'thumbnail'
                        ),

                        array(
                            'id'       => 'rp-num',
                            'type'     => 'text',
							'required' => array( 'rp-check', "=", '1' ),
                            'title'    => esc_html__( 'Number or related posts', 'benchmark' ),
                            'subtitle' => esc_html__( 'How many related posts to show', 'benchmark' ),
                            'validate' => 'numeric',
                            'default'  => '2'
                        ),


                        array(
                            'id'       => 'single-meta-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Single Post Meta', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide post meta on single posts', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                        array(
                            'id'       => 'single-nav-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Post Navigation', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide post navigation links.', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                        array(
                            'id'       => 'sharing-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Sharing Buttons', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide sharing buttons', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                        array(
                            'id'       => 'sharing-buttons',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array( 'sharing-check', "=", '1' ),
                            'title'    => esc_html__( 'Social Sharing Buttons', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose and reorder the buttons as required.', 'benchmark' ),
                            'desc'     => esc_html__( 'Drag the buttons up or down to reorder them.', 'benchmark' ),
                            'options'  => array(
                                '1' => 'Twitter',
                                '2' => 'Facebook',
                                '3' => 'LinkedIn',
								'4' => 'Google Plus',
								'5' => 'Pinterest',
								'6' => 'VK',
								'7' => 'Email',
								'8' => 'Print',
								'9' => 'Reddit'
                            ),
							'default'  => array(
                                '1' => '1',
                                '2' => '1',
                                '3' => '1',
								'4' => '1',
								'5' => '1',
								'6' => '1',
								'7' => '1',
								'8' => '1',
								'9' => '1'
                            )
                        )
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-th-large',
                    'title'  => esc_html__( 'Widget Areas', 'benchmark' ),
					'desc'	 => esc_html__( 'This section contains settings for all available widget areas.', 'benchmark' ),
                    'fields' => array(

						array(
							'id'       => 'pwa-check',
							'type'     => 'switch',
							'title'    => esc_html__( 'Primary widget area', 'benchmark' ),
							'subtitle' => esc_html__( 'Show or hide primary widget area.', 'benchmark' ),
							'desc'	 => esc_html__( 'This widget area is located before content + sidebar section, just after the header.', 'benchmark' ),
							'default'  => false,
							'on'       => 'Show',
							'off'      => 'Hide',
						),

						array(
							'id'       => 'pwa-columns',
							'type'     => 'select',
							'required' => array( 'pwa-check', "=", true ),
							'title'    => esc_html__( 'Choose columns', 'benchmark' ),
							'subtitle' => esc_html__( 'Choose number of columns to be shown in top widget area.', 'benchmark' ),
							'options'  => array(
								'1' => '1',
								'2' => '2',
								'3' => '3',
								'4' => '4',
								'6' => '6'
							),
							'default'  => '3',
							'hint'     => array(
								'content' => esc_html__( 'Depending upon number of columns, widgets will be divided in appropriate widths.', 'benchmark' )
							)
						),

						array(
							'id'       => 'cwa-a-check',
							'type'     => 'switch',
							'title'    => esc_html__( 'Content widget area A', 'benchmark' ),
							'subtitle' => esc_html__( 'Show or hide content widget area A.', 'benchmark' ),
							'desc'	 => esc_html__( 'This widget area is located before post content section. Applicable only on single posts.', 'benchmark' ),
							'default'  => false,
							'on'       => 'Show',
							'off'      => 'Hide',
						),

						array(
							'id'       => 'cwa-a-columns',
							'type'     => 'select',
							'required' => array( 'cwa-a-check', "=", true ),
							'title'    => esc_html__( 'Choose columns', 'benchmark' ),
							'subtitle' => esc_html__( 'Choose number of columns to be shown in Content widget area A.', 'benchmark' ),
							'options'  => array(
								'1' => '1',
								'2' => '2',
								'3' => '3',
								'4' => '4'
							),
							'default'  => '1',
							'hint'     => array(
								'content' => esc_html__( 'Depending upon number of columns, widgets will be divided in appropriate widths.', 'benchmark' )
							)
						),

						array(
							'id'       => 'cwa-b-check',
							'type'     => 'switch',
							'title'    => esc_html__( 'Content widget area B', 'benchmark' ),
							'subtitle' => esc_html__( 'Show or hide content widget area B.', 'benchmark' ),
							'desc'	 => esc_html__( 'This widget area is located after post content section. Applicable only on single posts.', 'benchmark' ),
							'default'  => false,
							'on'       => 'Show',
							'off'      => 'Hide',
						),

						array(
							'id'       => 'cwa-b-columns',
							'type'     => 'select',
							'required' => array( 'cwa-b-check', "=", true ),
							'title'    => esc_html__( 'Choose columns', 'benchmark' ),
							'subtitle' => esc_html__( 'Choose number of columns to be shown in Content widget area B.', 'benchmark' ),
							'options'  => array(
								'1' => '1',
								'2' => '2',
								'3' => '3',
								'4' => '4'
							),
							'default'  => '1',
							'hint'     => array(
								'content' => esc_html__( 'Depending upon number of columns, widgets will be divided in appropriate widths.', 'benchmark' )
							)
						),

						array(
							'id'       => 'swa-a-check',
							'type'     => 'switch',
							'title'    => esc_html__( 'Secondary Widget Area A', 'benchmark' ),
							'subtitle' => esc_html__( 'Show or hide secondary widget area A', 'benchmark' ),
							'desc'	 => esc_html__( 'This widget area is located after content section and sidebar.', 'benchmark' ),
							'default'  => true,
							'on'       => 'Show',
							'off'      => 'Hide',
						),

						array(
							'id'       => 'sec-a-columns',
							'type'     => 'select',
							'required' => array( 'swa-a-check', "=", true ),
							'title'    => esc_html__( 'Choose columns', 'benchmark' ),
							'subtitle' => esc_html__( 'Choose number of columns to be shown in secondary widget area A.', 'benchmark' ),
							'options'  => array(
								'1' => '1',
								'2' => '2',
								'3' => '3',
								'4' => '4',
								'6' => '6'

							),
							'default'  => '4',
							'hint'     => array(
								'content' => esc_html__( 'Depending upon number of columns, widgets will be divided in appropriate widths.', 'benchmark' )
							)
						),

						array(
							'id'       => 'swa-b-check',
							'type'     => 'switch',
							'title'    => esc_html__( 'Secondary Widget Area B', 'benchmark' ),
							'subtitle' => esc_html__( 'Show or hide secondary widget area B', 'benchmark' ),
							'desc'	 => esc_html__( 'This widget area is located before the footer section.', 'benchmark' ),
							'default'  => false,
							'on'       => 'Show',
							'off'      => 'Hide',
						),

						array(
							'id'       => 'sec-b-columns',
							'type'     => 'select',
							'required' => array( 'swa-b-check', "=", true ),
							'title'    => esc_html__( 'Choose columns', 'benchmark' ),
							'subtitle' => esc_html__( 'Choose number of columns to be shown in secondary widget area B.', 'benchmark' ),
							'options'  => array(
								'1' => '1',
								'2' => '2',
								'3' => '3',
								'4' => '4',
								'6' => '6'

							),
							'default'  => '4'
						)
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-briefcase',
                    'title'  => esc_html__( 'Footer', 'benchmark' ),
					'desc'	 => esc_html__( 'This section contains settings for the footer area.', 'benchmark' ),
                    'fields' => array(

                        array(
                            'id'       => 'footer-text',
                            'type'     => 'editor',
                            'title'    => esc_html__( 'Footer Text', 'benchmark' ),
                            'subtitle' => esc_html__( 'Custom footer notes here', 'benchmark' ),
							'desc' 	   => esc_html__( 'You can use shortcodes like [ss_current_year], [ss_site_title], [ss_site_url], etc.', 'benchmark' ),
                            'default'  => '&copy 2016 Benchmark. All rights reserved.',
                        ),
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-picture',
                    'title'  => esc_html__( 'Image Sizes', 'benchmark' ),
					'desc'   => esc_html__( 'This section contains global image size settings for archives and widgets. You can override these image settings for blog/portfolio templates inside individual page options panel when editing the page.', 'benchmark' ),

					'fields' => array(

						array(
							'id'       => 'grid-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Blog Grid', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for grid template images.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '640',
								'height'  => '360',
							)
						),

						array(
							'id'       => 'grid-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '1',
								'2' => '1'
							)
						),

						array(
							'id'       => 'list-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Blog List', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for list style template images.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '640',
								'height'  => '640',
							)
						),

						array(
							'id'       => 'list-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '1',
								'2' => '1'
							)
						),

						array(
							'id'       => 'classic-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Blog Classic', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for classic style template images.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '800',
								'height'  => '450',
							)
						),

						array(
							'id'       => 'classic-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '1',
								'2' => '1'
							)
						),

						array(
							'id'       => 'port-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Portfolio Templates', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for portfolio template images.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '480',
								'height'  => '',
							)
						),

						array(
							'id'       => 'port-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '0',
								'2' => '0'
							)
						),

						array(
							'id'       => 'single-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Single Post', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for single post featured image.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '800',
								'height'  => '',
							)
						),

						array(
							'id'       => 'single-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '0',
								'2' => '0'
							)
						),

						array(
							'id'       => 'related-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Related Posts', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for related post thumbnails.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '640',
								'height'  => '360',
							)
						),

						array(
							'id'       => 'related-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '1',
								'2' => '1'
							)
						)
					)
				) );

                Redux::setSection( $opt_name, array(
                    'icon'   => 'el el-shopping-cart',
                    'title'  => esc_html__( 'WooCommerce', 'benchmark' ),
					'desc'   => esc_html__( 'This section contains custom settings for WooCommerce. You can configure other main settings inside WooCommerce plugin\'s Settings.', 'benchmark' ),
                    'fields' => array(
                        array(
                            'id'            => 'shop-columns',
                            'type'          => 'select',
                            'title'         => esc_html__( 'Shop columns', 'benchmark' ),
                            'subtitle'      => esc_html__( 'Choose number of columns in shop', 'benchmark' ),
                            'options'  => array(
                                '2' => '2',
                                '3' => '3',
								'4' => '4'
                            ),
                            'default'  => '3',
                            'hint'     => array(
                                //'title'     => '',
                                'content' => esc_html__( 'The shop page and product archives will show products in number of columns as specified here.', 'benchmark' )
                            )
                        ),

						array(
							'id'       => 'catalog-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Shop Product Image Size', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for shop product thumbnails.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '400',
								'height'  => '400',
							)
						),

						array(
							'id'       => 'catalog-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Shop images crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '1',
								'2' => '1'
							)
						),

						array(
							'id'       => 'shop-cat-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Shop Category Image Size', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for shop category thumbnails.', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '400',
								'height'  => '400',
							)
						),

						array(
							'id'       => 'shop-cat-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Shop images crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '1',
								'2' => '1'
							)
						),

						array(
							'id'       => 'single-product-images',
							'type'     => 'dimensions',
							'units'    => false,
							'title'    => esc_html__( 'Single Product Image Size', 'benchmark' ),
							'subtitle' => esc_html__( 'Width and height for single product image', 'benchmark' ),
							'desc'     => esc_html__( 'The sizes are in px. Provide numeric values without unit.', 'benchmark' ),
							'default'  => array(
								'width'   => '600',
								'height'  => '',
							)
						),

						array(
							'id'       => 'single-product-misc',
							'type'     => 'checkbox',
							'title'    => false,
							'subtitle' => esc_html__('Single product image crop and upscale options', 'benchmark'),

							//Must provide key => value pairs for multi checkbox options
							'options'  => array(
								'1' => 'Force Crop',
								'2' => 'Force Upscale'
							),

							//See how default has changed? you also don't need to specify opts that are 0.
							'default' => array(
								'1' => '0',
								'2' => '0'
							)
						),

                        array(
                            'id'       => 'shop-sb-pos',
                            'type'     => 'image_select',
                            'title'    => esc_html__( 'Shop sidebar placement', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select a sidebar placement for shop', 'benchmark' ),
                            'options'  => array(
                                'left' => array(
									'title' => 'Left',
                                    'alt' => '2 Column Left',
                                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                                ),
                                'right' => array(
									'title' => 'Right',
                                    'alt' => '2 Column Right',
                                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                                )
                            ),
                            'default'  => 'left',
                            'hint'     => array(
                                'content' => esc_html__( 'This setting will apply to shop and product archives.', 'benchmark' )
                            )
                        ),

                        array(
                            'id'       => 'product-sb-pos',
                            'type'     => 'image_select',
                            'title'    => esc_html__( 'Single product sidebar placement', 'benchmark' ),
                            'subtitle' => esc_html__( 'Select a sidebar placement for single product', 'benchmark' ),
                            'options'  => array(
                                'left' => array(
									'title' => 'Left',
                                    'alt' => '2 Column Left',
                                    'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                                ),
                                'right' => array(
									'title' => 'Right',
                                    'alt' => '2 Column Right',
                                    'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                                )
                            ),
                            'default'  => 'left',
                            'hint'     => array(
                                'content' => esc_html__( 'This setting will apply to single product pages', 'benchmark' )
                            )
                        ),

                        array(
                            'id'       => 'woo-sb-check',
                            'type'     => 'checkbox',
                            'title'    => esc_html__( 'Hide WooCommerce sidebar on', 'benchmark' ),
                            'subtitle' => esc_html__( 'Hide WooCommerce sidebar on following pages', 'benchmark' ),
							'desc'     => esc_html__( 'For pages like cart, my-account, checkout, etc. kindly use page option setting for hiding sidebar.', 'benchmark' ),
                            //Must provide key => value pairs for multi checkbox options
                            'options'  => array(
                                'shop' => 'Shop / Archives',
                                'single' => 'Single Product'
                            ),
                            //See how std has changed? you also don't need to specify opts that are 0.
                            'default'  => array(
                                'shop' => '0',
                                'single' => '0'
                            )
                        ),

                        array(
                            'id'       => 'woo-sharing-check',
                            'type'     => 'switch',
                            'title'    => esc_html__( 'Product Sharing Buttons', 'benchmark' ),
                            'subtitle' => esc_html__( 'Show or hide sharing buttons', 'benchmark' ),
                            'default'  => 1,
                            'on'       => 'Show',
                            'off'      => 'hide',
                        ),

                        array(
                            'id'       => 'woo-sharing-buttons',
                            'type'     => 'sortable',
                            'mode'     => 'checkbox', // checkbox or text
							'required' => array( 'sharing-check', "=", '1' ),
                            'title'    => esc_html__( 'Choose sharing buttons', 'benchmark' ),
                            'subtitle' => esc_html__( 'Choose and reorder the buttons as required.', 'benchmark' ),
                            'desc'     => esc_html__( 'Drag the buttons up or down to reorder them.', 'benchmark' ),
                            'options'  => array(
                                '1' => 'Twitter',
                                '2' => 'Facebook',
                                '3' => 'LinkedIn',
								'4' => 'Google Plus',
								'5' => 'Pinterest',
								'6' => 'VK',
								'7' => 'Email',
								'8' => 'Print',
								'9' => 'Reddit'
                            ),
							'default'  => array(
                                '1' => '1',
                                '2' => '1',
                                '3' => '0',
								'4' => '0',
								'5' => '0',
								'6' => '0',
								'7' => '1',
								'8' => '1',
								'9' => '0'
                            )
                        )
					)
				) );

				Redux::setSection( $opt_name, array(
					'icon'		=> 'el el-fontsize',
					'title'		=> esc_html__( 'Typography', 'benchmark' ),
					'fields'	=> array(
						array(
                            'id'          => 'body-fonts',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Body Copy', 'benchmark' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => true,
                            'output'      => array( 'html' ),
                            'units'       => 'px',
							'text-align'  => false,
							//'line-height' => false,
							'color' 	=> false,

                            'subtitle'    => esc_html__( 'Set body copy font using these settings.', 'benchmark' ),
                            'default'     => array(
									'font-weight'  => '400',
									'font-family' => 'Roboto',
									'google'      => false,
									'font-size'   => '14px',
									'line-height' => '24px'
							)
						),

						array(
                            'id'          => 'heading-fonts',
                            'type'        => 'typography',
                            'title'       => esc_html__( 'Headings', 'benchmark' ),
                            'google'      => true,
                            'font-backup' => true,
                            'all_styles'  => true,
                            'output'      => array( 'h1,h2,h3,h4,h5,h6' ),
                            'units'       => 'px',
							'text-align'  => false,
							'font-size'   => false,
							'line-height'  => false,
							'color'			=> false,

                            'subtitle'    => esc_html__( 'Set heading font style and colors', 'benchmark' ),
                            'default'     => array(
									'font-weight'  => '400',
									'font-family' => 'Roboto',
									'google'      => false
							)
						),
					)
				) );

    /*
     * <--- END SECTIONS
     */


    /**
	 * Action hook examples
     *
     */

    // If Redux is running as a plugin, this will remove the demo notice and links
    add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');


    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    function dynamic_section( $sections ) {
        //$sections = array();
        $sections[] = array(
            'title'  => esc_html__( 'Section via hook', 'benchmark' ),
            'desc'   => esc_html__( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'benchmark' ),
            'icon'   => 'el el-paper-clip',
            // Leave this as a blank section, no options just some intro text set above.
            'fields' => array()
        );

        return $sections;
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    function change_arguments( $args ) {
        //$args['dev_mode'] = true;

        return $args;
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    function change_defaults( $defaults ) {
        $defaults['str_replace'] = 'Testing filter hook!';

        return $defaults;
    }

    // Remove the demo link and the notice of integrated demo from the redux-framework plugin
    function remove_demo() {

        // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
        if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
            remove_filter( 'plugin_row_meta', array(
                ReduxFrameworkPlugin::instance(),
                'plugin_metalinks'
            ), null, 2 );

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
        }
    }