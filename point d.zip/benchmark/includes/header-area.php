<?php
/**
 * Header area
 * Contains logo and header icons
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();
$hide_main_nav = '';
$header_callout_text = '';
$hide_header_icons = false;

if ( is_page() ) {
	global $post;

	// Fetch page options for per page header area settings
	$page_opts 				= get_post_meta( $post->ID, 'bmrk_page_opts', true );
	$custom_menu 			= isset( $page_opts[ 'custom_menu' ] ) ? $page_opts[ 'custom_menu' ] : false;
	$one_page_menu 			= isset( $page_opts[ 'one_page_menu' ] ) ? $page_opts[ 'one_page_menu' ] : false;
	$hide_header_icons 		= isset( $page_opts[ 'hide_header_icons' ] ) ? $page_opts[ 'hide_header_icons' ] : false;
	$hide_main_nav 			= isset( $page_opts[ 'hide_main_nav' ] ) ? $page_opts[ 'hide_main_nav' ] : false;
	$header_callout_text 	= ! empty( $page_opts[ 'header_callout_text' ] ) ? $page_opts[ 'header_callout_text' ] : '';
}
?>
<div class="header-main">
    <div class="container clearfix">
        <div class="row">

            <?php benchmark_menu_button(); ?>

            <div class="brand">
                <?php benchmark_logo(); ?>
            </div><!-- /.col-sm-3 -->

            <div class="menu-area clearfix<?php if ( ( ! $bmrk_opts[ 'woo-cart-widget' ] && ! $bmrk_opts[ 'wishlist-count' ] && ! $bmrk_opts[ 'search-form' ] ) || ( is_page() && $hide_header_icons ) ) echo ' expand-full'; ?>">

			<?php if ( ! $hide_main_nav ) { ?>
                    <nav id="main-nav" class="primary-nav">
                        <?php $menu_args = array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu clearfix', 'container' => false, 'fallback_cb' => 'benchmark_menu_fallback' );

                       	if ( is_page() ) {
                            if ( $custom_menu && $custom_menu !== 'none' ) {
                                $menu_args['menu'] = $custom_menu;
                                $menu_args['theme_location'] = '';
                            }

                            if ( $one_page_menu && has_nav_menu( 'primary' ) || ( $one_page_menu && $custom_menu && $custom_menu !== 'none' ) ) {
                                $menu_args['menu_class'] = 'one-page-menu nav-menu clearfix';
                            }

                            wp_nav_menu( $menu_args );
                        }

                        else {
                            wp_nav_menu( $menu_args );
                        }
                        ?>
                    </nav><!-- /#main-nav -->

				<?php } // Hide main nav

				if ( is_page() && $hide_main_nav && '' !== $header_callout_text ) { ?>

                	<div class="header-callout-text<?php if ( $hide_header_icons ) echo ' float-right'; ?>">
						<?php echo do_shortcode( stripslashes( $header_callout_text ) ); ?>
                    </div><!-- /.header-callout-text -->

				<?php
                }

				if ( is_page() ) {
					if ( ! $hide_header_icons && ( $bmrk_opts[ 'woo-cart-widget' ] || $bmrk_opts[ 'wishlist-count' ] || $bmrk_opts[ 'search-form' ] ) ) { ?>
						<div class="header-icons">
							<?php do_action( 'benchmark_header_icons' ); ?>
						</div><!-- /.header-menu-icons -->
					<?php }
				}
				else {
					if ( $bmrk_opts[ 'woo-cart-widget' ] || $bmrk_opts[ 'wishlist-count' ] || $bmrk_opts[ 'search-form' ] ) { ?>
						<div class="header-icons">
						<?php do_action( 'benchmark_header_icons' ); ?>
						</div><!-- /.header-menu-icons -->
					<?php }
				} ?>
            </div><!-- /.menu-area -->
        </div><!-- /.row -->
    </div><!-- /.container -->
    <?php if ( $bmrk_opts[ 'search-form' ] ) {
		if ( ! $hide_header_icons ) {
			do_action( 'benchmark_search_panel' );
		}
	} ?>
</div><!-- /.header-main -->