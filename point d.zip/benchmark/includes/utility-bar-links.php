<?php
/**
 * utility links
 * WooCommerce login links, WPML Language bar and WCML price switcher
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

echo '<ul class="utility-nav">';
foreach ( $bmrk_opts[ 'cb-right-links' ] as $key=>$value ) {

    switch( $key ) {

        case '1':
			if ( $bmrk_opts[ 'cb-right-links' ][ '1' ] ) : ?>
				<li class="welcome">
				<?php if ( is_user_logged_in() ) {
						$current_user = wp_get_current_user();
						
						if ( ! ( $current_user instanceof WP_User ) )
							return;
						
						if ( $current_user->user_firstname ) {
							printf( '<i class="mdi mdi-person"></i>%s', sprintf( esc_html__( 'Welcome, %s', 'benchmark' ), $current_user->user_firstname ) );
						}
						
						elseif ( $current_user->display_name ) {
							printf( '<i class="mdi mdi-person"></i>%s', sprintf( esc_html__( 'Welcome, %s', 'benchmark' ), $current_user->display_name ) );
						}
						
						else {
							printf( '<i class="mdi mdi-person"></i>%s', sprintf( esc_html__( 'Welcome, %s', 'benchmark' ), $current_user->user_login ) );
						}
					}
					
					else {
						printf( '<i class="mdi mdi-person"></i>%s', esc_html__( 'Welcome, Guest', 'benchmark' ) );
					}
					?>
				</li>
			<?php endif;
        break;

        case '2':

			if ( $bmrk_opts[ 'cb-right-links' ][ '2' ] ) : ?>

                <li class="login-register">
					<?php
                    if ( is_user_logged_in() ) { ?>
                        <a class="log-out" href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" title="<?php esc_attr_e( 'Log out of your account', 'benchmark' ); ?>"><?php printf( '<i class="mdi mdi-lock_outline"></i>%s', esc_html__( 'Logout', 'benchmark' ) ); ?></a>
                    <?php }
                    else {
						if ( class_exists( 'woocommerce' ) ) { ?>
                        <a class="log-in" href="<?php echo esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ); ?>" title="<?php esc_attr_e( 'Login or register for a new account', 'benchmark' ); ?>"><?php printf( '<i class="mdi mdi-lock_open"></i>%s', esc_html__( 'Login / Register', 'benchmark' ) ); ?></a>
                        <?php }
						else {
						?>
                        <a class="log-in" href="<?php echo esc_url( home_url( '/' ) ) . 'wp-login.php?action=register'; ?>" title="<?php esc_attr_e( 'Login or register for a new account', 'benchmark' ); ?>"><?php printf( '<i class="mdi mdi-lock_open"></i>%s', esc_html__( 'Login / Register', 'benchmark' ) ); ?></a>
                    <?php }
					} ?>
                </li>

			<?php endif;

        break;

		case '3':

			if ( $bmrk_opts[ 'cb-right-links' ][ '3' ] ) :

				if ( class_exists( 'woocommerce' ) ) {
					global $woocommerce; ?>
					<li class="cart-status"><a class="cart-contents" href="<?php echo esc_url( $woocommerce->cart->get_cart_url() ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'benchmark' ); ?>"><i class="mdi mdi-shopping_cart"></i><?php echo sprintf( _n( '%d item - ', '%d items - ', $woocommerce->cart->cart_contents_count, 'benchmark' ), $woocommerce->cart->cart_contents_count); echo $woocommerce->cart->get_cart_subtotal(); ?></a></li>
			<?php }
			endif;

		break;

		case '4':

			if ( $bmrk_opts[ 'cb-right-links' ][ '4' ] ) :
				if ( function_exists( 'icl_language_selector' ) ) : ?>
					<li class="lang-switcher">
						<?php do_action( 'icl_language_selector' ); ?>
					</li><!-- .lang-switcher -->
				<?php endif;
			endif;

		break;

		case '5';

			if ( $bmrk_opts[ 'cb-right-links' ][ '5' ] ) :
				if ( class_exists( 'woocommerce_wpml' ) ) : ?>
					<li class="currency-switcher">
						<?php do_action( 'currency_switcher', array( 'switcher_style' => 'dropdown', 'format' => '%name% (%symbol%)' ) ); ?>
					</li><!-- .currency-switcher -->
				<?php endif;
			endif;
		break;
    }
}

do_action( 'benchmark_utility_links' );

echo '</ul>';