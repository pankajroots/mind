<?php
/**
 * hero-area.php
 *
 * Used for displaying page titles and archive titles.
 */

global $posts;

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

	if ( is_page() && $bmrk_opts[ 'hero-check-pages' ] ) {

		// Fetch page options for per page header area settings

		$page_opts 			= get_post_meta( $posts[0]->ID, 'bmrk_page_opts', true );
		$page_title 		= isset( $page_opts[ 'page_title' ] ) ? $page_opts[ 'page_title' ] : '';
		$hide_title 		= isset( $page_opts[ 'hide_title' ] ) ? $page_opts[ 'hide_title' ] : '';
		$hide_hero 			= isset( $page_opts[ 'hide_hero' ] ) ? $page_opts[ 'hide_hero' ] : '';

        if ( ! $hide_hero ) : ?>
            <div id="hero-area" class="hero-area">
                <div class="container clearfix">
                <?php if ( benchmark_archive_title() && ! is_single() && ! $hide_title && ! ( is_post_type_archive( 'product' )/* || is_tax( get_object_taxonomies( 'product' ) )*/ ) ) { ?>
                    <h1 class="page-title"><?php
                    if ( '' != $page_title ) {
						echo $page_title;
					}
					else {
						echo benchmark_archive_title();
					}
					?></h1>
                <?php } ?>
                </div><!-- /.container -->
            </div><!-- /.hero-area -->
        <?php endif;
	}

	elseif ( apply_filters( 'benchmark_hero_check_archives', $bmrk_opts[ 'hero-check-archives' ] ) && benchmark_archive_title() && ! is_page() && ! is_single() ) {
 ?>
        <div id="hero-area" class="hero-area">
            <div class="container clearfix">
                <h1 class="page-title"><?php
					if ( class_exists( 'woocommerce' ) && ( is_post_type_archive( 'product' ) || is_tax( get_object_taxonomies( 'product' ) ) ) ) {
						woocommerce_page_title();
					}
					else {
						echo benchmark_archive_title();
					} ?>
                </h1>
            </div><!-- /.container -->
        </div><!-- /.hero-area -->
        <?php
	}
?>