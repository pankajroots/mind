<?php
/**
 * Custom search panel
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts(); ?>

<div class="search-panel">

	<div class="container clearfix">
		<?php
        if ( class_exists( 'woocommerce' ) && 'product' == $bmrk_opts['search-form-type'] ) {
            get_template_part( 'woocommerce/product-searchform' );
        }
        else {
            get_search_form();
        }
        ?>
        <a href="#" class="search-close" title="<?php esc_attr_e( 'Close', 'benchmark' ); ?>"><i class="mdi mdi-close"></i><span class="sr-only"><?php esc_html_e( 'close search', 'benchmark' ); ?></span></a>

    </div><!-- /.container -->

</div><!-- /.search-panel -->