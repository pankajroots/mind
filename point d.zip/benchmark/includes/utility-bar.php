<?php
/**
 * Top utility bar
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts(); ?>

<div id="utility-top">
    <div class="container clearfix">

        <div id="callout-bar-left" class="callout-bar col-md-6" role="complementary">
            <?php echo do_shortcode( stripslashes( $bmrk_opts[ 'cb-text-left' ] ) ); ?>
        </div><!-- /#callout-bar-left -->

        <?php if ( 'links' == $bmrk_opts[ 'callout-right' ] ) { ?>
            <div id="utility-links" class="col-md-6">
				<?php get_template_part( 'includes/utility-bar-links' );	?>
            </div><!-- /#utility-links -->
        <?php }

        else { ?>
            <div id="callout-bar-right" class="callout-bar col-md-6 text-right" role="complementary">
				<?php echo do_shortcode( stripslashes( $bmrk_opts[ 'cb-text-right' ] ) );  ?>
            </div><!-- /#callout-bar-right -->
        <?php } ?>

    </div><!-- /.container -->
</div><!-- /#utility-top-->
