<?php
/**
 * Add post options array with custom option fields
 */

function benchmark_add_post_options() {

	$post_opts = array(
		'info1' 	=> array(
			'type' 			=> 'heading',
			'description' 	=> esc_html__( 'Post Format Options', 'benchmark' )
		),

		'pf_video' 	=> array(
			'id' 			=> 'pf_video',
			'title' 		=> esc_html__( 'Video URL', 'benchmark' ),
			'type' 			=> 'text',
			'description' 	=> esc_html__( 'URL of video for Video Post Format. Example: http://vimeo.com/41369274', 'benchmark' )
		),

		'hr1' 			=> array( 'type' => 'hr' ),

		'info2' 		=> array(
			'type' 			=> 'heading',
			'description' 	=> esc_html__( 'Single Post Options', 'benchmark' )
		),

		'sb_placement' => array(
			'id' 			=> 'sb_placement',
			'title' 		=> esc_html__( 'Sidebar Placement', 'benchmark' ),
			'std'			=> 'global',
			'type' 			=> 'select',
			'options' 		=> array( 'global', 'right', 'left', 'none' ),
			'description' 	=> esc_html__( 'Choose a sidebar placement on this post. Choose global setting if you want theme options sidebar setting to apply on this post.', 'benchmark' )
		),

		'hide_meta'	 	=> array(
			'id' 			=> 'hide_meta',
			'title' 		=> esc_html__( 'Hide post meta on this post', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_image'	 	=> array(
			'id' 			=> 'hide_image',
			'title' 		=> esc_html__( 'Hide featured image on this post', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'show_image'	 	=> array(
			'id' 			=> 'show_image',
			'title' 		=> esc_html__( 'Show featured image on this post. (Useful when featured image is disabled via Theme Options).', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_related'	 	=> array(
			'id' 			=> 'hide_related',
			'title' 		=> esc_html__( 'Hide related posts section on this post', 'benchmark' ),
			'type' 			=> 'checkbox'
		),
	);

	return $post_opts;

}

function benchmark_add_post_options_key() {
	return 'bmrk_post_options';
}

add_filter( 'bnz_post_opts_array', 'benchmark_add_post_options' );
add_filter( 'bnz_post_opts_key', 'benchmark_add_post_options_key' );