<?php
/**
 * Theme defined pre-built layouts for
 * Site Origin Page Builder
 */

function benchmark_prebuilt_layouts( $layouts ){
$layouts['home-one'] = array (
	'name' => esc_html__( 'Home 01', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_1.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax-1.jpg" parallax="true" overlay="dark"  style="padding: 160px 0 64px;"]

[ss_row]

[ss_column md="7"]

<h1 class="text-l">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-24">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification and 100% job placement in one of the top IT Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

<img class="hero-img rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/hero1.jpg" alt="hero">

[/ss_column]

[ss_column md="5"]

<div class="register-form">

<h3 class="h2 bar-center text-center bottom-24">Register now and get free course material worth <strong>$49</strong></h3>

[contact-form-7 id="16" title="lead-gen-form"]

<hr>

<p class="help-block">Your details will not be published. Before subscribing please read our <a href="#">Terms of service</a> and <a href="#">Privacy Policy</a>.</p>

</div>

[/ss_column]

[/ss_row]

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'custom_id' => 'home',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 7,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>

<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',

        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 16,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 10,
        'cell' => 0,
        'id' => 17,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    18 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' =>
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    19 =>
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 19,
        'style' =>
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' =>
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 1,
        'id' => 23,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 2,
        'id' => 24,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 25,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    26 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' =>
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    27 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 1,
        'id' => 28,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 2,
        'id' => 29,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 3,
        'id' => 30,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 18,
        'cell' => 0,
        'id' => 31,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    4 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    5 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    6 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    7 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    8 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    9 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    10 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    11 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    12 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    13 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    14 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    15 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    16 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    17 =>
    array (
      'cells' => 4,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    18 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_image_attachment' => 14,
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    3 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 =>
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    11 =>
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    14 =>
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    15 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    16 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    17 =>
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    18 =>
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 =>
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 =>
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    22 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 =>
    array (
      'grid' => 15,
      'weight' => 1,
    ),
    25 =>
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    27 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    28 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    29 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    30 =>
    array (
      'grid' => 18,
      'weight' => 1,
    ),
  )
);

$layouts['home-two'] = array (
	'name' => esc_html__( 'Home 02', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_2.jpg',
  'widgets' => 
  array (
    0 => 
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/full_screen_parallax.jpg" parallax="true" overlay="dark"  style="padding: 144px 0 0;" fullscreen="true"]

<div class="absolute-center">

<h2 class="text-xxl mobile-heading">Let us <span style="color: #ffeb3b;">C++</span></h2>

<p class="h3">Learn C++ programming from the top ranked faculties of Berkeley University.
Subscribe to our course and you could win a free Laptop.</p>

[ss_button type="alt" size="medium" link="#" title="Apply for the course"]Apply now[/ss_button] [ss_button type="white" size="medium" link="#" title="Learn more about the course"]Find out more[/ss_button]

</div>

[/ss_section]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'custom_id' => 'home',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 7,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>
                           
<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 16,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' => 
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 19,
        'style' => 
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' => 
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 => 
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' => 
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 => 
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 1,
        'id' => 23,
        'style' => 
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 => 
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 2,
        'id' => 24,
        'style' => 
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 25,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    26 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' => 
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    27 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 1,
        'id' => 28,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 2,
        'id' => 29,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 3,
        'id' => 30,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 => 
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 0,
        'id' => 31,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    9 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    10 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    11 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    12 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    13 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    14 => 

    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    15 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    16 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    17 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    18 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    11 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    14 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    16 => 
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    17 => 
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    18 => 
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 => 
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 => 
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 => 
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    22 => 
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 => 
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 => 
    array (
      'grid' => 15,
      'weight' => 1,
    ),
    25 => 
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    27 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    28 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    29 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    30 => 
    array (
      'grid' => 18,
      'weight' => 1,
    ),
  )
);

$layouts['home-three'] = array (
	'name' => esc_html__( 'Home 03', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_3.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax-1.jpg" parallax="true" overlay="dark"  style="padding: 160px 0 64px;" xclass="text-center"]

<h1 class="text-l">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-48">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification
and 100% job placement in one of the top IT Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

<div class="register-form">

<h3 class="h2 bar-center bottom-24">Register now and get free course material worth <strong>$49</strong></h3>

[contact-form-7 id="87" title="home-full-width-lead-gen-multiple"]

<hr>

<p class="help-block">Your details will not be published. Before subscribing please read our <a href="#">Terms of service</a> and <a href="#">Privacy Policy</a>.</p>

</div>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'custom_id' => 'home',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 7,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>

<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 16,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 17,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' =>
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    19 =>
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 19,
        'style' =>
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' =>
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 1,
        'id' => 23,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 2,
        'id' => 24,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 25,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    26 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' =>
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    27 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 1,
        'id' => 28,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 2,
        'id' => 29,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 3,
        'id' => 30,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 0,
        'id' => 31,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    4 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    5 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    6 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    7 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    8 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    9 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    10 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    11 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    12 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    13 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    14 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    15 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    16 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    17 =>
    array (
      'cells' => 4,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    18 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_image_attachment' => 14,
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    3 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 =>
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    11 =>
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    14 =>
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    15 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    16 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    17 =>
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    18 =>
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 =>
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 =>
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    22 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 =>
    array (
      'grid' => 15,
      'weight' => 1,
    ),
    25 =>
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    27 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    28 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    29 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    30 =>
    array (
      'grid' => 18,
      'weight' => 1,
    ),
  )
);

$layouts['home-four'] = array (
	'name' => esc_html__( 'Home 04', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_4.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax-1.jpg" parallax="true" overlay="dark"  style="padding: 160px 0 64px;" xclass="text-center"]

<h1 class="text-l">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-48">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification
and 100% job placement in one of the top IT Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

[ss_row]

[ss_column md="7"]

<img class="hero-img rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/hero2.jpg" alt="hero">

[/ss_column]

[ss_column md="5"]

<div class="register-form">

<h3 class="h2 bar-center text-center bottom-24">Register now and get free course material worth <strong>$49</strong></h3>

[contact-form-7 id="76" title="lead-small"]

<hr>

<p class="help-block">Your details will not be published. Before subscribing please read our <a href="#">Terms of service</a> and <a href="#">Privacy Policy</a>.</p>

</div>

[/ss_column]

[/ss_row]

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'custom_id' => 'home',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 7,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>

<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 16,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 17,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' =>
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    19 =>
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 19,
        'style' =>
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' =>
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 1,
        'id' => 23,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 2,
        'id' => 24,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 25,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    26 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' =>
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    27 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 1,
        'id' => 28,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 2,
        'id' => 29,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 3,
        'id' => 30,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 0,
        'id' => 31,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    4 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    5 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    6 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    7 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    8 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    9 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    10 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    11 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',

        'background_display' => 'tile',
      ),
    ),
    12 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    13 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    14 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    15 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    16 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    17 =>
    array (
      'cells' => 4,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    18 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_image_attachment' => 14,
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    3 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 =>
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    11 =>
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    14 =>
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    15 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    16 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    17 =>
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    18 =>
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 =>
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 =>
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    22 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 =>
    array (
      'grid' => 15,
      'weight' => 1,
    ),
    25 =>
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    27 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    28 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    29 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    30 =>
    array (
      'grid' => 18,
      'weight' => 1,
    ),
  )
);

$layouts['home-five'] = array (
	'name' => esc_html__( 'Home 05', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_5.jpg',
  'widgets' => 
  array (
    0 => 
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/full_screen_parallax.jpg" parallax="true" overlay="dark"  style="padding: 144px 0 0;" fullscreen="true" xclass="text-center"]

<div class="absolute-center">

<h1 class="text-l mobile-heading">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-48 hide-on-mobile">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification
and 100% job placement in one of the top IT Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

<div class="register-form single-row">

[contact-form-7 id="103" title="home-horiz-email"]

</div>

<p class="help-block">Your details will not be published. Before subscribing please read our <a href="#">Terms of service</a> and <a href="#">Privacy Policy</a>.</p>

</div>

[/ss_section]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'custom_id' => 'home',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 7,
        'style' => 
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>
                           
<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 16,
        'style' => 
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' => 
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 19,
        'style' => 
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' => 
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 => 
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' => 
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 => 
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 1,
        'id' => 23,
        'style' => 
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 => 
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 2,
        'id' => 24,
        'style' => 
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 => 
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 25,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    26 => 
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' => 
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    27 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 1,
        'id' => 28,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 2,
        'id' => 29,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 => 
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 3,
        'id' => 30,
        'style' => 
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 => 
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 0,
        'id' => 31,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    9 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    10 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    11 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    12 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    13 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    14 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    15 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    16 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    17 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    18 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    11 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    14 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    16 => 
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    17 => 
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    18 => 
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 => 
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 => 
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 => 
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    22 => 
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 => 
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 => 
    array (
      'grid' => 15,
      'weight' => 1,
    ),
    25 => 
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    27 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    28 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    29 => 
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    30 => 
    array (
      'grid' => 18,
      'weight' => 1,
    ),
  )
);

$layouts['home-six'] = array (
	'name' => esc_html__( 'Home 06', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_6.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax-1.jpg" parallax="true" overlay="dark"]

[ss_row]

[ss_column md="6"]

<h1 class="text-l">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-24">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification and 100% job placement in top Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

[ss_button type="alt" size="medium" link="#" title="Check out the collection"]Apply now[/ss_button] [ss_button type="white" size="medium" link="#" title="Check out the collection"]Learn more[/ss_button]

[/ss_column]

[ss_column md="6"]

<p><img class="hero-img rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/hero2.jpg" alt="hero"></p>

[/ss_column]

[/ss_row]

[/ss_section]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'custom_id' => 'home',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 7,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>

<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 16,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 10,
        'cell' => 0,
        'id' => 17,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    18 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' =>
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    19 =>
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 19,
        'style' =>
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' =>
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 1,
        'id' => 23,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 2,
        'id' => 24,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 25,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    26 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' =>
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    27 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 1,
        'id' => 28,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 2,
        'id' => 29,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 3,
        'id' => 30,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 18,
        'cell' => 0,
        'id' => 31,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-top: -48px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    4 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    5 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    6 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    7 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    8 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    9 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    10 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    11 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    12 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    13 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    14 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    15 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    16 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    17 =>
    array (
      'cells' => 4,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    18 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    3 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 =>
    array (
      'grid' => 2,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 =>
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 =>
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    11 =>
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 =>
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    14 =>
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    15 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    16 =>
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    17 =>
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    18 =>
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 =>
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 =>
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    22 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 =>
    array (
      'grid' => 14,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 =>
    array (
      'grid' => 15,
      'weight' => 1,
    ),
    25 =>
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    27 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    28 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    29 =>
    array (
      'grid' => 17,
      'weight' => 0.25,
    ),
    30 =>
    array (
      'grid' => 18,
      'weight' => 1,
    ),
  )
);

$layouts['home-seven'] = array (
	'name' => esc_html__( 'Home 07', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_7.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_row]
[ss_column sm="6"]

<h1 class="text-l font-light">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-24">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification and 100% job placement in top Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

[ss_button type="alt" size="medium" link="#" title="Check out the collection"]Apply now[/ss_button] [ss_button type="line" size="medium" link="#" title="Check out the collection"]Learn more[/ss_button]

[/ss_column]

[ss_column sm="6"]

<img class="hero-img rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/hero2.jpg" alt="hero">

[/ss_column]
[/ss_row]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'custom_id' => 'home',
          'widget_css' => 'padding: 64px 0 40px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 4,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 5,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 7,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 8,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 10,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 11,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>

<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 13,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 1,
        'id' => 14,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    15 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 16,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 1,
        'id' => 17,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    18 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    19 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 19,
        'style' =>
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 =>
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' =>
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    21 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    22 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' =>
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 23,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 1,
        'id' => 24,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 2,
        'id' => 25,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    26 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    27 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' =>
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 0,
        'id' => 28,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 1,
        'id' => 29,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 2,
        'id' => 30,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 3,
        'id' => 31,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    32 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 19,
        'cell' => 0,
        'id' => 32,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-top: -48px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    3 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    4 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    5 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    6 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    7 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    8 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    9 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    10 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    11 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    12 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    13 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    14 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    15 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    16 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    17 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    18 =>
    array (
      'cells' => 4,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    19 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 =>
    array (
      'grid' => 4,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 =>
    array (
      'grid' => 4,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 =>
    array (
      'grid' => 4,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    9 =>
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    10 =>
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    11 =>
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    12 =>
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    13 =>
    array (
      'grid' => 8,
      'weight' => 0.5,
    ),
    14 =>
    array (
      'grid' => 8,
      'weight' => 0.5,
    ),
    15 =>
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    16 =>
    array (
      'grid' => 10,
      'weight' => 0.5,
    ),
    17 =>
    array (
      'grid' => 10,
      'weight' => 0.5,
    ),
    18 =>
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 =>
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 =>
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 =>
    array (
      'grid' => 14,
      'weight' => 1,
    ),
    22 =>
    array (
      'grid' => 15,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 =>
    array (
      'grid' => 15,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 =>
    array (
      'grid' => 15,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    25 =>
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 =>
    array (
      'grid' => 17,
      'weight' => 1,
    ),
    27 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    28 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    29 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    30 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    31 =>
    array (
      'grid' => 19,
      'weight' => 1,
    ),
  )
);

$layouts['home-eight'] = array (
	'name' => esc_html__( 'Home 08', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/home_8.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_slider loop="true" items="1"]
[ss_slide]
[ss_row]
[ss_column sm="6"]

<h1 class="text-l font-light">Flat 40% discount on all ecommerce courses</h1>

<h2 class="text-m bottom-24">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification and 100% job placement in top Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

[ss_button type="alt" size="medium" link="#" title="Check out the collection"]Apply now[/ss_button] [ss_button type="line" size="medium" link="#" title="Check out the collection"]Learn more[/ss_button]

[/ss_column]

[ss_column sm="6"]

<img class="hero-img rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/hero2.jpg" alt="hero">

[/ss_column]
[/ss_row]
[/ss_slide]

[ss_slide]
[ss_row]
[ss_column sm="6"]

<h1 class="text-l font-light">Advanced Java
certification in just
6 months</h1>

<h2 class="text-m bottom-24">Covering two trimesters with an Industry based live project, you will be awarded Benchmark certification and 100% job placement in top Companies. <span class="text-underline">Do not miss</span> the opportunity.</h2>

[ss_button type="alt" size="medium" link="#" title="Check out the collection"]Apply now[/ss_button] [ss_button type="line" size="medium" link="#" title="Check out the collection"]Learn more[/ss_button]

[/ss_column]

[ss_column sm="6"]

<img class="hero-img rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="hero">

[/ss_column]
[/ss_row]
[/ss_slide]
[/ss_slider]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'custom_id' => 'home',
          'widget_css' => 'padding: 64px 0 40px;',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light text-center bar-center">Benefits of choosing Benchmark</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'custom_id' => 'features',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-spellcheck"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Professional Courses</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,100',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-beenhere"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Award winning faculty</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 4,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,200',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-school"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Top Graduates</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 5,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-edit"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Creative Learning</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,300',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-airplanemode_active"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Campus Placement</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 7,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,400',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 =>
    array (
      'title' => '',
      'text' => '<i class="icon mdi mdi-loyalty"></i>

<div class="feature-details">

<h3 class="h4 bottom-4">Dedicated Support</h3>

<p>In hac habitasse platea dictumst morbi sed nisi vitae convallis ipsum dolor justo amet quis elit.</p>

</div>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 8,
        'style' =>
        array (
          'data_atts' => 'animation, flipInX | animdelay,600',
          'class' => 'bottom-24 animated clearfix',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo1.jpg" alt="feature1"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 10,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Follow your dreams</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#pricing">See Pricing Plans</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 11,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Compete the World</h2>

<h3 class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo.</h3>

<ul class="check-list">
    <li>Built on Twitter Bootstrap</li>
    <li>Vector webfont icons</li>
    <li>Fully responsive and retina ready</li>
    <li>Easy to extend and modify</li>
    <li>Working ajax/php forms</li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 13,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo2.jpg" alt="feature2"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 1,
        'id' => 14,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    15 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 =>
    array (
      'title' => '',
      'text' => '<img class="rounded-2px" src="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/02/promo3.jpg" alt="feature3"/>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 16,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light">Reach to your success</h2>

<h3 class="text-m">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus facilisis sapien.</h3>

Integer quis elit id felis condimentum fermentum. Nullam pharetra arcu sit amet sapien cursus et sagittis urna eleifend. Nulla eleifend justo eu urna ultrices sagittis sed auctor tincidunt pretium.

<a class="ss-btn btn-line no-margin" href="#partners">Meet alumni</a>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 10,
        'cell' => 1,
        'id' => 17,
        'style' =>
        array (
          'data_atts' => 'animation, fadeIn| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    18 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax2.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Join an institute where only professionals are delivered</h2>

<p class="text-m">Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat.<br/>Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Learn more</a>

[/ss_section]',
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 11,
        'cell' => 0,
        'id' => 18,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    19 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 font-light bar-center">Trusted &amp; loved by</h2>

<h3 class="text-d text-center bottom-48">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>

<ul class="list-inline logo-grid">
<li class="animated" data-animation="flipInX" data-animdelay="100"><a href="#" title=""><img src="[ss_theme_url]/images/user/b1.png" alt="brand1" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="200"><a href="#" title=""><img src="[[ss_theme_url]/images/user/b2.png" alt="brand2" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="400"><a href="#" title=""><img src="[ss_theme_url]/images/user/b3.png" alt="brand3" /></a></li>
<li class="animated" data-animation="flipInX" data-animdelay="600"><a href="#" title=""><img src="[ss_theme_url]/images/user/b4.png" alt="brand4" /></a></li>
</ul>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 19,
        'style' =>
        array (
          'custom_id' => 'partners',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'bottom-24 text-center',
          'widget_css' => 'padding-top: 80px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    20 =>
    array (
      'title' => '',
      'text' => '[ss_testimonial_slider]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar1.jpg" name="Grace Wills" desig1="Graduated, 2015" desig2="Programmer, IRQ Ltd."]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[ss_testimonial_slide avatar_url="{ss_theme_url}/images/user/avatar2.jpg" name="Mick Wright" desig1="Developer, X Games" desig2="2015 Batch"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum. Donec vel sapien porta sapien eleifend tincidunt at sit amet erat.[/ss_testimonial_slide]

[/ss_testimonial_slider]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 20,
        'style' =>
        array (
          'class' => 'text-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    21 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 21,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    22 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Just starting out? Select from our plans</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 14,
        'cell' => 0,
        'id' => 22,
        'style' =>
        array (
          'custom_id' => 'pricing',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Elementary" label="Basic"]

<p class="price"><span class="text-34 font-light">$199.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Donec vel sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Basic Computers</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>3D Modelling basics</li>
        <li>Tally / Accounting</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 0,
        'id' => 23,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    24 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Advanced" label="economy" type="blue"]

<p class="price"><span class="text-34 font-light">$249.00</span><small> / month</small></p>

<div class="pricing-content">
    <p>Sapien donec vel porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>Accounting Software</li>
        <li>Web Development</li>
        <li>3D Modelling advanced</li>
        <li>UX/UI Design</li>
    </ul>
    <p><a class="ss-btn btn-alt btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 1,
        'id' => 24,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    25 =>
    array (
      'title' => '',
      'text' => '[ss_pricing_grid title="Power Pack" label="Premium" type="brown"]

<p class="price"><span class="text-34 font-light">$349.00</span><small> / month</small></p>
<div class="pricing-content">
    <p>Lorem ipsum sapien porta sapien eleifend tincidunt at sit amet erat amet.</p>
    <ul class="check-list">
        <li>Java Programming</li>
        <li>Operating System</li>
        <li>Adobe Creative Suite</li>
        <li>MS Office 2007</li>
        <li>php and JavaScript</li>
        <li>Accounting Software</li>
    </ul>
    <p><a class="ss-btn btn-line btn-medium btn-block" href="#">Get Started</a></p>
</div>

[/ss_pricing_grid]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 15,
        'cell' => 2,
        'id' => 25,
        'style' =>
        array (
          'data_atts' => 'animation, fadeInLeft| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    26 =>
    array (
      'title' => '',
      'text' => '<hr>',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 16,
        'cell' => 0,
        'id' => 26,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    27 =>
    array (
      'title' => '',
      'text' => '<h2 class="h1 text-center font-light bar-center">Meet the team</h2>

<h3 class="text-d text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus leo ante, consectetur sit amet vulputate vel, dapibus sit amet lectus. Etiam varius dui eget lorem elementum eget mattis sapien interdum.</h3>',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 17,
        'cell' => 0,
        'id' => 27,
        'style' =>
        array (
          'custom_id' => 'team',
          'data_atts' => 'animation, fadeIn| animdelay,100',
          'class' => 'text-center',
          'widget_css' => 'padding-top: 56px;',
          'background_display' => 'tile',
        ),
      ),
    ),
    28 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member1.jpg" name="Dr. Thompson" desig1="C# and Java Specialist" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 0,
        'id' => 28,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,100',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    29 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member2.jpg" name="Kara Moon" desig1="Computer Science" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 1,
        'id' => 29,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,300',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    30 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member3.jpg" name="Elle Woods" desig1="Fashion Management" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 2,
        'id' => 30,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,500',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    31 =>
    array (
      'title' => '',
      'text' => '[ss_member_card avatar_url="{ss_theme_url}/images/user/member4.jpg" name="Samuel Shultz" desig1="Personality Development" link="#" social_links="Twitter, http://twitter.com | Facebook, http://facebook.com | Pinterest, http://pinterest.com"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 18,
        'cell' => 3,
        'id' => 31,
        'style' =>
        array (
          'data_atts' => 'animation, flipInY| animdelay,700',
          'class' => 'animated',
          'background_display' => 'tile',
        ),
      ),
    ),
    32 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/parallax3.jpg" parallax="true" overlay="dark" xclass="text-center"]

<h2 class="h1">Unleash your true potential. Join Benchmark.</h2>

<p class="text-m">Quisque lacinia auctor mattis. Duis sed nisl justo. Morbi pellentesque blandit tellus ac dapibus. Suspendisse sed urna lobortis nulla semper suscipit id et justo. Fusce ullamcorper, nibh eget viverra consequat, purus turpis pretium neque, in laoreet ipsum.</p>

<a class="ss-btn btn-alt btn-medium" href="#hero">Register now</a> <a class="ss-btn btn-line btn-medium" href="#pricing">Download Brochure</a>

[/ss_section]',
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 19,
        'cell' => 0,
        'id' => 32,
        'style' =>
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-top: -48px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'background_display' => 'tile',
      ),
    ),
    3 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    4 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '32px',
        'background_display' => 'tile',
      ),
    ),
    5 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    6 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    7 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    8 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    9 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'background_display' => 'tile',
      ),
    ),
    10 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'class' => 'feature-list',
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    11 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
    12 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    13 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    14 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    15 =>
    array (
      'cells' => 3,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    16 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    17 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    18 =>
    array (
      'cells' => 4,
      'style' =>
      array (
        'bottom_margin' => '56px',
        'gutter' => '24px',
        'background_display' => 'tile',
      ),
    ),
    19 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'row_css' => 'margin-bottom: -40px;',
        'bottom_margin' => '0px',
        'background_display' => 'parallax',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    4 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    5 =>
    array (
      'grid' => 3,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    6 =>
    array (
      'grid' => 4,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    7 =>
    array (
      'grid' => 4,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    8 =>
    array (
      'grid' => 4,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    9 =>
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    10 =>
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    11 =>
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    12 =>
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    13 =>
    array (
      'grid' => 8,
      'weight' => 0.5,
    ),
    14 =>
    array (
      'grid' => 8,
      'weight' => 0.5,
    ),
    15 =>
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    16 =>
    array (
      'grid' => 10,
      'weight' => 0.5,
    ),
    17 =>
    array (
      'grid' => 10,
      'weight' => 0.5,
    ),
    18 =>
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    19 =>
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    20 =>
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    21 =>
    array (
      'grid' => 14,
      'weight' => 1,
    ),
    22 =>
    array (
      'grid' => 15,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    23 =>
    array (
      'grid' => 15,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    24 =>
    array (
      'grid' => 15,
      'weight' => 0.333333333333333314829616256247390992939472198486328125,
    ),
    25 =>
    array (
      'grid' => 16,
      'weight' => 1,
    ),
    26 =>
    array (
      'grid' => 17,
      'weight' => 1,
    ),
    27 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    28 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    29 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    30 =>
    array (
      'grid' => 18,
      'weight' => 0.25,
    ),
    31 =>
    array (
      'grid' => 19,
      'weight' => 1,
    ),
  )
);

$layouts['contact'] = array (
	'name' => esc_html__( 'Contact', 'benchmark' ),
	'description' => '',
	'screenshot' => get_template_directory_uri() . '/images/pb_screenshots/contact.jpg',
  'widgets' =>
  array (
    0 =>
    array (
      'title' => '',
      'text' => '[ss_section bgimage="http://labs.saurabh-sharma.net/themes/benchmark/wp-content/uploads/2016/01/contact_parallax.jpg" parallax="true" overlay="dark"  style="padding: 192px 0 48px;"]

<h2 class="text-xl no-margin">Contact us</h2>

[/ss_section]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 =>
    array (
      'title' => '',
      'text' => '[ss_breadcrumbs]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' =>
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 =>
    array (
      'title' => '',
      'text' => '<h2 class="h4 font-medium">Send us your query by filling the form below</h2>

[contact-form-7 id="64" title="contact page"]',
      'filter' => false,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' =>
        array (
          'class' => 'bottom-24',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 =>
    array (
      'title' => '',
      'text' => '<h2 class="h3 font-medium bottom-8">Benchmark Inc.</h2>

<h3 class="h6 text-muted">A/26 North Coast Avenue
Street Name, City
Country - 110127</h3>

<h3 class="h4">Location Map</h3>

[ss_gmap location="Maharana Pratap Smarak, Udaipur, Rajasthan, India" responsive="true"]',
      'filter' => true,
      'panels_info' =>
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' =>
        array (
          'class' => 'bottom-24',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' =>
  array (
    0 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '48px',
        'background_display' => 'parallax',
      ),
    ),
    1 =>
    array (
      'cells' => 1,
      'style' =>
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    2 =>
    array (
      'cells' => 2,
      'style' =>
      array (
        'bottom_margin' => '24px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' =>
  array (
    0 =>
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 =>
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 =>
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    3 =>
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
  )
);

return $layouts;
}

add_filter( 'siteorigin_panels_prebuilt_layouts', 'benchmark_prebuilt_layouts' );
?>