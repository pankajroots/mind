<?php
/**
 * Add page options array with custom option fields
 */

function benchmark_add_page_options() {

	$page_opts = array(

		'info0' 	=> array(
			'type' 			=> 'heading',
			'description' 	=> esc_html__( 'Header and Hero area options', 'benchmark' )
		),

		'one_page_menu' => array(
			'id' 			=> 'one_page_menu',
			'title' 		=> esc_html__( 'Enable one page scroll-spy menu on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'transparent_nav' => array(
			'id' 			=> 'transparent_nav',
			'title' 		=> esc_html__( 'Enable transparent navbar on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),


		'custom_menu' => array(
			'id' 			=> 'custom_menu',
			'title' 		=> esc_html__( 'Custom menu for this page', 'benchmark' ),
			'type' 			=> 'wp-menus',
			'description' 	=> esc_html__( 'The chosen menu will be shown only for this particular page. This option is useful for creating one page template.', 'benchmark' )
		),

		'page_title' => array(
			'id' 			=> 'page_title',
			'title' 		=> esc_html__( 'Custom page title', 'benchmark' ),
			'type' 			=> 'text',
			'description' 	=> esc_html__( 'Provide a custom page title for the hero area', 'benchmark' )
		),

		'header_callout_text' => array(
			'id' 			=> 'header_callout_text',
			'title' 		=> esc_html__( 'Header callout text in place of menu', 'benchmark' ),
			'type' 			=> 'textarea',
			'description' 	=> esc_html__( 'This text can be shown when hiding menu.', 'benchmark' )
		),

		'hide_top_nav' => array(
			'id' 			=> 'hide_top_nav',
			'title' 		=> esc_html__( 'Hide top navbar on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_main_nav' => array(
			'id' 			=> 'hide_main_nav',
			'title' 		=> esc_html__( 'Hide main navbar on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_header_icons' => array(
			'id' 			=> 'hide_header_icons',
			'title' 		=> esc_html__( 'Hide header icons (search, cart, etc.) on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_crumbs' => array(
			'id' 			=> 'hide_crumbs',
			'title' 		=> esc_html__( 'Hide breadcrumbs on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_hero' => array(
			'id' 			=> 'hide_hero',
			'title' 		=> esc_html__( 'Hide hero area on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'force_white_color' => array(
			'id' 			=> 'force_white_color',
			'title' 		=> esc_html__( 'Force white color for menu items when using white color scheme', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hr0' => array(	'type' => 'hr'),

		'info1' 	=> array(
			'type' 			=> 'heading',
			'description' 	=> esc_html__( 'Sidebar Options', 'benchmark' )
		),

		'sb_placement' => array(
			'id' 			=> 'sb_placement',
			'title' 		=> esc_html__( 'Sidebar Placement', 'benchmark' ),
			'std'			=> 'global',
			'type' 			=> 'select',
			'options' 		=> array( 'global', 'right', 'left', 'none' ),
			'description' 	=> esc_html__( 'Choose a sidebar placement on this page. Choose global setting if you want theme options sidebar setting to apply on this page.', 'benchmark' )
		),

		'hr1' => array(	'type' => 'hr'),

		'info2' 	=> array(
			'type' 			=> 'heading',
			'description' 	=> esc_html__( 'Blog and portfolio template options', 'benchmark' )
		),

		'cats' 	=> array(
			'id' 			=> 'cats',
			'title' 		=> esc_html__( 'Categories for blog or portfolio templates.', 'benchmark' ),
			'type' 			=> 'multi-select',
			'description' 	=> esc_html__( 'Choose categories to show posts from. Use Ctrl + select for multiple selection.', 'benchmark' )
		),

		'post_per_page' => array(
			'id' 			=> 'post_per_page',
			'title' 		=> esc_html__( 'Posts per page', 'benchmark' ),
			'type' 			=> 'number_text',
			'description' 	=> esc_html__( 'The number of posts to show per page.', 'benchmark' )
		),

		'grid_columns' => array(
			'id' 			=> 'grid_columns',
			'title' 		=> esc_html__( 'Number of grid columns', 'benchmark' ),
			'std'			=> '2',
			'type' 			=> 'select',
			'options' 		=> array( '2', '3', '4'),
			'description' 	=> esc_html__( 'Select number of grid columns. This setting applies to grid style templates.', 'benchmark' )
		),

		'img_width' => array(
			'id' 			=> 'img_width',
			'title' 		=> esc_html__( 'Image width', 'benchmark' ),
			'type' 			=> 'number_text',
			'description' 	=> esc_html__( 'Provide image width (in px) without the unit. Eg. 300', 'benchmark' )
		),

		'img_height' => array(
			'id' 			=> 'img_height',
			'title' 		=> esc_html__( 'Image height', 'benchmark' ),
			'type' 			=> 'number_text',
			'description' 	=> esc_html__( 'Provide image height (in px) without the unit. Eg. 300', 'benchmark' )
		),

		'img_crop' => array(
			'id' 			=> 'img_crop',
			'title' 		=> esc_html__( 'Crop images', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'img_upscale' => array(
			'id' 			=> 'img_upscale',
			'title' 		=> esc_html__( 'Upscale images', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hr2' => array(	'type' => 'hr'),

		'info3' => array(
			'type' 			=> 'heading',
			'description' 	=> esc_html__( 'Miscellaneous settings', 'benchmark' )
		),

		'color_scheme' => array(
			'id' 			=> 'color_scheme',
			'title' 		=> esc_html__( 'Color Scheme for this page', 'benchmark' ),
			'type' 			=> 'select',
			'std'			=> 'global',
			'options' 		=> array( 'global', 'blue', 'brown', 'coffee', 'forest', 'green', 'indigo', 'pink', 'purple-green', 'purple-tan', 'purple', 'slate', 'teal', 'white' ),
			'description' 	=> esc_html__( 'Choose a color scheme for this page. If set global, color scheme from theme options will be taken into effect.', 'benchmark' )
		),

		'hide_sec_a' => array(
			'id' 			=> 'hide_sec_a',
			'title' 		=> esc_html__( 'Hide secondary widget area A on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		),

		'hide_sec_b' => array(
			'id' 			=> 'hide_sec_b',
			'title' 		=> esc_html__( 'Hide secondary widget area B on this page', 'benchmark' ),
			'type' 			=> 'checkbox'
		)
	);

	return $page_opts;
}

function benchmark_add_page_options_key() {
	return 'bmrk_page_opts';
}

add_filter( 'bnz_page_opts_array', 'benchmark_add_page_options' );
add_filter( 'bnz_page_opts_key', 'benchmark_add_page_options_key' );