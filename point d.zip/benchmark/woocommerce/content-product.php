<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you (the theme developer).
 * will need to copy the new files to your theme to maintain compatibility. We try to do this.
 * as little as possible, but it does happen. When this occurs the version of the template file will.
 * be bumped and the readme will list any important changes.
 *
 * @see     http://docs.woothemes.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product;
$bmrk_opts = benchmark_get_theme_opts();

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

// Extra post classes
$classes = array();

switch( $bmrk_opts[ 'shop-columns' ] ) {

	case '1' :
		$classes[] = 'col-xs-12';
	break;

	case '2' :
		$classes[] = 'col-xs-6 col-sm-6';
	break;

	case '3' :
		$classes[] = 'col-xs-6 col-sm-4';
	break;

	case '4' :
		$classes[] = 'col-xs-6 col-sm-4 col-md-3';
	break;

	case '6' :
		$classes[] = 'col-xs-6 col-sm-4 col-md-2';
	break;
}
?>
<div <?php post_class( $classes ); ?>>

    <div class="product-wrap">

		<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>

        <a href="<?php the_permalink(); ?>">

        <?php
        /**
        * woocommerce_before_shop_loop_item_title hook
        *
        * @hooked woocommerce_show_product_loop_sale_flash - 10
        * @hooked woocommerce_template_loop_product_thumbnail - 10
        */
        do_action( 'woocommerce_before_shop_loop_item_title' );
		
		/**
		 * woocommerce_shop_loop_item_title hook.
		 *
		 * @hooked woocommerce_template_loop_product_title - 10
		 */
		do_action( 'woocommerce_shop_loop_item_title' );
        ?>

        </a>
        <div class="product-info">
            <?php the_title( '<h3><a href="' . esc_url( get_permalink() ) . '" data-product-id="' . get_the_ID() . '">', '</a></h3>' );

            /**
             * woocommerce_after_shop_loop_item_title hook
             *
             * @hooked woocommerce_template_loop_rating - 5
             * @hooked woocommerce_template_loop_price - 10
             */
            do_action( 'woocommerce_after_shop_loop_item_title' );
			?>
        </div><!-- /.product-info -->

        <div class="product-actions">
            <a href="#" class="product-actions-trigger" title="<?php esc_attr_e( 'Product actions', 'benchmark' ); ?>"><i class="mdi mdi-more_vert"></i><span class="sr-only"><?php esc_html_e( 'product actions', 'benchmark' ); ?></span></a>
            <div class="product-actions-overlay">
				<?php
				/**
				 * woocommerce_after_shop_loop_item hook.
				 *
				 * @hooked woocommerce_template_loop_product_link_close - 5
				 * @hooked woocommerce_template_loop_add_to_cart - 10
				 */
				do_action( 'woocommerce_after_shop_loop_item' ); ?>
            </div><!-- /.product-actions-overlay -->
        </div><!-- /.product-actions -->
    </div><!-- /.product-wrap -->
</div>