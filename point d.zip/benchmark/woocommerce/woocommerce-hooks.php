<?php
/**
 * WooCommerce hooks
 * Custom functions, hooks and actions for WooCommerce Plugin
 */


// Update cart fragments in top nav

function bmrk_top_nav_fragments( $fragments ) {
	global $woocommerce;
	ob_start(); ?>
	<a class="cart-contents" href="<?php echo esc_url( $woocommerce->cart->get_cart_url() ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'benchmark' ); ?>"><i class="mdi mdi-shopping_cart"></i><?php echo sprintf( _n( ' %d item - ', ' %d items - ', $woocommerce->cart->cart_contents_count, 'benchmark' ), $woocommerce->cart->cart_contents_count); echo $woocommerce->cart->get_cart_subtotal(); ?></a>
	<?php
	$fragments['a.cart-contents'] = ob_get_clean();
	return $fragments;
}

add_filter( 'woocommerce_add_to_cart_fragments', 'bmrk_top_nav_fragments' );



// Update cart fragments in shopping bag

function bmrk_shopping_bag_fragments( $fragments ) {
	global $woocommerce;
	ob_start(); ?>
    <a class="cart-contents-2" href="#" title="<?php esc_attr_e('View your shopping cart', 'benchmark'); ?>"><i class="mdi mdi-shopping_cart"></i><span class="cart-count"><?php echo $woocommerce->cart->cart_contents_count; ?></span></a>
	<?php
	$fragments['.cart-contents-2'] = ob_get_clean();
	return $fragments;
}

add_filter( 'woocommerce_add_to_cart_fragments', 'bmrk_shopping_bag_fragments' );


// Change number of shop/archive columns as chosen in theme options

if ( ! function_exists( 'bmrk_shop_columns' ) ) {
	function bmrk_shop_columns() {
		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();
		return $bmrk_opts[ 'shop-columns' ];
	}
}

add_filter( 'loop_shop_columns', 'bmrk_shop_columns' );


// Set number of cross sells columns to 2
if ( ! function_exists( 'bmrk_cross_sells_columns' ) ) {
	function bmrk_cross_sells_columns() {
		return 2;
	}
}
add_filter( 'woocommerce_cross_sells_columns', 'bmrk_cross_sells_columns' );


// Change number of related products
function benchmark_related_products_args( $args ) {
	$bmrk_opts = benchmark_get_theme_opts();
	
	$args['posts_per_page'] = (int)$bmrk_opts[ 'shop-columns' ]; // 3 related products
	$args['columns'] = (int)$bmrk_opts[ 'shop-columns' ] + 1; // Number of columns is -1 of actual value
	
	return $args;
}

add_filter( 'woocommerce_output_related_products_args', 'benchmark_related_products_args' );


// Remove WooCommerce sidebar on single product if opted to do so in theme options

if ( ! function_exists( 'bmrk_woocommerce_get_sidebar' ) ) {
	function bmrk_woocommerce_get_sidebar() {
		
		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();
		
		if ( ( is_singular( 'product' ) && $bmrk_opts[ 'woo-sb-check' ][ 'single' ] ) || ( ( is_post_type_archive( 'product' ) || is_tax( get_object_taxonomies( 'product' ) ) ) && $bmrk_opts[ 'woo-sb-check' ][ 'shop' ] ) ) {
			return;
		}
		else {
			get_sidebar( 'shop' );
		}
	}
	
}

remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
add_action( 'woocommerce_sidebar', 'bmrk_woocommerce_get_sidebar', 10 );


// Hide WC Breadcrumbs if opted from theme options
if ( ! function_exists( 'bmrk_remove_wc_breadcrumbs' ) ) {
	function bmrk_remove_wc_breadcrumbs() {
		
		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();
		
		if ( ! $bmrk_opts[ 'crumbs-check' ] ) {
			remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
		}
	}
	
}

add_action( 'init', 'bmrk_remove_wc_breadcrumbs' );


// Add a row div wrapper around checkout billing form
if ( ! function_exists( 'bmrk_open_row' ) ) {
	function bmrk_open_row() {
		echo '<div class="row">';
	}
}

if ( ! function_exists( 'bmrk_close_row' ) ) {
	function bmrk_close_row() {
		echo '</div><!-- /.woocommerce-billing-fields .row -->';
	}
}

add_action( 'woocommerce_before_checkout_billing_form', 'bmrk_open_row' );
add_action( 'woocommerce_after_checkout_billing_form', 'bmrk_close_row' );
add_action( 'woocommerce_before_checkout_shipping_form', 'bmrk_open_row' );
add_action( 'woocommerce_after_checkout_shipping_form', 'bmrk_close_row' );

// Show product category image on category archives if available
if ( ! function_exists( 'woocommerce_category_image' ) ) {
	function woocommerce_category_image() {
		if ( is_product_category() ){
			global $wp_query;
			$cat = $wp_query->get_queried_object();
			$thumbnail_id = get_woocommerce_term_meta( $cat->term_id, 'thumbnail_id', true );
			$image = wp_get_attachment_url( $thumbnail_id );
			if ( $image ) {
				echo '<div class="product-archive-image"><img src="' . esc_url( $image ) . '" alt="' . esc_attr( $cat->name ) . '" /></div>';
			}
		}
	}
}

add_action( 'woocommerce_archive_description', 'woocommerce_category_image', 2 );


/**
 * Modify WooCommerce product loop wrapper
 * ul is changed to div
 * inner items are div instead of li
 */

function woocommerce_product_loop_start() {
	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();
	printf ( '<div class="products column-%s">', $bmrk_opts[ 'shop-columns' ] );
}

function woocommerce_product_loop_end() {
	printf ( '</div><!-- /.products -->' );
}


/**
 * Disable WooCommerce layout and smallscreen css file
 * Responsive styles are already included in theme
 */

add_filter( 'woocommerce_enqueue_styles', '__return_false' );


// Add custom product share buttons
function bmrk_product_sharing() {
	
	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();
	
	if ( $bmrk_opts[ 'sharing-check' ] ) :
		echo bmrk_social_sharing( apply_filters( 'benchmark_product_sharing_heading', esc_html__( 'Share this', 'benchmark' ) ), $bmrk_opts[ 'woo-sharing-buttons' ] );
	endif;
	
}

add_action( 'woocommerce_single_product_summary', 'bmrk_product_sharing', 45 );


// Content wrappers
function bmrk_shop_wrapper_start() {
	echo '<main id="main" class="col-xs-12 col-md-9 clearfix">';
}

function bmrk_shop_wrapper_end() {
	echo '</main>';
}

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
add_action( 'woocommerce_before_main_content', 'bmrk_shop_wrapper_start', 10 );
add_action( 'woocommerce_after_main_content', 'bmrk_shop_wrapper_end', 10 );


// Add aqua resizer support to shop thumbnails

function bmrk_woocommerce_get_product_thumbnail( $size = 'shop_catalog', $placeholder_width = 0, $placeholder_height = 0  ) {

	if ( has_post_thumbnail() ) {

		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();
		
		if ( function_exists( 'aq_resize' ) ) {
			$thumb = get_post_thumbnail_id();
			$src = wp_get_attachment_url( $thumb );

			$src = aq_resize( $src, $bmrk_opts[ 'catalog-images' ][ 'width' ], $bmrk_opts[ 'catalog-images' ][ 'height' ], (bool)$bmrk_opts[ 'catalog-misc' ][ '1' ], true, (bool)$bmrk_opts[ 'catalog-misc' ][ '2' ] );

			if ( $src ) {
				return sprintf ( '<img src="%s" alt="%s" />', $src, get_the_title() );
			}
			else {
				return get_the_post_thumbnail();
			}
		}
		else {
			return get_the_post_thumbnail();
		}
	}
	elseif ( wc_placeholder_img_src() ) {
		return wc_placeholder_img( $size );
	}

}

function bmrk_woocommerce_template_loop_product_thumbnail() {
	echo bmrk_woocommerce_get_product_thumbnail();
}

remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
add_action( 'woocommerce_before_shop_loop_item_title', 'bmrk_woocommerce_template_loop_product_thumbnail', 10 );


// Add aqua resizer support in subcategory thumbnails
function benchmark_woocommerce_subcategory_thumbnail( $category ) {
	
	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();
	
	$thumbnail_id = get_woocommerce_term_meta( $category->term_id, 'thumbnail_id', true  );

	if ( $thumbnail_id ) {
		$image = wp_get_attachment_image_src( $thumbnail_id, 'full'  );
		$image = $image[0];
	} else {
		$image = wc_placeholder_img_src();
	}

	if ( function_exists( 'aq_resize' ) ) {
		$resized = aq_resize( $image, $bmrk_opts[ 'shop-cat-images' ][ 'width' ], $bmrk_opts[ 'shop-cat-images' ][ 'height' ], (bool)$bmrk_opts[ 'shop-cat-misc' ][ '1' ], true, (bool)$bmrk_opts[ 'shop-cat-misc' ][ '2' ] );
		if ( $resized ) {
			echo sprintf ( '<img src="%s" alt="%s" />', esc_url( $resized ), esc_attr( get_the_title() ) );
		}
		else {
			echo sprintf ( '<img src="%s" alt="%s" />', esc_url( $image ), esc_attr( get_the_title() ) );
		}
	}

	else {
		echo sprintf ( '<img src="%s" alt="%s" />', esc_url( $image ), esc_attr( get_the_title() ) );
	}
	
}

remove_action( 'woocommerce_before_subcategory_title', 'woocommerce_subcategory_thumbnail', 10 );
add_action( 'woocommerce_before_subcategory_title', 'benchmark_woocommerce_subcategory_thumbnail', 10 );


// Disable automatically generated page titles by WooCommerce
add_filter( 'woocommerce_show_page_title', 'bmrk_disable_woo_titles' );

function bmrk_disable_woo_titles() {
	return false;
}


// Add Wishlist feature in shop and archives
if( ! function_exists( 'bmrk_wishlist_button' ) ){
    function bmrk_wishlist_button() {
		if ( class_exists( 'YITH_WCWL' ) ) {
        	echo do_shortcode( '[yith_wcwl_add_to_wishlist]' );
		}
    }
}

add_action( 'woocommerce_after_shop_loop_item', 'bmrk_wishlist_button' );


// Add custom offer label via custom fields
function bmrk_wc_offer_label() {
	global $post;

	$label = get_post_meta( $post->ID, 'offer_label', true );
	$label = isset( $label ) && ! empty( $label ) ? '<span class="onsale">' . esc_attr( $label ) . '</span>' : '';
	echo $label;
}


// Remove default Sale label

remove_action( 'woocommerce_before_single_product_summary','woocommerce_show_product_sale_flash', 10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
remove_action( 'yith_wcqv_product_image', 'woocommerce_show_product_sale_flash', 10 );


// Add custom offer label

add_action( 'woocommerce_product_thumbnails', 'bmrk_wc_offer_label', 10 );
add_action( 'woocommerce_before_shop_loop_item_title', 'bmrk_wc_offer_label', 10 );
add_action( 'woocommerce_before_single_product_summary', 'bmrk_wc_offer_label', 15 );
add_action( 'yith_wcqv_product_image', 'bmrk_wc_offer_label', 10 );


// Change breadcrumb separator

function benchmark_change_breadcrumb_delim( $defaults ) {
	$defaults['delimiter'] = '<span class="delimiter"></span>';
	return $defaults;
}
add_filter( 'woocommerce_breadcrumb_defaults', 'benchmark_change_breadcrumb_delim' );


/**
 * Remove shop loop item links and title
 * These templates are overridden by copying
 * respective files inside benchmark/woocommerce/ folder
 */
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
remove_action( 'woocommerce_before_subcategory', 'woocommerce_template_loop_category_link_open', 10 );
remove_action( 'woocommerce_after_subcategory', 'woocommerce_template_loop_category_link_close', 10 );
?>