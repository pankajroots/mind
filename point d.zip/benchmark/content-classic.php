<?php
/**
 * Content Loop for archives - Classic Style.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-classic clearfix' ); ?>>

    <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

    if ( $bmrk_opts[ 'archive-meta-check' ] ) : ?>
        <aside id="meta-<?php the_ID();?>" class="entry-meta"><?php echo apply_filters( 'benchmark_post_meta_classic', benchmark_post_meta( 'meta-links-list' ) ); ?></aside>
    <?php endif;

    if ( 'video' == get_post_format() && $bmrk_opts[ 'archive-video-check' ] ) {
        get_template_part( 'formats/format-video' );
    }

    else {
        if ( has_post_thumbnail() ) { ?>
                <div class="post-thumb">
                    <?php if ( 'gallery' == get_post_format() ) { ?>
                        <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                    <?php }

                    elseif ( 'video' == get_post_format() ) { ?>
                        <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                    <?php }

                    if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
                        echo benchmark_post_thumbnail( $bmrk_opts[ 'classic-images' ][ 'width' ], $bmrk_opts[ 'classic-images' ][ 'height' ], (bool)$bmrk_opts[ 'classic-misc' ][ '1' ], (bool)$bmrk_opts[ 'classic-misc' ][ '2' ] );
                    }

                    else { ?>

                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                        <?php
                        echo benchmark_post_thumbnail( $bmrk_opts[ 'classic-images' ][ 'width' ], $bmrk_opts[ 'classic-images' ][ 'height' ], (bool)$bmrk_opts[ 'classic-misc' ][ '1' ], (bool)$bmrk_opts[ 'classic-misc' ][ '2' ] );
                        ?>
                    </a>

                    <?php } ?>

                </div><!-- /.post-thumb -->
            <?php } // has_post_thumbnail
    }

    if ( 'excerpt' == $bmrk_opts[ 'classic-content-check' ] ) {
        echo '<p class="post-excerpt">' . benchmark_short( get_the_excerpt(), $bmrk_opts[ 'excerpt-length-classic' ] ) . '</p>'; ?>
        <p><a class="more-link btn-flat" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php esc_html_e( 'Read more', 'benchmark' ); ?></a></p>
    <?php }

    else {
        the_content( __( 'Read more', 'benchmark' ) );
    } ?>

</article><!-- /#post-<?php the_ID(); ?> -->