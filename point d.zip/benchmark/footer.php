<?php
/**
 * The template for displaying footer.
 *
 * Contains secondary widget areas, footer content and the closing of the
 * parent div elements.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

	// Page options

	$hide_sec_a = false;
	$hide_sec_b = false;

	if ( is_page() ) {
		global $post;
		$page_opts = get_post_meta( $post->ID, 'bmrk_page_opts', true );
		$hide_sec_a = isset( $page_opts[ 'hide_sec_a' ] ) ? $page_opts[ 'hide_sec_a' ] : false;
		$hide_sec_b = isset( $page_opts[ 'hide_sec_b' ] ) ? $page_opts[ 'hide_sec_b' ] : false;
	}
?>
			</div><!-- /.content-row -->
		</div><!-- /.site-content -->
	</div><!-- /#primary -->

	<?php // Secondary widget area A

	if ( ! $hide_sec_a ) {

		if ( is_active_sidebar( 'secondary-area-a' ) ) :
			if ( $bmrk_opts[ 'swa-a-check' ] ) : ?>
				<div id="secondary-a" class="secondary widget-area" role="complementary">
					<div class="container clearfix">
						<div class="row gutter-24 sec-row">
							<?php dynamic_sidebar( 'secondary-area-a' ); ?>
						</div><!-- /.sec-row -->
					</div><!-- /.container -->
				</div><!-- /#secondary-a -->
			<?php endif;
		endif;

	}

	// Secondary widget area B

	if ( ! $hide_sec_b ) {

		if ( is_active_sidebar( 'secondary-area-b' ) ) :
			if ( $bmrk_opts[ 'swa-b-check' ] ) : ?>
				<div id="secondary-b" class="secondary widget-area" role="complementary">
					<div class="container clearfix">
						<div class="row gutter-24 sec-row">
							<?php dynamic_sidebar( 'secondary-area-b' ); ?>
						</div><!-- /.sec-row -->
					</div><!-- /.container -->
				</div><!-- /#secondary-b -->
			<?php endif;
		endif;

	}
	?>
	<footer id="footer">
		<div class="container clearfix">
			<?php echo do_shortcode( $bmrk_opts[ 'footer-text' ] ); ?>
		</div><!-- /.container -->
	</footer><!-- /#footer -->

    <div id="scroll-to-top" class="scroll-to-top">
        <a href="#" title="<?php esc_attr_e( 'Scroll to top', 'benchmark' ); ?>"><span class="sr-only"><?php esc_html_e( 'top', 'benchmark' ); ?></span></a>
    </div><!-- /.scroll-to-top -->

    <div class="resp-menu-mask"></div><!-- /.resp-menu-mask -->

    </div> <!-- /#page -->
    <?php wp_footer(); ?>
    </body>
</html>