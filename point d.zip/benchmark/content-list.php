<?php
/**
 * Content Loop for archives - List Style.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-list clearfix' ); ?>>

  <?php if ( has_post_thumbnail() ) { ?>
                <div class="post-thumb">
                    <?php if ( 'gallery' == get_post_format() ) { ?>
                        <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                    <?php }

                    elseif ( 'video' == get_post_format() ) { ?>
                        <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                    <?php }

                if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
                        echo benchmark_post_thumbnail( $bmrk_opts[ 'list-images' ][ 'width' ], $bmrk_opts[ 'list-images' ][ 'height' ], (bool)$bmrk_opts[ 'list-misc' ][ '1' ], (bool)$bmrk_opts[ 'list-misc' ][ '2' ] );
                        }

                    else { ?>

                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                        <?php
                        echo benchmark_post_thumbnail( $bmrk_opts[ 'list-images' ][ 'width' ], $bmrk_opts[ 'list-images' ][ 'height' ], (bool)$bmrk_opts[ 'list-misc' ][ '1' ], (bool)$bmrk_opts[ 'list-misc' ][ '2' ] );
                        ?>
                    </a>

                    <?php } ?>

                </div><!-- /.post-thumb -->

        <?php $content_right_class = 'entry-content'; ?>

    <?php }
    else {
        $content_right_class = 'entry-content no-thumbnail';
    }
    ?>

    <div class="<?php echo esc_attr( $content_right_class ); ?>">

        <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

        echo '<p class="post-excerpt">' . benchmark_short( get_the_excerpt(), $bmrk_opts[ 'excerpt-length-list' ] ) . '</p>';

        if ( $bmrk_opts[ 'archive-meta-check' ] ) : ?>
            <aside id="meta-<?php the_ID(); ?>" class="entry-meta list"><?php echo apply_filters( 'benchmark_post_meta_list_big', benchmark_post_meta( 'meta-links-list' ) ); ?></aside>
        <?php endif; ?>

    </div><!-- /.entry-right -->

</article><!-- /#post-<?php the_ID(); ?> -->