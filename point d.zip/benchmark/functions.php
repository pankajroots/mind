<?php
/**
 * Benchmark functions and definitions.
 *
 * Contains helper functions used in the theme, along with functions
 * that are attached to action and filter hooks in WordPress.

 * Most functions in this file are pluggable, and can be used in Child Theme.
 * Functions that are not pluggable (not wrapped in function_exists()) are attached
 * to a filter or action hook.
 *
 */

/**
 * Sets up the content width value based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) )
	$content_width = 660;


/**
 * Sets up theme defaults and registers support for various WordPress features.
 */

if ( ! function_exists( 'benchmark_setup' ) ) :

	function benchmark_setup() {

		// Make theme available for translation
		load_theme_textdomain( 'benchmark', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Title tag automatically managed by WordPress
		add_theme_support( 'title-tag' );

		// Post thumbnails support
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 800, 9999, false );

		// This theme uses wp_nav_menu() in one location
		register_nav_menus( array(
			'primary'	=> esc_html__( 'Primary Menu', 'benchmark' )
		) );

		// Output valid html5 for the following
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

		// Post formats
		add_theme_support( 'post-formats', array( 'video', 'gallery' ) );

		// Setup the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'benchmark_custom_background_args', array(
			'default-color'      => 'ffffff',
			'default-attachment' => 'fixed',
		) ) );

		// Declare theme as WooCommerce compatible
		add_theme_support( 'woocommerce' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );	

		// Basic editor style resembling theme styles
		add_editor_style( 'css/editor-style.css' );

	}
endif;

add_action( 'after_setup_theme', 'benchmark_setup' );

/**
 * Returns theme options variable
 */

if ( ! function_exists( 'benchmark_get_theme_opts' ) ) :

	function benchmark_get_theme_opts() {

		// Set theme options variable from JSON file when Redux Framework plugin is not available
		$bmrk_opts = get_option( 'bmrk_opts' );

		if ( ! class_exists( 'ReduxFrameworkPlugin' ) || ! $bmrk_opts ) {

			$json_file = get_template_directory_uri() . '/includes/theme-defaults.json';

			// Get remote JSON file
			$response = wp_remote_get( $json_file );

			// Check for error
			if ( is_wp_error( $response ) ) {
				return;
			}

			// Parse remote JSON file
			$data = wp_remote_retrieve_body( $response );

			// Check for error
			if ( is_wp_error( $data ) ) {
				return;
			}

			// Set default vars from data
			$bmrk_opts = json_decode( $data, true );

		}
		return $bmrk_opts;
	}

endif;


/**
 * Include required files
 */

require_once( trailingslashit( get_template_directory() ) . 'includes/theme-config.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/class-tgm-plugin-activation.php' );
require_once( trailingslashit( get_template_directory() ) . 'woocommerce/woocommerce-hooks.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/page-builder-layouts.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/page-options.php' );
require_once( trailingslashit( get_template_directory() ) . 'includes/post-options.php' );


/**
 * Enqueue scripts and styles for front-end.
 */
function benchmark_scripts_styles() {
	global $wp_query, $post, $wp_styles, $bmrk_opts;

	// Load our main stylesheet.
	wp_enqueue_style( 'benchmark-style', get_stylesheet_uri() );

	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'benchmark-ie', get_template_directory_uri() . '/css/ie.css', array( 'benchmark-style' ), '' );
	wp_style_add_data( 'benchmark-ie', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	wp_enqueue_style( 'benchmark-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'benchmark-style' ), '' );
	wp_style_add_data( 'benchmark-ie7', 'conditional', 'lt IE 8' );

	// WooCommerce Custom stylesheet
	if ( class_exists( 'woocommerce' )  ) {
		wp_register_style( 'woocommerce-custom', get_template_directory_uri() . '/woocommerce/woocommerce-custom.css', array( 'benchmark-style' ), '' );
		wp_enqueue_style( 'woocommerce-custom' );
	}

	// Color schemes

	$color_scheme = $bmrk_opts[ 'color-scheme' ];

	if ( is_page() ) {
		global $post;

		// Check if a per page color scheme is available
		$page_opts 		= get_post_meta( $post->ID, 'bmrk_page_opts', true );
		$color_scheme 	= isset( $page_opts[ 'color_scheme' ] ) && 'global' != $page_opts[ 'color_scheme' ] ? $page_opts[ 'color_scheme' ] : $bmrk_opts[ 'color-scheme' ];

	}

	if ( $color_scheme != 'default' ) {
		$scheme_url = get_template_directory_uri() . '/css/schemes/' . $color_scheme . '.css';
		wp_register_style( 'benchmark-' . $bmrk_opts[ 'color-scheme' ] . '-scheme', $scheme_url, array( 'benchmark-style' ), '' );
		wp_enqueue_style( 'benchmark-' . $bmrk_opts[ 'color-scheme' ] . '-scheme' );
	}

	// RTL stylesheet
	// @todo in next versions
	/*if ( $bmrk_opts[ 'rtl-css' ] || is_rtl() ) {
		wp_register_style( 'benchmark-rtl', get_template_directory_uri() . '/rtl.css', array( 'benchmark-style' ), '' );
		wp_enqueue_style( 'benchmark-rtl' );
	}*/

	// Responsive stylesheet
	if ( $bmrk_opts[ 'resp-mode' ] ) {
		wp_register_style( 'benchmark-responsive', get_template_directory_uri() . '/responsive.css', array( 'benchmark-style' ), '' );
		wp_enqueue_style( 'benchmark-responsive' );
	}

	// Load icon fonts from theme if the Bonanza Shortcodes plugin is not active
	if ( ! class_exists( 'Bonanza_Shortcodes' ) ) {
		if ( ! wp_style_is( 'material-icons', 'enqueued' ) ) {
			wp_enqueue_style( 'material-icons', get_template_directory_uri() . '/css/material-icons.css', array(), null );
		}

		if ( ! wp_style_is( 'fontawesome', 'enqueued' ) ) {
			wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), null );
		}

		if ( ! wp_style_is( 'simple-line-icons', 'enqueued' ) ) {
			wp_enqueue_style( 'simple-line-icons', get_template_directory_uri() . '/css/simple-line-icons.css', array(), null );
		}
	}

	// Threaded comments
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Masonry
	if ( $bmrk_opts[ 'masonry-check' ] &&
			(
				( 	( is_home() || is_archive() || is_search() )
					&& 'grid' == $bmrk_opts[ 'archive-style' ]
				)
				|| is_page_template( 'templates/blog-grid.php' )
				|| is_page_template( 'templates/port-grid.php' )
				|| ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'ss_posts') )
			)
		) {
			wp_enqueue_script( 'jquery-masonry' );
	}

	// Custom JS functions
	wp_enqueue_script( 'benchmark-custom', get_template_directory_uri() . '/js/custom.js', array( 'jquery' ), '', true );

	// Localization variables
	wp_localize_script(
		'benchmark-custom', 'bmrk_custom', array(
			'expand_menu_text' => esc_html__( 'Expand or collapse menu items', 'benchmark' ),
			'navbar_type' => $bmrk_opts[ 'navbar-type' ],
			'header_overlay' => isset( $header_overlay ) ? $header_overlay : false,
			'layout_width' => floatval( $bmrk_opts[ 'layout-width' ] )
	) );
}

add_action( 'wp_enqueue_scripts', 'benchmark_scripts_styles', '20' );


/**
 * Register theme widget areas
 */
function benchmark_widget_areas() {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	$widget_class = array();
	$i = 1;

	$widget_columns = array (
		$bmrk_opts[ 'pwa-columns' ],
		$bmrk_opts[ 'cwa-a-columns' ],
		$bmrk_opts[ 'cwa-b-columns' ],
		$bmrk_opts[ 'sec-a-columns' ],
		$bmrk_opts[ 'sec-b-columns' ]
	);

	foreach ( $widget_columns as $widget_column ) {
		switch( $widget_column ) {
			case '1' :
				$widget_class[$i] = 'col-md-12';
			break;

			case '2' :
				$widget_class[$i] = 'wcol-2 col-xs-6';
			break;

			case '3' :
				$widget_class[$i] = 'wcol-3 col-xs-6 col-sm-4';
			break;

			case '4' :
				$widget_class[$i] = 'wcol-4 col-xs-6 col-md-3';
			break;

			case '6' :
				$widget_class[$i] = 'wcol-6 col-xs-6 col-sm-4 col-md-2';
			break;
		}
		$i++;

	}

	register_sidebar( array(
		'name' 			=> esc_html__( 'Sidebar widget area', 'benchmark' ),
		'id' 			=> 'sidebar-widget-area',
		'description' 	=> esc_html__( 'The main sidebar widget area', 'benchmark' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' 	=> "</aside>",
		'before_title' 	=> '<h3 class="widget-title">',
		'after_title' 	=> '</h3>'
	) );

	register_sidebar( array(
		'name' 			=> esc_html__( 'Primary widget area', 'benchmark' ),
		'id' 			=> 'primary-widget-area',
		'description' 	=> esc_html__( 'Widget area before main content and sidebar', 'benchmark' ),
		'before_widget' => '<aside id="%1$s" class="pwa widget ' . $widget_class[1] . ' %2$s">',
		'after_widget'	=> "</aside>",
		'before_title' 	=> '<h3 class="widget-title">',
		'after_title' 	=> '</h3>'
	) );

	register_sidebar( array(
		'name' 			=> esc_html__( 'Content widget area - A', 'benchmark' ),
		'id' 			=> 'content-widget-area-a',
		'description' 	=> esc_html__( 'Inline widget area before main content', 'benchmark' ),
		'before_widget' => '<aside id="%1$s" class="cwa widget ' . $widget_class[2] . ' %2$s">',
		'after_widget'	=> "</aside>",
		'before_title' 	=> '<h3 class="widget-title">',
		'after_title' 	=> '</h3>'
	) );

	register_sidebar( array(
		'name' 			=> esc_html__( 'Content widget area - B', 'benchmark' ),
		'id' 			=> 'content-widget-area-b',
		'description' 	=> esc_html__( 'Inline widget area after main content', 'benchmark' ),
		'before_widget' => '<aside id="%1$s" class="cwa widget ' . $widget_class[3] . ' %2$s">',
		'after_widget'	=> "</aside>",
		'before_title' 	=> '<h3 class="widget-title">',
		'after_title' 	=> '</h3>'
	) );

	register_sidebar( array(
		'name' 			=> esc_html__( 'Secondary Area - A', 'benchmark' ),
		'id' 			=> 'secondary-area-a',
		'description' 	=> esc_html__( 'Wide widget area A before footer', 'benchmark' ),
		'before_widget' => '<aside id="%1$s" class="widget ' . $widget_class[4] . ' %2$s">',
		'after_widget' 	=> "</aside>",
		'before_title' 	=> '<h3 class="widget-title">',
		'after_title' 	=> '</h3>'
	) );

	register_sidebar( array(
		'name' 			=> esc_html__( 'Secondary Area - B', 'benchmark' ),
		'id' 			=> 'secondary-area-b',
		'description' 	=> esc_html__( 'Wide widget area B before footer', 'benchmark' ),
		'before_widget' => '<aside id="%1$s" class="widget ' . $widget_class[5] . ' %2$s">',
		'after_widget' 	=> "</aside>",
		'before_title' 	=> '<h3 class="widget-title">',
		'after_title' 	=> '</h3>'
	) );
}

add_action( 'widgets_init', 'benchmark_widget_areas' );


/**
 * Enqueue html5 script in head section for old browsers
 */
function benchmark_html5_js() { ?>
    <!--[if lt IE 9]>
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
    <![endif]-->
<?php }

add_action( 'wp_head', 'benchmark_html5_js' );


/**
 * Generate layout width CSS as set in Theme Options
 */
function benchmark_layout_width() {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	$bmrk_layout_width = $bmrk_opts[ 'layout-width' ];

	if ( floatval( $bmrk_opts[ 'layout-width' ] ) < 800 ) {
		$bmrk_layout_width = 800;
	}

	if ( floatval( $bmrk_opts[ 'layout-width' ] ) > 2000 ) {
		$bmrk_layout_width = 2000;
	}
	?>
	<style type="text/css">
		#page,
		.is-boxed.fixed-nav #header {
			max-width: <?php echo ( floatval( $bmrk_layout_width ) + 80 ) . 'px' ?>;
		}
		.container {
			max-width: <?php echo floatval( $bmrk_layout_width ) . 'px' ?>;
		}
	</style>
<?php }

add_action( 'wp_head', 'benchmark_layout_width' );


/**
 * Allow custom head markup to be inserted by user from Theme Options
 */
function benchmark_custom_head_code() {
	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	if ( ! empty( $bmrk_opts[ 'custom-head-code' ] ) ) {
		echo $bmrk_opts[ 'custom-head-code' ];
	}
	else {
		return;
	}
}

add_action( 'wp_head', 'benchmark_custom_head_code');


/**
 * Post meta information
 */
if ( ! function_exists( 'benchmark_post_meta' ) ) :
	function benchmark_post_meta( $type ) {

		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();

		$type = isset($type) ? $type : 'meta-links';

		$list_class = 'meta-list';

		if ( 'meta-links-grid' == $type ) {
			$list_class = 'card-meta';
		}

		$list_output = '';

		$out = '<ul class="' . $list_class . '">';

		foreach ( $bmrk_opts[ $type ] as $key=>$value) {

			switch($key) {
				case 'date':
					if ( $bmrk_opts[ $type ][ 'date' ] ) :

						if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
							$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}

							$time_string = sprintf( $time_string,
								esc_attr( get_the_date( 'c' ) ),
								get_the_date(),
								esc_attr( get_the_modified_date( 'c' ) ),
								get_the_modified_date()
							);

							$list_output .= sprintf( '<li class="posted-on"><span class="screen-reader-text">%1$s </span><a href="%2$s" rel="bookmark">%3$s%4$s</a></li>',
								esc_html_x( 'Posted on', 'Used before publish date.', 'benchmark' ),
								esc_url( get_permalink() ),
								$type != 'meta-links-grid' ? '<i class="mdi mdi-event"></i>' : '',
								$time_string
							);
						}

					endif;
				break;

				case 'author':

					if ( $bmrk_opts[ $type ][ 'author' ] ) :

						if ( 'post' == get_post_type() ) {
							if ( is_singular() || is_multi_author() ) {
								$list_output .= sprintf( '<li class="byline"><span class="author vcard"><span class="screen-reader-text">%1$s </span><a class="url fn n" href="%2$s">%3$s%4$s</a></span></li>',
									esc_html_x( 'Author', 'Used before post author name.', 'benchmark' ),
									esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
									$type != 'meta-links-grid' ? '<i class="mdi mdi-person"></i>' : '',
									get_the_author()
								);
							}
							else {
								$list_output .= sprintf( '<li class="byline"><span class="screen-reader-text">%1$s </span><a href="%2$s">%3$s%4$s</a></li>',
									esc_html_x( 'Author', 'Used before post author name.', 'benchmark' ),
									esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
									$type != 'meta-links-grid' ? '<i class="mdi mdi-person"></i>' : '',
									get_the_author()
								);
							}
						}

					endif;
				break;

				case 'cats':
					if ( $bmrk_opts[ $type ][ 'cats' ] ) :

						if ( 'post' == get_post_type() ) {
							$categories_list = get_the_category_list( esc_html_x( ', ', 'Used between list items, there is a space after the comma.', 'benchmark' ) );
							if ( $categories_list ) {
								$list_output .= sprintf( '<li class="cat-links"><span class="screen-reader-text">%1$s </span>%2$s%3$s</li>',
									esc_html_x( 'Categories', 'Used before category names.', 'benchmark' ),
									$type != 'meta-links-grid' ? '<i class="mdi mdi-folder"></i>' : '',
									$categories_list
								);
							}
						}

					endif;
				break;

				case 'tags':
					if ( $bmrk_opts[ $type ][ 'tags' ] ) :

						if ( 'post' == get_post_type() ) {
							$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'Used between list items, there is a space after the comma.', 'benchmark' ) );
							if ( $tags_list ) {
								$list_output .= sprintf( '<li class="tags-links"><span class="screen-reader-text">%1$s </span>%2$s%3$s</li>',
									esc_html_x( 'Tags', 'Used before tag names.', 'benchmark' ),
									$type != 'meta-links-grid' ? '<i class="mdi mdi-bookmark"></i>' : '',
									$tags_list
								);
							}
						}

					endif;
				break;

				case 'comments':
					if ( $bmrk_opts[ $type ][ 'comments' ] ) :

						if ( ! post_password_required() && ( comments_open() && get_comments_number() ) ) {
							$number = (int) get_comments_number( get_the_ID() );
							$list_output .= sprintf( '<li class="comments-link"><a href="%1$s" title="%2$s"><span class="screen-reader-text">%2$s </span>%4$s%5$s</a></li>',
								get_comments_link(),
								sprintf( esc_html__( 'Comment on %s', 'benchmark' ), get_the_title() ),
								esc_html_x( 'Comments', 'Used before comments link.', 'benchmark' ),
								$type != 'meta-links-grid' ? '<i class="mdi mdi-mode_comment"></i>' : '',
								(int) get_comments_number( get_the_ID() )
							 );
						}


					endif;
				break;

				case 'edit':
					if ( $bmrk_opts[ $type ][ 'edit' ] ) :
						if ( current_user_can( 'edit_posts' ) && is_single() )
							$list_output .= sprintf( '<li class="edit-link"><a href="%1$s" title="%2$s"><i class="mdi mdi-edit"></i>%2$s</a></li>', get_edit_post_link(), esc_html__( 'Edit', 'benchmark' ) );
						endif;
				break;

				case 'morelink':
					if ( $bmrk_opts[ $type ][ 'morelink' ] ) :

						$list_output .= sprintf( '<li class="more-link"><a href="%1$s">%2$s%3$s</a></li>',
							esc_url( get_permalink() ),
							$type != 'meta-links-grid' ? '<i class="mdi mdi-link"></i>' : '',
							esc_html__( 'Read more', 'benchmark' )
						);

					endif;
				break;
			} // Switch
		} // Foreach

		if ( is_attachment() && wp_attachment_is_image() ) {
			// Retrieve attachment metadata.
			$metadata = wp_get_attachment_metadata();

			$list_output .= sprintf( '<li class="full-size-link"><span class="screen-reader-text">%1$s </span><a href="%2$s"><i class="fa fa-image"></i>%3$s &times; %4$s</a></li>',
				esc_html_x( 'Full size', 'Used before full size attachment link.', 'benchmark' ),
				esc_url( wp_get_attachment_url() ),
				$metadata['width'],
				$metadata['height']
			);
		}

		// Support any extra meta item via action hook
		ob_start();
		do_action( 'benchmark_post_meta_items' );
		$list_output .= ob_get_contents();
		ob_end_clean();
		if ( $list_output == '' ) {
			return;
		}
		else {
			return $out . $list_output . '</ul>';
		}
	}
endif;


/**
 * Post meta in grid archives
 */
if ( ! function_exists( 'benchmark_footer_actions' ) ) :
	function benchmark_footer_actions() {

		$out = '<ul class="card-actions">';

		$out .= apply_filters( 'benchmark_grid_actions_buttons', sprintf( '<li class="more-link"><a href="%1$s">%2$s</a></li>', esc_url( get_permalink() ), apply_filters( 'benchmark_grid_readmore_button', esc_html__( 'Explore', 'benchmark' ) ) ) );

		$out .= '</ul>';

		// Start action buttons output
		$out .= '<ul class="card-action-buttons">';

		if ( comments_open() ) {
			$out .= apply_filters( 'benchmark_grid_actions_icons', sprintf( '<li><span class="screen-reader-text">%1$s </span><a href="%2$s" class="comment-link" title="%1$s">%3$s<i class="mdi mdi-mode_comment"></i></a></li>',
				sprintf( esc_html__( 'Comment on %s', 'benchmark' ), esc_attr( get_the_title() ) ),
				esc_url( get_comments_link() ),
				get_comments_number() > 0 ? '<span class="comment-number">' . get_comments_number() . '</span>' : ''
			) );
		}

		$out .= '</ul>';

		return apply_filters( 'benchmark_post_meta_grid', $out );

	}
endif;

/**
 * Add body class to the theme depending upon selected options and templates
 */
function benchmark_grid_post_meta( $classes ) {
	echo benchmark_post_meta( 'meta-links-grid' );
}

add_action( 'benchmark_after_grid_title', 'benchmark_grid_post_meta', 4 );


/**
 * Add body class to the theme depending upon selected options and templates
 */
function benchmark_body_class( $classes ) {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();
	$color_scheme = $bmrk_opts[ 'color-scheme' ];

	if ( (
			(
				! ( is_post_type_archive( 'product' ) || is_tax( get_object_taxonomies( 'product' ) ) )
				&& 'left' == $bmrk_opts[ 'sb-pos' ]
			)
			||
			(
				( is_post_type_archive( 'product' ) || is_tax( get_object_taxonomies( 'product' ) ) )
				&& 'left' == $bmrk_opts[ 'shop-sb-pos' ]
			)
			||
			( is_singular( 'product' ) && 'left' == $bmrk_opts[ 'product-sb-pos' ] )

		) ) {
		$classes[] = 'sidebar-left';
	}

	/**
	 * @todo Add RTL classes
	 * if ( $bmrk_opts[ 'rtl-css' ] || is_rtl() ) {
		$classes[] = 'rtl';
	 * }
	 */

	if (
		( is_archive() && ! ( is_post_type_archive( 'product' ) || is_tax( get_object_taxonomies( 'product' ) ) ) && ! $bmrk_opts[ 'archive-sb-check' ] )
		||
		( is_singular( 'product' ) && $bmrk_opts[ 'woo-sb-check' ][ 'single' ] )
		||
		(
			( is_post_type_archive( 'product' ) || is_tax( get_object_taxonomies( 'product' ) ) ) && $bmrk_opts[ 'woo-sb-check' ][ 'shop' ]
		)
		||
		( ! is_singular( 'product' ) && is_single() && ! $bmrk_opts[ 'single-sb-check' ] )
	 ) {
		$classes[] = 'full-width';
	}

	if ( ! is_singular( 'product' ) && is_single() ) {
		global $post;

		// Fetch post options
		$post_opts 			= get_post_meta( $post->ID, 'bmrk_post_options', true );
		$sb_placement 		= isset( $post_opts[ 'sb_placement' ] ) ? $post_opts[ 'sb_placement' ] : 'global';
	}

	$classes[] = 'is-' . $bmrk_opts[ 'layout-style' ];

	if ( is_page() ) {
		global $post;

		// Fetch page options for per page header area settings
		$page_opts 			= get_post_meta( $post->ID, 'bmrk_page_opts', true );
		$hide_hero 			= isset( $page_opts[ 'hide_hero' ] ) ? $page_opts[ 'hide_hero' ] : false;
		$one_page_menu 		= isset( $page_opts[ 'one_page_menu' ] ) ? $page_opts[ 'one_page_menu' ] : false;
		$transparent_nav 	= isset( $page_opts[ 'transparent_nav' ] ) ? $page_opts[ 'transparent_nav' ] : false;
		$hide_top_nav 		= isset( $page_opts[ 'hide_top_nav' ] ) ? $page_opts[ 'hide_top_nav' ] : false;
		$hide_main_nav 		= isset( $page_opts[ 'hide_main_nav' ] ) ? $page_opts[ 'hide_main_nav' ] : false;
		$force_white_color 	= isset( $page_opts[ 'force_white_color' ] ) ? $page_opts[ 'force_white_color' ] : false;
		$color_scheme 		= isset( $page_opts[ 'color_scheme' ] ) && 'global' != $page_opts[ 'color_scheme' ] ? $page_opts[ 'color_scheme' ] : $bmrk_opts[ 'color-scheme' ];

		if ( $hide_hero ) {
			$classes[] = 'hero-disabled';
		}

		if ( $one_page_menu ) {
			$classes[] = 'one-page-enabled';
		}

		if ( $transparent_nav ) {
			$classes[] = 'transparent-nav';
		}

		if ( $hide_top_nav ) {
			$classes[] = 'perpage-topbar-disabled';
		}

		if ( $hide_main_nav ) {
			$classes[] = 'perpage-main-nav-disabled';
		}

		if ( $force_white_color ) {
			$classes[] = 'force-white';
		}

	}

	if ( $bmrk_opts[ 'top-bar-check' ] ) {
		$classes[] = 'global-topbar-enabled';
	}

	if ( $bmrk_opts[ 'navbar-type' ] ) {
		$classes[] = $bmrk_opts[ 'navbar-type' ] . '-nav';
	}

	$classes[] = 'scheme-' . $color_scheme;

	return $classes;
}

add_filter( 'body_class', 'benchmark_body_class' );


/**
 * Related Posts feature on Single Posts
 */
if ( ! function_exists( 'benchmark_related_posts' ) ) :

	function benchmark_related_posts() {
		
		global $post;
		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();
		$args = '';

		if ( 'tags' == $bmrk_opts[ 'rp-taxonomy' ] ) {
			$tags = wp_get_post_tags( $post->ID );
			if ( $tags ) {
				$tag_ids = array();
				foreach ( $tags as $individual_tag ) {
					$tag_ids[] = $individual_tag->term_id;
				}
				$args = array(
					'tag__in' 				=> $tag_ids,
					'post__not_in' 			=> array( $post->ID ),
					'posts_per_page'		=> $bmrk_opts[ 'rp-num' ],
					'orderby' 				=> apply_filters( 'benchmark_related_posts_orderby', 'rand' )
				);
			} // if tags
		} // taxonomy tags
		else {
			$categories = get_the_category( $post->ID );
			if ( $categories ) {
				$category_ids = array();
				foreach( $categories as $individual_category )
					$category_ids[] = $individual_category->term_id;
					$args = array(
						'category__in' 			=> $category_ids,
						'post__not_in' 			=> array( $post->ID ),
						'posts_per_page'		=> $bmrk_opts[ 'rp-num' ],
						'orderby'				=> apply_filters( 'benchmark_related_posts_orderby', 'rand' )
					);
			} // if categories
		} // taxonomy categories

		$related_posts_query = new WP_Query( $args );

		if ( $related_posts_query->have_posts() ) : ?>
            <div id="benchmark-related-posts" class="related-posts">

                <h3><?php printf( apply_filters( 'benchmark_related_posts_heading', esc_html__( 'Related content', 'benchmark' ) ) ); ?></h3>

                <?php if ( 'thumbnail' == $bmrk_opts[ 'rp-style' ] ) {
					echo '<div class="related-grid clearfix">';
				}
                else {
					echo '<ul class="plain-list">';
				}

                while( $related_posts_query->have_posts() ) :

					$related_posts_query->the_post();

					if ( 'thumbnail' == $bmrk_opts[ 'rp-style' ] ) {
						if ( has_post_thumbnail() ) { ?>
                        <div class="related-inner">
                            <div class="related-item">
                                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                    <div class="related-content">
										<?php the_title( '<h3>', '</h3>' );
                                        if ( 'gallery' == get_post_format() ) { ?>
                                        <span class="post-format-icon mdi mdi-photo_library"></span>
                                        <?php }

                                        elseif ( 'video' == get_post_format() ) { ?>
                                        <span class="post-format-icon mdi mdi-play_circle_filled"></span>
                                        <?php } ?>
                                    </div><!-- /.related-content -->

                                    <?php
                                    echo benchmark_post_thumbnail( $bmrk_opts[ 'related-images' ][ 'width' ], $bmrk_opts[ 'related-images' ][ 'height' ], (bool)$bmrk_opts[ 'related-misc' ][ '1' ], (bool)$bmrk_opts[ 'related-misc' ][ '2' ] );
                                    ?>
                                </a>
                            </div><!-- /.related-item -->
                        </div><!-- /.related-inner -->
					<?php } // has_post_thumbnail()
					}
					else { ?>
						<li><h3><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3></li>
					<?php } ?>

                <?php endwhile; // while have posts

				if ( 'thumbnail' == $bmrk_opts[ 'rp-style' ] ) {
					echo '</div>';
				}
				else {
					echo '</ul>';
				}
				?>
            </div><!-- /.related-posts -->
		<?php endif; // if have posts
        wp_reset_query();
        wp_reset_postdata();
	}
endif;

/**
 * Social Sharing feature on single posts
 */
if ( ! function_exists( 'bmrk_social_sharing' ) ) :
	function bmrk_social_sharing( $sharing_heading, $sharing_buttons, $overlay = false ) {
		global $post;

		setup_postdata( $post );

		// Set variables
		$out = '';
		$list = '';
		$share_image = '';
		$protocol = is_ssl() ? 'https' : 'http';
		$permalink = get_permalink();
		$title = get_the_title();

		if ( has_post_thumbnail( $post->ID ) ) {
			$share_image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
		}

		$share_content = strip_tags( get_the_excerpt() );

		$out .= '<div id="benchnark-social-sharing" class="ss-sharing-container"><div class="row">';

		if ( ! empty( $sharing_heading ) ) {
			$out .= '<div class="col-sm-4"><h3>' . apply_filters( 'benchmark_social_sharing_heading', esc_html__( 'Share this', 'benchmark' ) ) . '</h3></div>';
			$buttons_class = "col-sm-8 text-right";
		}
		else {
			$buttons_class = "col-sm-12";
		}

		$out .= '<div class="' . $buttons_class . '"><ul class="ss-sharing clearfix">';
		

		foreach ( $sharing_buttons as $key=>$value ) {

			switch($key) {

				case '1':
					if ( $sharing_buttons[ '1' ] ) :
						$list .= sprintf( '<li class="ss-twitter"><a href="%s://twitter.com/home?status=%s" target="_blank" title="%s"><i class="fa fa-twitter"></i>%s</a></li>', $protocol, urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on twitter', 'benchmark' ), $overlay ? esc_attr__( 'Twitter', 'benchmark' ) : '<span class="sr-only">twitter</span>' );
					endif;
				break;

				case '2':
					if ( $sharing_buttons[ '2' ] ) :
						$list .= sprintf( '<li class="ss-facebook"><a href="%s://www.facebook.com/sharer/sharer.php?u=%s" target="_blank" title="%s"><i class="fa fa-facebook"></i>%s</a></li>', $protocol, urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on facebook', 'benchmark' ), $overlay ? esc_attr__( 'Facebook', 'benchmark' ) : '<span class="sr-only">facebook</span>' );
					endif;
				break;

				case '3':
					if ( $sharing_buttons[ '3' ] ) :
						$list .= sprintf( '<li class="ss-linkedin"><a href="%s://www.linkedin.com/shareArticle?mini=true&amp;url=%s" target="_blank" title="%s"><i class="fa fa-linkedin"></i>%s</a></li>', $protocol, urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on LinkedIn', 'benchmark' ), $overlay ? esc_attr__( 'LinkedIn', 'benchmark' ) : '<span class="sr-only">linkedin</span>' );
					endif;
				break;

				case '4':
					if ( $sharing_buttons[ '4' ] ) :
						$list .= sprintf( '<li class="ss-gplus"><a href="%s://plus.google.com/share?url=%s" target="_blank" title="%s"><i class="fa fa-google-plus"></i>%s</a></li>', $protocol, urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share on Google+', 'benchmark' ), $overlay ? esc_attr__( 'Google+', 'benchmark' ) : '<span class="sr-only">google+</span>' );
					endif;
				break;

				case '5':
					if ( $sharing_buttons[ '5' ] ) :
						$list .= sprintf( '<li class="ss-pint"><a href="%s://pinterest.com/pin/create/button/?url=%s&amp;media=%s" target="_blank" title="%s"><i class="fa fa-pinterest"></i>%s</a></li>', $protocol, urlencode( esc_url( get_permalink() ) ), esc_url( $share_image ), esc_attr__( 'Pin it', 'benchmark' ), $overlay ? esc_attr__( 'Pinterest', 'benchmark' ) : '<span class="sr-only">pinterest</span>' );
					endif;
				break;

				case '6':
					if ( $sharing_buttons[ '6' ] ) :
						$list .= sprintf( '<li class="ss-vk"><a href="%s://vkontakte.ru/share.php?url=%s" target="_blank" title="%s"><i class="fa fa-vk"></i>%s</a></li>', $protocol, urlencode( esc_url( get_permalink() ) ), esc_attr__( 'Share via VK', 'benchmark' ), $overlay ? esc_attr__( 'VKontakte', 'benchmark' ) : '<span class="sr-only">vkontakte</span>' );
					endif;
				break;

				case '7':
					if ( $sharing_buttons[ '7' ] ) :
						$list .= sprintf( '<li class="ss-mail"><a href="mailto:someone@example.com?Subject=%s" title="%s"><i class="fa fa-envelope"></i>%s</a></li>', urlencode( esc_attr( get_the_title() ) ), esc_attr__( 'Email this', 'benchmark' ), $overlay ? esc_attr__( 'Email', 'benchmark' ) : '<span class="sr-only">email</span>' );
						
					endif;
				break;

				case '8':
					if ( $sharing_buttons[ '8' ] ) :
						$list .= sprintf( '<li class="ss-print"><a href="#" title="%s"><i class="fa fa-print"></i>%s</a></li>', esc_attr__( 'Print', 'benchmark' ), $overlay ? esc_attr__( 'Print', 'benchmark' ) : '<span class="sr-only">print</span>' );
					endif;
				break;

				case '9':
					if ( $sharing_buttons[ '9' ] ) :
						$list .= sprintf( '<li class="ss-reddit"><a href="//www.reddit.com/submit" onclick="window.location = \'//www.reddit.com/submit?url=\' + encodeURIComponent(window.location); return false" title="%s"><i class="fa fa-reddit-square"></i><span class="sr-only">reddit</span>%s</a></li>', esc_attr__( 'Reddit', 'benchmark' ), $overlay ? esc_attr__( 'Reddit', 'benchmark' ) : '<span class="sr-only">reddit</span>' );
					endif;
				break;

			} // switch

		} // foreach

		// Support extra meta items via action hook
		ob_start();
		do_action( 'benchmark_sharing_buttons_li' );
		$out .= ob_get_contents();
		ob_end_clean();
		
		if ( $overlay ) {
			return $list;
		}
		
		$out .= $list . '</ul></div></div></div>';

		return $out;
	}
endif;

/**
 * Add Social meta tags for Facebook and Google+
 */
function benchmark_social_meta_tags() {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	if ( ( is_single() && $bmrk_opts[ 'social-meta-check' ][ 'posts' ] ) || ( is_page() && $bmrk_opts[ 'social-meta-check' ][ 'pages' ] ) ) {
		global $post;
		setup_postdata( $post );
		$image = '';
		if ( has_post_thumbnail( $post->ID ) ) {
			$image = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
		}
		?>

        <!-- Social meta tags for Facebook -->
        <meta property="og:title" content="<?php echo esc_attr( get_the_title() ); ?>"/>
        <meta property="og:type" content="article"/>
        <meta property="og:image" content="<?php echo esc_url( $image ); ?>"/>
        <meta property="og:url" content="<?php echo esc_url( get_permalink() ); ?>"/>
        <meta property="og:description" content="<?php echo strip_tags( get_the_excerpt() ); ?>"/>
        <meta property="og:site_name" content="<?php esc_attr( get_bloginfo( 'name' ) ); ?>"/>
		<?php wp_reset_postdata();
	}
}

add_action( 'wp_head', 'benchmark_social_meta_tags', 99 );

/**
 * Enable shortcodes inside Widgets
 */
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');

/**
 * Allow HTML in category and term descriptions
 */
foreach ( array( 'pre_term_description' ) as $filter ) {
    remove_filter( $filter, 'wp_filter_kses' );
	add_filter( $filter, 'do_shortcode');
	add_filter( $filter, 'shortcode_unautop');
}

foreach ( array( 'term_description' ) as $filter ) {
    remove_filter( $filter, 'wp_kses_data' );
	add_filter( $filter, 'do_shortcode');
	add_filter( $filter, 'shortcode_unautop');
}


/**
 * Assign appropriate heading tag for blog name (SEO)
 */
if ( ! function_exists( 'benchmark_site_title_tag' ) ) :
	function benchmark_site_title_tag( $tag_type, $usage = 'desktop' ) {

		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();

		$classname = ( 'text' == $bmrk_opts[ 'logo-check' ] || 'mobile' == $usage ) ? 'site-title' : 'site-title logo-image';

		if ( is_front_page() ) {
			$open_tag = '<h1 class="' . esc_attr( $classname ) . '">';
			$close_tag = '</h1>';
		}

		elseif ( is_archive() || is_page_template( 'templates/blog-classic.php' ) || is_page_template( 'templates/blog-grid.php' ) || is_page_template( 'templates/blog-list.php' ) || is_page_template( 'templates/port-grid.php' ) ) {
			$open_tag = '<h3 class="' . esc_attr( $classname ) . '">';
			$close_tag = '</h3>';
		}
		else {
			$open_tag = '<h4 class="' . esc_attr( $classname ) . '">';
			$close_tag = '</h4>';
		}

		if ( 'open' == $tag_type ) {
			echo $open_tag;
		}

		if ( 'close' == $tag_type ) {
			echo $close_tag;
		}
	}
endif;


/**
 * Generate site name and logo in header area
 */
if ( ! function_exists( 'benchmark_logo' ) ) :
	function benchmark_logo( $usage = 'desktop' ) {

		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();

		if ( $usage != 'mobile' ) :
			if ( 'text' == $bmrk_opts[ 'logo-check' ] ) :

				benchmark_site_title_tag( 'open', $usage ); ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo strip_tags( esc_attr( $bmrk_opts[ 'site-title' ] ) ); ?>" rel="home"><?php if (  ! empty ( $bmrk_opts[ 'site-title' ] ) ) echo $bmrk_opts[ 'site-title' ]; else bloginfo( 'name' ); ?></a><?php benchmark_site_title_tag( 'close' ); ?>

			<?php else :

				if ( $bmrk_opts[ 'logo-custom-url' ] ) {
					$logo_url = $bmrk_opts[ 'logo-custom-url' ];
				}

				else {

					$logo_url = ( ! empty( $bmrk_opts[ 'logo-2x-url' ][ 'url' ] ) ) ? $bmrk_opts[ 'logo-2x-url' ][ 'url' ] : $bmrk_opts[ 'logo-url' ][ 'url' ];

				}

				// Load dark logo if the color scheme is white
				$color_scheme = $bmrk_opts[ 'color-scheme' ];

				if ( is_page() ) {
					global $post;

					// Check if a per page color scheme is available
					$page_opts 		= get_post_meta( $post->ID, 'bmrk_page_opts', true );
					$color_scheme 	= isset( $page_opts[ 'color_scheme' ] ) && 'global' != $page_opts[ 'color_scheme' ] ? $page_opts[ 'color_scheme' ] : $bmrk_opts[ 'color-scheme' ];

				}

				if ( $color_scheme == 'white' ) {

					if ( $bmrk_opts[ 'logo-custom-url-dark' ] ) {
						$logo_url_dark = $bmrk_opts[ 'logo-custom-url-dark' ];
					}

					$logo_url_dark = $bmrk_opts[ 'logo-dark-url' ][ 'url' ];

				}

				benchmark_site_title_tag( 'open' ); ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-primary<?php if ( ! empty( $bmrk_opts[ 'logo-2x-url' ][ 'url' ] ) ) echo ' logo-2x'; ?>" /><?php if ( $color_scheme == 'white' ) { ?><img src="<?php echo esc_attr( $logo_url_dark ); ?>" alt="<?php esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-dark" /> <?php } ?></a>

				<?php benchmark_site_title_tag( 'close' );

			endif;
		endif;

		if ( 'mobile' == $usage ) :

			if ( 'text' == $bmrk_opts[ 'logo-check' ] ) :

					benchmark_site_title_tag( 'open', $usage ); ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo strip_tags( esc_attr( $bmrk_opts[ 'site-title' ] ) ); ?>" rel="home"><?php if (  ! empty ( $bmrk_opts[ 'site-title' ] ) ) echo $bmrk_opts[ 'site-title' ]; else bloginfo( 'name' ); ?></a><?php benchmark_site_title_tag( 'close' ); ?>

			<?php else :

				benchmark_site_title_tag( 'open' ); ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img src="<?php echo esc_url( $bmrk_opts[ 'logo-dark-url' ][ 'url' ] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="logo-dark" /></a>

				<?php benchmark_site_title_tag( 'close' );
			endif;
		endif;
	}
endif;


/**
 * WooCommerce shopping bag icon in header area
 */
function benchmark_shopping_bag() {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	if ( class_exists( 'woocommerce' ) && $bmrk_opts[ 'woo-cart-widget' ] ) {
		global $woocommerce; ?>
		<div class="cart-widget woocommerce widget_shopping_cart">
			<a class="cart-contents-2" href="#" title="<?php esc_attr_e( 'View your shopping cart', 'benchmark' ); ?>"><i class="mdi mdi-shopping_cart"></i><span class="cart-count"><?php echo $woocommerce->cart->cart_contents_count; ?></span></a>
			<div class="cart-submenu">
				<div class="widget_shopping_cart_content"></div><!-- /.widget_shopping_cart_content -->
			</div><!-- /.cart-submenu -->
		</div><!-- /.cart-widget -->
	<?php }

}

add_action( 'benchmark_header_icons', 'benchmark_shopping_bag', 10 );


/**
 * Wishlist counter in header area
 */
function benchmark_wishlist_counter() {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	if ( function_exists( 'YITH_WCWL' ) && $bmrk_opts[ 'wishlist-count' ] ) { ?>
		<div class="header-wishlist-count">
            <a href="<?php echo YITH_WCWL()->get_wishlist_url(); ?>" class="wishlist-button" title="<?php esc_attr_e( 'View your wishlist', 'benchmark' ); ?>"><i class="mdi mdi-favorite"></i><span class="sr-only"><?php esc_html_e( 'wishlist', 'benchmark' ); ?></span><span class="wishlist-count"><?php echo yith_wcwl_count_products(); ?></span></a>
		</div>
	<?php }
}

add_action( 'benchmark_header_icons', 'benchmark_wishlist_counter', 9 );


/**
 * Update wishlist count
 */
function benchmark_update_wishlist_count() {
    if( function_exists( 'YITH_WCWL' ) ) {
        wp_send_json( YITH_WCWL()->count_products() );
    }
}
add_action( 'wp_ajax_update_wishlist_count', 'benchmark_update_wishlist_count' );
add_action( 'wp_ajax_nopriv_update_wishlist_count', 'benchmark_update_wishlist_count' );


/**
 * Search widget in header area
 */
function benchmark_search_widget() {

	// Get theme options var
	$bmrk_opts = benchmark_get_theme_opts();

	if ( $bmrk_opts[ 'search-form' ] ) {  ?>
	<div class="header-search-widget">
        <a href="#" class="search-trigger" title="<?php esc_attr_e( 'Search', 'benchmark' ); ?>"><i class="mdi mdi-search"></i><span class="sr-only"><?php esc_html_e( 'search', 'benchmark' ); ?></span></a>
    </div><!-- /.header-search-widget -->
<?php }
}

add_action( 'benchmark_header_icons', 'benchmark_search_widget', 8 );

function benchmark_add_search_form() {
	get_template_part( 'includes/search-panel' );
}

add_action( 'benchmark_search_panel', 'benchmark_add_search_form', 8 );


/**
 * Responsive menu button
 */
if ( ! function_exists( 'benchmark_menu_button' ) ) :
	function benchmark_menu_button() { ?>
		<div class="header-menu-icon">
			<a href="#" class="menu-trigger" title="<?php esc_attr_e( 'Toggle Menu', 'benchmark' ); ?>"><i class="mdi mdi-menu"></i><span class="sr-only"><?php esc_html_e( 'menu', 'benchmark' ); ?></span></a>
		</div><!-- /.header-menu-icon -->
	<?php
	}
endif;


/**
 * Resized post thumbnail using Aqua Resizer
 */
if ( ! function_exists( 'benchmark_post_thumbnail' ) ) :
	function benchmark_post_thumbnail( $width, $height, $crop, $upscale ) {

		if ( function_exists( 'aq_resize' ) ) {
			$thumb = get_post_thumbnail_id();
			$src = wp_get_attachment_url( $thumb );
			$src = aq_resize( $src, $width, $height, (bool)$crop, true, (bool)$upscale );
			if ( $src ) {
				return sprintf ( '<img src="%s" alt="%s" />', $src, get_the_title() );
			}
			else {
				return get_the_post_thumbnail();
			}
		}
		else {
			return get_the_post_thumbnail();
		}
	}
endif;


/**
 * Get post thumbnail caption
 */
if ( ! function_exists( 'benchmark_post_thumbnail_caption' ) ) {
	function benchmark_post_thumbnail_caption() {
		global $post;

		$thumbnail_id    = get_post_thumbnail_id($post->ID);
		$thumbnail_image = get_posts( array( 'p' => $thumbnail_id, 'post_type' => 'attachment' ) );

		if ( $thumbnail_image && isset( $thumbnail_image[0] ) && $thumbnail_image[0]->post_excerpt ) {
			return '<p class="post-thumbnail-caption">' . $thumbnail_image[0]->post_excerpt . '</p>';
		}
	}
}

/**
 * No posts found message
 */
if ( ! function_exists( 'benchmark_no_posts_found' ) ) :
	function benchmark_no_posts_found() { ?>
        <section class="error-404 not-found">
            <header class="page-header">
                <h1 class="page-title"><?php
					if ( is_search() ) {
						esc_html_e( 'No results found.', 'benchmark' );
					}
					else {
						esc_html_e( 'Oops! That page can&rsquo;t be found.', 'benchmark' );
					} ?>
                </h1>
            </header><!-- .page-header -->

            <div class="page-content">
                <p><?php
				if ( is_search() ) {
						esc_html_e( 'Sorry! Nothing matched your search criteria. Please try searching again with different keywords.', 'benchmark' );
					}
					else {
						esc_html_e( 'It looks like nothing was found at this location. Maybe try a search?', 'benchmark' );
					} ?></p>
            <?php get_search_form(); ?>
            </div><!-- /.page-content -->
        </section><!-- /.error-404 -->
        <?php
	}
endif;



/**
 * Retrieve archive title based on the queried object.
 */

if ( ! function_exists( 'benchmark_archive_title' ) ) :
	function benchmark_archive_title() {

		// Get theme options var
		$bmrk_opts = benchmark_get_theme_opts();

		$title = '';

		if ( $bmrk_opts[ 'hero-check-archives' ] ) :
			if ( is_category() ) {
				$title = single_cat_title( '', false );
			} elseif ( is_tag() ) {
				$title = single_tag_title( '', false );
			} elseif ( is_author() ) {
				$title = '<span class="vcard">' . get_the_author() . '</span>';
			} elseif ( is_year() ) {
				$title = get_the_date( esc_html_x( 'Y', 'yearly archives date format', 'benchmark' ) );
			} elseif ( is_month() ) {
				$title = get_the_date( esc_html_x( 'F Y', 'monthly archives date format', 'benchmark' ) );
			} elseif ( is_day() ) {
				$title = get_the_date( esc_html_x( 'F j, Y', 'daily archives date format', 'benchmark' ) );
			} elseif ( is_tax( 'post_format' ) ) {
				if ( is_tax( 'post_format', 'post-format-aside' ) ) {
					$title = esc_html_x( 'Asides', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {
					$title = esc_html_x( 'Galleries', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-image' ) ) {
					$title = esc_html_x( 'Images', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-video' ) ) {
					$title = esc_html_x( 'Videos', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {
					$title = esc_html_x( 'Quotes', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-link' ) ) {
					$title = esc_html_x( 'Links', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-status' ) ) {
					$title = esc_html_x( 'Statuses', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {
					$title = esc_html_x( 'Audio', 'post format archive title', 'benchmark' );
				} elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {
					$title = esc_html_x( 'Chats', 'post format archive title', 'benchmark' );
				}
			} elseif ( is_post_type_archive() ) {
				$title = post_type_archive_title( '', false );
			} elseif ( is_tax() ) {
				$tax = get_taxonomy( get_queried_object()->taxonomy );
				/* translators: 1: Taxonomy singular name, 2: Current taxonomy term */
				$title = sprintf( esc_html_x( '%1$s: %2$s', 'Archive: Archive Term name', 'benchmark' ), $tax->labels->singular_name, single_term_title( '', false ) );
			}
		endif;

		if ( is_page() || is_single() && ! is_attachment() ) {
			$title = get_the_title();
		}

		return $title;
	}
endif;


/**
 * Display navigation to next/previous comments when applicable.
 */
if ( ! function_exists( 'benchmark_comment_nav' ) ) :
	function benchmark_comment_nav() {
		// Are there comments to navigate through?
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<nav class="navigation comment-navigation">
			<h2 class="screen-reader-text"><?php esc_html_e( 'Comment navigation', 'benchmark' ); ?></h2>
			<div class="nav-links">
				<?php
					if ( $prev_link = get_previous_comments_link( esc_html__( 'Older Comments', 'benchmark' ) ) ) :
						printf( '<div class="nav-previous">%s</div>', $prev_link );
					endif;

					if ( $next_link = get_next_comments_link( esc_html__( 'Newer Comments', 'benchmark' ) ) ) :
						printf( '<div class="nav-next">%s</div>', $next_link );
					endif;
				?>
			</div><!-- /.nav-links -->
		</nav><!-- /.comment-navigation -->
		<?php
		endif;
	}
endif;

/**
 * Shorten any text by word limit
 * http://plugins.ten-321.com/post-content-shortcodes/
 */
if ( ! function_exists( 'benchmark_short' ) ) :
	function benchmark_short( $text, $limit )	{
		if ( intval( $limit ) && intval( $limit ) < str_word_count( $text ) ) {
			$text = explode( ' ', $text );
			$text = implode( ' ', array_slice( $text, 0, ( intval( $limit ) ) ) );
			$text = force_balance_tags( $text );
			$text = str_replace( array( '<p>', '</p>' ), "", $text );
		}
		return $text;
	}
endif;

/**
 * Menu fallback when no menus assigned
 */

if ( ! function_exists( 'benchmark_menu_fallback' ) ) :
	function benchmark_menu_fallback() {
		echo '<ul class="nav-menu clearfix"><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'benchmark' ) . '</a></li></ul>';
	}
endif;

if ( ! function_exists( 'benchmark_resp_menu_fallback' ) ) :
	function benchmark_resp_menu_fallback() {
		echo '<ul class="resp-menu clearfix"><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'benchmark' ) . '</a></li></ul>';
	}
endif;


/* Custom ajax loader for Contact Form 7 plugin */

function my_wpcf7_ajax_loader() {
	return  get_template_directory_uri() . '/images/loading-spinner.gif';
}

add_filter('wpcf7_ajax_loader', 'my_wpcf7_ajax_loader');

/**
 * Show breadcrumbs according to the options chosen
 */
function benchmark_show_breadcrumbs() {
	global $post, $bmrk_opts;
	if ( class_exists( 'Bonanza_Shortcodes' ) && ! is_home() && ! is_front_page() ) {
		if ( is_page() ) {
			$page_opts = get_post_meta( $post->ID, 'bmrk_page_opts', true );
			$hide_crumbs = isset( $page_opts['hide_crumbs'] ) ? $page_opts['hide_crumbs'] : '';
			if ( ! $hide_crumbs ) { // If not opted to hide breadcrumbs
				if ( $bmrk_opts[ 'crumbs-check' ] ) {
					echo do_shortcode( '[ss_breadcrumbs]' );
				}
			} // Hide breadcrumbs
			elseif ( ! isset( $page_opts ) ) {
				if ( $bmrk_opts[ 'crumbs-check' ] ) {
					echo do_shortcode( '[ss_breadcrumbs]' );
				}
			} // Default Fallback when no options are set
		} // is_page
		else {
			if ( $bmrk_opts[ 'crumbs-check' ] ) {
				echo do_shortcode( '[ss_breadcrumbs]' );
			}
		}
	}
}

add_action( 'benchmark_main_content_start', 'benchmark_show_breadcrumbs', 8 );


/**
 * Hide redux framework notices
 */
function benchmark_admin_css() {
	echo '<style type="text/css">
		.redux-dev-mode-notice-container.redux-dev-qtip { display: none; }
	</style>';
}
add_action( 'admin_head', 'benchmark_admin_css' );

/**
 * Dequeue fontawesome CSS loaded by Yith Wishlist plugin
 */

function benchmark_dequeue_fontawesome()  {
	wp_dequeue_style( 'yith-wcwl-font-awesome' ); 
}

add_action( 'wp_print_styles', 'benchmark_dequeue_fontawesome', 100 );

/**
 * Add async and defer loading of JavaScripts
 */

function benchmark_async_loading( $tag, $handle ) {
	$handles = array( 'jquery-masonry', 'benchmark-custom' );
	
	if ( ! in_array( $handle, $handles ) ) {
		return $tag;
	}

    return str_replace( ' src', ' defer async src', $tag );
}
//add_filter( 'script_loader_tag', 'benchmark_async_loading' , 10, 2 );


/**
 * Register the required plugins for this theme.
 */
function benchmark_register_required_plugins() {

	$plugins = array(

        array(
            'name'               => 'Bonanza Shortcodes',
            'slug'               => 'bonanza-shortcodes',
            'source'             => get_template_directory() . '/plugins/bonanza-shortcodes.zip',
            'required'           => true, // If false, the plugin is only 'recommended' instead of required.
            'version'            => '1.3.0', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
            'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
            'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
            'external_url'       => '', // If set, overrides default API URL and points to an external URL.
        ),

        // Redux Plugin from WordPress repository
        array(
            'name'      => 'Redux Framework',
            'slug'      => 'redux-framework',
            'required'  => true,
        ),

		// Siteorigin Page Builder Plugin
		array(
            'name'      => 'SiteOrigin Panels',
            'slug'      => 'siteorigin-panels',
            'required'  => true,
        ),

		// Contact Form 7 Plugin
		array(
            'name'      => 'Contact Form 7',
            'slug'      => 'contact-form-7',
            'required'  => true,
        ),
		
		// WooCommerce Plugin
		array(
            'name'      => 'WooCommerce',
            'slug'      => 'woocommerce',
            'required'  => false,
        ),

		// Yith WooCommerce Quick View
        array(
            'name'      => 'Yith WooCommerce Quick View',
            'slug'      => 'yith-woocommerce-quick-view',
            'required'  => false,
        ),

		// Yith WooCommerce Wishlist
        array(
            'name'      => 'Yith WooCommerce Wishlist',
            'slug'      => 'yith-woocommerce-wishlist',
            'required'  => false,
        )

    );

	/*
	 * Array of configuration settings. Amend each line as needed.
	 *
	 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
	 * strings available, please help us make TGMPA even better by giving us access to these translations or by
	 * sending in a pull-request with .po file(s) with the translations.
	 *
	 * Only uncomment the strings in the config array if you want to customize the strings.
	 */
	$config = array(
		'id'           => 'benchmark',             // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.
	);

    tgmpa( $plugins, $config );
}

add_action( 'tgmpa_register', 'benchmark_register_required_plugins' );
?>