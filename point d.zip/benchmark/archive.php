<?php
/**
 * The template for displaying Archive pages.
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();
get_header(); ?>

	<main id="main" class="col-xs-12 col-md-9">

		<?php do_action( 'benchmark_main_content_start' );
		
		// Grid style archives uses Masonry container
		if ( 'grid' == $bmrk_opts[ 'archive-style' ] ) { ?>
            <div class="<?php if ( $bmrk_opts[ 'masonry-check' ] ) echo 'masonry-enabled'; ?> content-grid row clearfix">
		<?php }
		
		if ( have_posts() ) :

			the_archive_description( '<header class="page-header"><div class="taxonomy-description">', '</div></header>' );
			
			while ( have_posts() ) :
				
				the_post();
			
				get_template_part( 'content', $bmrk_opts[ 'archive-style' ] );
			
			// End the loop.
			endwhile;			
        
			// Close grid style container
			if ( 'grid' == $bmrk_opts[ 'archive-style' ] ) { ?>
				</div><!-- /.content-grid -->
			<?php }
			
			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'benchmark' ),
				'next_text'          => __( 'Next page', 'benchmark' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'benchmark' ) . ' </span>',
			) );

		// If no content
		else :
		
			benchmark_no_posts_found();
			
		endif;
		?>

	</main><!-- /#main -->

<?php if ( $bmrk_opts[ 'archive-sb-check' ] ) {
	get_sidebar();
}
get_footer(); ?>