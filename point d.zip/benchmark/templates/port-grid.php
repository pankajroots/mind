<?php
/**
 * Template Name: Portfolio
 *
 * Description: Grid style portfolio
 */

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

get_header();

	// Page option variables
	$page_opts 			= get_post_meta( $posts[0]->ID, 'bmrk_page_opts', true );
	$cats 				= isset( $page_opts[ 'cats' ] ) ? $page_opts[ 'cats' ] : array( '-1' );
	$grid_columns 		= isset( $page_opts[ 'grid_columns' ] ) ? $page_opts[ 'grid_columns' ] : '2';
	$img_width 			= !empty ( $page_opts[ 'img_width' ] ) ? $page_opts[ 'img_width' ] : $bmrk_opts[ 'port-images' ][ 'width' ];
	$img_height 		= !empty ( $page_opts[ 'img_height' ] ) ? $page_opts[ 'img_height' ] : $bmrk_opts[ 'port-images' ][ 'height' ];
	$img_crop 			= isset ( $page_opts[ 'img_crop' ] ) ? $page_opts[ 'img_crop' ] : (bool)$bmrk_opts[ 'port-misc' ][ '1' ];
	$img_upscale 		= isset ( $page_opts[ 'img_upscale' ] ) ? $page_opts[ 'img_upscale' ] : (bool)$bmrk_opts[ 'port-misc' ][ '2' ];
	$post_per_page 		= !empty( $page_opts[ 'post_per_page' ] ) ? $page_opts[ 'post_per_page' ] : '8';
	$sb_placement 		= isset( $page_opts[ 'sb_placement' ] ) ? $page_opts[ 'sb_placement' ] : 'global';
	$content_class 		= 'col-xs-12 col-md-9';

	switch( $sb_placement ) {

		case 'none' :
			$content_class = 'col-md-12';
		break;

		case 'left' :
			$content_class = 'col-xs-12 col-md-9 content-right';
		break;

		case 'right' :
			$content_class = 'col-xs-12 col-md-9 content-left';
		break;

	}
?>

<main id="main" class="<?php echo esc_attr( $content_class ); ?>">
	<?php
    do_action( 'benchmark_main_content_start' );

	// Page content before posts
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
            the_content();
		endwhile;
	endif;

    if ( $cats ) :
		if ( get_query_var( 'paged' ) )
			$paged = get_query_var( 'paged' );
		elseif ( get_query_var( 'page' ) )
			$paged = get_query_var( 'page' );
		else
			$paged = 1;
		$args = array(
			'cat' 					=> implode( ',', $cats ),
			'orderby' 				=> 'date',
			'order' 				=> 'desc',
			'paged' 				=> $paged,
			'posts_per_page' 		=> $post_per_page
		);

		/* Assign original query to temp */
		$temp = $wp_query;
		$wp_query = new WP_Query( $args );

		if ( $wp_query->have_posts() ) : ?>

            <div class="<?php if ( $bmrk_opts[ 'masonry-check' ] ) echo 'masonry-enabled'; ?> port-grid row clearfix">
				<?php
                $count = 1;
                $clear_class = '';
                $grid_class = 'entry-grid col-xs-6';

                switch( $grid_columns ) {

					case '3' :
						$grid_class .= ' col-sm-4 col-md-4';
					break;

					case '4' :
						$grid_class .= ' col-sm-3 col-md-3';
					break;

                }

                while ( $wp_query->have_posts()) :

					$wp_query->the_post();

					/* Calculate appropriate class names for first grids */
					$clear_class = ( 0 == ( ( $count - 1 ) % $grid_columns ) ) ? ' first-grid' : '';
					if ( has_post_thumbnail() ) { ?>
                        <article id="post-<?php the_ID();?>" <?php post_class( $grid_class . $clear_class ); ?>>
                            <div class="entry-inner">

                                <div class="post-thumb">
                                    <?php if ( 'gallery' == get_post_format() ) { ?>
                                        <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                                    <?php }

                                    elseif ( 'video' == get_post_format() ) { ?>
                                        <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                                    <?php }

									if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
										echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
									}

                                    else { ?>

                                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                        <?php
                                        echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
                                        ?>
                                    </a>

                                    <?php } ?>
                                </div><!-- /.post-thumb -->

                                <div class="entry-content">
                                    <?php the_title( '<h2><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
                                    if ( $bmrk_opts[ 'archive-meta-check' ] ) { ?>
                                        <aside id="meta-<?php the_ID();?>" class="entry-meta"><?php echo apply_filters( 'benchmark_post_meta_port', benchmark_post_meta( 'meta-links-port' ) ); ?></aside>
                                    <?php } ?>
                                </div><!-- /.entry-content -->

                            </div><!-- /.entry-inner -->
                        </article><!-- /#post-<?php the_ID();?> -->
				<?php } // has post thumbnail

                $count++;

                endwhile; // End the loop ?>

            </div><!-- /.port-grid -->

            <?php
            the_posts_pagination( array(
				'prev_text'          => esc_html__( 'Previous page', 'benchmark' ),
				'next_text'          => esc_html__( 'Next page', 'benchmark' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'benchmark' ) . ' </span>',
            ) );

		else :
			benchmark_no_posts_found();
		endif; // if have posts

		$wp_query = $temp;  // reset back to original query

    endif; ?>

</main><!-- /#main -->

<?php
if ( 'none' != $sb_placement ) {
	get_sidebar();
}
get_footer(); ?>