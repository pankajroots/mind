<?php
/**
 * Template Name: Blog - List Style
 *
 * Description: A list style blog template with left aligned thumbnails.
 */
// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

get_header();

	// Page option variables
	$page_opts 			= get_post_meta( $posts[0]->ID, 'bmrk_page_opts', true );
	$cats 				= isset( $page_opts[ 'cats' ] ) ? $page_opts[ 'cats' ] : array( '-1' );
	$post_per_page 		= !empty( $page_opts[ 'post_per_page' ] ) ? $page_opts[ 'post_per_page' ] : '9';
	$img_width 			= !empty ( $page_opts[ 'img_width' ] ) ? $page_opts[ 'img_width' ] : $bmrk_opts[ 'list-images' ][ 'width' ];
	$img_height 		= !empty ( $page_opts[ 'img_height' ] ) ? $page_opts[ 'img_height' ] : $bmrk_opts[ 'list-images' ][ 'height' ];
	$img_crop 			= isset ( $page_opts[ 'img_crop' ] ) ? $page_opts[ 'img_crop' ] : (bool)$bmrk_opts[ 'list-misc' ][ '1' ];
	$img_upscale 		= isset ( $page_opts[ 'img_upscale' ] ) ? $page_opts[ 'img_upscale' ] : (bool)$bmrk_opts[ 'list-misc' ][ '2' ];
	$sb_placement 		= isset( $page_opts[ 'sb_placement' ] ) ? $page_opts[ 'sb_placement' ] : 'global';
	$content_class 		= 'col-xs-12 col-md-9';

	switch( $sb_placement ) {

		case 'none' :
			$content_class = 'col-md-12';
		break;

		case 'left' :
			$content_class = 'col-xs-12 col-md-9 content-right';
		break;

		case 'right' :
			$content_class = 'col-xs-12 col-md-9 content-left';
		break;

	}
?>

<main id="main" class="<?php echo esc_attr( $content_class ); ?>">
	<?php
    do_action( 'benchmark_main_content_start' );

	// Page content before posts
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
	endif;

    if ( $cats ) :
		if ( get_query_var( 'paged' ) )
			$paged = get_query_var( 'paged' );
		elseif ( get_query_var( 'page' ) )
			$paged = get_query_var( 'page' );
		else
			$paged = 1;
		$args = array(
			'cat' 					=> implode( ',', $cats ),
			'orderby' 				=> 'date',
			'order' 				=> 'desc',
			'paged' 				=> $paged,
			'posts_per_page' 		=> $post_per_page
		);

		/* Assign original query to temp */
		$temp = $wp_query;
		$wp_query = new WP_Query( $args );

		if ( $wp_query->have_posts() ) :
			while ( $wp_query->have_posts() ) :
				$wp_query->the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-list clearfix' ); ?>>

      <?php if ( has_post_thumbnail() ) { ?>
                    <div class="post-thumb">
						<?php if ( 'gallery' == get_post_format() ) { ?>
                            <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                        <?php }

                        elseif ( 'video' == get_post_format() ) { ?>
                            <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                        <?php }

						if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
							echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
						}

						else { ?>

                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
							<?php
                            echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
                            ?>
                        </a>

						<?php } ?>

                    </div><!-- /.post-thumb -->

            <?php $content_right_class = 'entry-content'; ?>

        <?php }
        else {
			$content_right_class = 'entry-content no-thumbnail';
        }
        ?>

        <div class="<?php echo esc_attr( $content_right_class ); ?>">

			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

			echo '<p class="post-excerpt">' . benchmark_short( get_the_excerpt(), $bmrk_opts[ 'excerpt-length-list' ] ) . '</p>';

			if ( $bmrk_opts[ 'archive-meta-check' ] ) : ?>
                <aside id="meta-<?php the_ID(); ?>" class="entry-meta list"><?php echo apply_filters( 'benchmark_post_meta_list_big', benchmark_post_meta( 'meta-links-list' ) ); ?></aside>
            <?php endif; ?>

        </div><!-- /.entry-right -->

				</article><!-- /#post-<?php the_ID(); ?> -->

			<?php endwhile; // End the loop

			the_posts_pagination( array(
				'prev_text'          => esc_html__( 'Previous page', 'benchmark' ),
				'next_text'          => esc_html__( 'Next page', 'benchmark' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'benchmark' ) . ' </span>',
			) );

		else :
			benchmark_no_posts_found();
		endif; // if have posts

		$wp_query = $temp;  // reset back to original query

    endif; ?>

</main><!-- /#main -->

<?php
if ( 'none' != $sb_placement ) {
	get_sidebar();
}
get_footer(); ?>