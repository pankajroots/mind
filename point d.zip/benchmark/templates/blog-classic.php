<?php
/**
 * Template Name: Blog - Classic Style
 *
 * Description: Show blog posts in classic style.
 */
global $wp_query, $posts;

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

get_header();

	// Page option variables
	$page_opts 			= get_post_meta( $posts[0]->ID, 'bmrk_page_opts', true );
	$cats 				= isset( $page_opts[ 'cats' ] ) ? $page_opts[ 'cats' ] : array( '-1' );
	$post_per_page 		= !empty( $page_opts[ 'post_per_page' ] ) ? $page_opts[ 'post_per_page' ] : '9';
	$img_width 			= !empty ( $page_opts[ 'img_width' ] ) ? $page_opts[ 'img_width' ] : $bmrk_opts[ 'classic-images' ][ 'width' ];
	$img_height 		= !empty ( $page_opts[ 'img_height' ] ) ? $page_opts[ 'img_height' ] : $bmrk_opts[ 'classic-images' ][ 'height' ];
	$img_crop 			= isset ( $page_opts[ 'img_crop' ] ) ? $page_opts[ 'img_crop' ] : (bool)$bmrk_opts[ 'classic-misc' ][ '1' ];
	$img_upscale 		= isset ( $page_opts[ 'img_upscale' ] ) ? $page_opts[ 'img_upscale' ] : (bool)$bmrk_opts[ 'classic-misc' ][ '2' ];
	$sb_placement 		= isset( $page_opts[ 'sb_placement' ] ) ? $page_opts[ 'sb_placement' ] : 'global';
	$content_class 		= 'col-xs-12 col-md-9';

	switch( $sb_placement ) {

		case 'none' :
			$content_class = 'col-md-12';
		break;

		case 'left' :
			$content_class = 'col-xs-12 col-md-9 content-right';
		break;

		case 'right' :
			$content_class = 'col-xs-12 col-md-9 content-left';
		break;

	}
?>

<main id="main" class="<?php echo esc_attr( $content_class ); ?>">

	<?php do_action( 'benchmark_main_content_start' );

	// Enable page content before posts
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
	endif;

    if ( $cats ) :
		if ( get_query_var( 'paged' ) )
			$paged = get_query_var( 'paged' );
		elseif ( get_query_var( 'page' ) )
			$paged = get_query_var( 'page' );
		else
			$paged = 1;
		$args = array(
			'cat' 				=> implode( ',', $cats ),
			'orderby' 			=> 'date',
			'order' 			=> 'desc',
			'paged' 			=> $paged,
			'posts_per_page' 	=> $post_per_page
		);

		/* Assign original query to temp */
		$temp = $wp_query;
		$wp_query = new WP_Query( $args );

		if ( $wp_query->have_posts() ) :

			while ( $wp_query->have_posts() ) :
				$wp_query->the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-classic clearfix' ); ?>>

					<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

                    if ( $bmrk_opts[ 'archive-meta-check' ] ) : ?>
                        <aside id="meta-<?php the_ID();?>" class="entry-meta"><?php echo apply_filters( 'benchmark_post_meta_classic', benchmark_post_meta( 'meta-links-list' ) ); ?></aside>
                    <?php endif;

                    if ( 'video' == get_post_format() && $bmrk_opts[ 'archive-video-check' ] ) {
                        get_template_part( 'formats/format-video' );
                    }

                    else {
						if ( has_post_thumbnail() ) { ?>

                           <div class="post-thumb">
                                <?php if ( 'gallery' == get_post_format() ) { ?>
                                    <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                                <?php }

                                elseif ( 'video' == get_post_format() ) { ?>
                                    <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                                <?php }

								if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
                                    echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
								}

                                else { ?>

                                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                    <?php
                                    echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
                                    ?>
                                </a>

                                <?php } ?>

                            </div><!-- /.post-thumb -->

						<?php }
					}

                    if ( 'excerpt' == $bmrk_opts[ 'classic-content-check' ] ) {
                        echo '<p class="post-excerpt">' . benchmark_short( get_the_excerpt(), $bmrk_opts[ 'excerpt-length-classic' ] ) . '</p>'; ?>
                        <p><a class="more-link btn-flat" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php esc_html_e( 'Read more', 'benchmark' ); ?></a></p>
					<?php }

                    else {
                        global $more;
                        $more = 0;
                        the_content( esc_html__( 'Read more', 'benchmark' ) );
                    } ?>

                </article><!-- #post-<?php the_ID(); ?> -->

			<?php endwhile; // End the loop

			the_posts_pagination( array(
				'prev_text'          => esc_html__( 'Previous page', 'benchmark' ),
				'next_text'          => esc_html__( 'Next page', 'benchmark' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'benchmark' ) . ' </span>',
			) );

		else :

			benchmark_no_posts_found();

		endif; // if have posts

		$wp_query = $temp; // reset back to original query

    endif; // if $cats ?>

</main><!-- /#main -->

<?php
if ( 'none' != $sb_placement ) {
	get_sidebar();
}
get_footer(); ?>