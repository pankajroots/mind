<?php
/**
 * Template Name: Blog - Grid Style
 *
 * Description: Grid style posts with sidebar
 */
global $wp_query;

// Get theme options var
$bmrk_opts = benchmark_get_theme_opts();

get_header();

	// Page option variables
	$page_opts 			= get_post_meta( $posts[0]->ID, 'bmrk_page_opts', true );
	$cats 				= isset( $page_opts[ 'cats' ] ) ? $page_opts[ 'cats' ] : array( '-1' );
	$grid_columns 		= isset( $page_opts[ 'grid_columns' ] ) ? $page_opts[ 'grid_columns' ] : '2';
	$img_width 			= !empty ( $page_opts[ 'img_width' ] ) ? $page_opts[ 'img_width' ] : $bmrk_opts[ 'grid-images' ][ 'width' ];
	$img_height 		= !empty ( $page_opts[ 'img_height' ] ) ? $page_opts[ 'img_height' ] : $bmrk_opts[ 'grid-images' ][ 'height' ];
	$img_crop 			= isset ( $page_opts[ 'img_crop' ] ) ? $page_opts[ 'img_crop' ] : (bool)$bmrk_opts[ 'grid-misc' ][ '1' ];
	$img_upscale 		= isset ( $page_opts[ 'img_upscale' ] ) ? $page_opts[ 'img_upscale' ] : (bool)$bmrk_opts[ 'grid-misc' ][ '2' ];
	$post_per_page 		= !empty( $page_opts[ 'post_per_page' ] ) ? $page_opts[ 'post_per_page' ] : '8';
	$sb_placement 		= isset( $page_opts[ 'sb_placement' ] ) ? $page_opts[ 'sb_placement' ] : 'global';
	$content_class 		= 'col-xs-12 col-md-9';

	switch( $sb_placement ) {

		case 'none' :
			$content_class = 'col-md-12';
		break;

		case 'left' :
			$content_class = 'col-xs-12 col-md-9 content-right';
		break;

		case 'right' :
			$content_class = 'col-xs-12 col-md-9 content-left';
		break;

	}
?>

<main id="main" class="<?php echo esc_attr( $content_class ); ?>">
	<?php
    do_action( 'benchmark_main_content_start' );

	// Page content before posts
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
	endif;

    if ( $cats ) :
		if ( get_query_var( 'paged' ) )
			$paged = get_query_var( 'paged' );
		elseif ( get_query_var( 'page' ) )
			$paged = get_query_var( 'page' );
		else
			$paged = 1;
		$args = array(
			'cat' 					=> implode( ',', $cats ),
			'orderby' 				=> 'date',
			'order' 				=> 'desc',
			'paged' 				=> $paged,
			'posts_per_page' 		=> $post_per_page
		);

		/* Assign original query to temp */
		$temp = $wp_query;
		$wp_query = new WP_Query( $args );

		if ( $wp_query->have_posts() ) : ?>
            <div class="<?php if ( $bmrk_opts[ 'masonry-check' ] ) echo 'masonry-enabled'; ?> content-grid row clearfix">
				<?php
                $count = 1;
                $clear_class = '';
                $grid_class = 'entry-grid col-xs-6';

                switch( $grid_columns ) {

					case '3' :
						$grid_class .= ' col-sm-4 col-md-4';
					break;

					case '4' :
						$grid_class .= ' col-sm-3 col-md-3';
					break;

                }

                while ( $wp_query->have_posts()) :

					$wp_query->the_post();

					/* Calculate appropriate class names for first grids */
					$clear_class = ( 0 == ( ( $count - 1 ) % $grid_columns ) ) ? ' first-grid' : '';
					?>
                    <article id="post-<?php the_ID();?>" <?php post_class( $grid_class . $clear_class ); ?>>
                        <div class="entry-inner">
							<?php if ( 'video' == get_post_format() && $bmrk_opts[ 'archive-video-check' ] ) {
                                get_template_part( 'formats/format-video' );
                            }
                            else {
                            if ( has_post_thumbnail() ) { ?>
                                <div class="post-thumb">
                                    <?php if ( 'gallery' == get_post_format() ) { ?>
                                        <a class="post-format-icon mdi mdi-photo_library" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                                    <?php }

                                    elseif ( 'video' == get_post_format() ) { ?>
                                        <a class="post-format-icon mdi mdi-play_circle_filled" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><span class="screen-reader-text"><?php the_title_attribute(); ?></span></a>
                                    <?php }

                                    if ( 'gallery' == get_post_format() || 'video' == get_post_format() ) {
                                        echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
									}

                                    else { ?>

                                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                                        <?php
                                        echo benchmark_post_thumbnail( $img_width, $img_height, $img_crop, $img_upscale );
                                        ?>
                                    </a>

                                    <?php } ?>

                                </div><!-- /.post-thumb -->
                            <?php } // has_post_thumbnail
                            } ?>

                            <div class="entry-content">
                                <?php

                                // Action hook before grid post title
                                do_action( 'benchmark_before_grid_title' );

                                the_title( '<h2><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

                                // Action hook after grid post title
                                do_action( 'benchmark_after_grid_title' );
                                ?>

                                <p class="post-excerpt">
                                    <?php echo benchmark_short( get_the_excerpt(), $bmrk_opts[ 'excerpt-length-grid' ] ); ?>
                                </p>
                            </div><!-- /.entry-content -->

                            <?php
                            if ( $bmrk_opts[ 'archive-meta-check' ] ) : ?>
                                <footer class="entry-actions">
                                    <aside id="meta-<?php the_ID();?>" class="entry-meta"><?php echo benchmark_footer_actions(); ?></aside>
                                </footer><!-- ./entry-actions -->
                            <?php endif; ?>

                        </div><!-- /.entry-inner -->

                    </article><!-- /#post-<?php the_ID();?> -->

					<?php $count++;

				endwhile; // End the loop ?>

            </div><!-- /.row -->

			<?php
			the_posts_pagination( array(
				'prev_text'          => esc_html__( 'Previous page', 'benchmark' ),
				'next_text'          => esc_html__( 'Next page', 'benchmark' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'benchmark' ) . ' </span>',
			) );

		else :
			benchmark_no_posts_found();
		endif; // if have posts

		$wp_query = $temp;  // reset back to original query
    endif; ?>
</main><!-- /#main -->

<?php
if ( 'none' != $sb_placement ) {
	get_sidebar();
}
get_footer(); ?>